#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "otcsdk::otcsdk" for configuration "Release"
set_property(TARGET otcsdk::otcsdk APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(otcsdk::otcsdk PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libotcsdk.so"
  IMPORTED_SONAME_RELEASE "libotcsdk.so"
  )

list(APPEND _cmake_import_check_targets otcsdk::otcsdk )
list(APPEND _cmake_import_check_files_for_otcsdk::otcsdk "${_IMPORT_PREFIX}/lib/libotcsdk.so" )

# Import target "otcsdk::otcsdk_static" for configuration "Release"
set_property(TARGET otcsdk::otcsdk_static APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(otcsdk::otcsdk_static PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C;CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libotcsdk_static.a"
  )

list(APPEND _cmake_import_check_targets otcsdk::otcsdk_static )
list(APPEND _cmake_import_check_files_for_otcsdk::otcsdk_static "${_IMPORT_PREFIX}/lib/libotcsdk_static.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
