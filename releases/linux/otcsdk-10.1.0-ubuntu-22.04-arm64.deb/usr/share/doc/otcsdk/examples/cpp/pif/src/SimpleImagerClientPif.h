// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    SimpleImagerClientPif.h
 * @author  Optris GmbH & Co. KG
 * @brief   Declarations of the main class for the minimal example.
 *          
 * @date 2025-03-31
 */

#pragma once

#include <chrono>
#include <memory>

#include "otcsdk/IRImager.h"
#include "otcsdk/IRImagerClient.h"


/**
 * @brief Minimal example implementation of an SimpleImagerClientPif with additional PIF functionality
 * 
 * Bare minimum required to run an imager instance and receive data from it via the Observer pattern. 
 * Adds a method that configures the Process Interface (PIF) and an additional callback for "Uncommitted Value".
 */
class SimpleImagerClientPif : public optris::IRImagerClient
{
public:
  /**
   * @brief Constructor.
   * 
   * @param[in] serialNumber of the camera to connect to.
   *
   * @throw SDKException if an imager instance could not be created.
   */
  SimpleImagerClientPif(unsigned long serialNumber);


  /// Main run method.
  void run();

  /// Configures the process interface.
  void configurePif();


private:
  // Convenience alias declarations for std::chrono.
  using Clock     = std::chrono::steady_clock;
  using TimePoint = Clock::time_point;
  using Seconds   = std::chrono::seconds;


  /// Time by which the output should be delayed.
  static constexpr Seconds DELAY_TIME{5};
  /// Wait-time between outputs.
  static constexpr Seconds OUTPUT_INTERVAL{1};


  /**
   * @brief Callback method triggered by imager when a new thermal frame is available.
   *
   * @param[in] thermal thermal frame data.
   * @param[in] meta    data of thermal frame.
   */
  void onThermalFrame(const optris::ThermalFrame& thermal, const optris::FrameMetadata& meta) override;


  /**
   * @brief Callback method triggered by imager when the state of the shutter flag changes.
   *
   * @param[in] flagState of the shutter flag.
   */
  void onFlagStateChange(optris::FlagState flagState) override;

  /**
   * @brief Callback method triggered by imager when a changed uncommitted PIF analog input value was received.
   * 
   * @param[in] name  configured name of the uncommitted value.
   * @param[in] unit  configured unit of the uncommitted value.
   * @param[in] value calculated from the PIF analog input value.
   */
  void onPifUncommittedValue(const std::string& name, const std::string& unit, float value) override;


  // Variables to delay and throttle the info-output of the PIF inputs (via the onThermalFrame()-callback).
  /// Timestamp gets set when configurePif() has finished.
  TimePoint _configurationFinished;
  /// Timestamp to keep track of the time of the last standard output.
  TimePoint _lastOutput;
  /// Turns off elapsed-time check in onThermalFrame()-callback.
  bool _delayOutput; 
  
  /// Imager instance.
  std::shared_ptr<optris::IRImager> _imager;
};