/**
 * @file Obvious2D.cpp
 *
 * @brief  Contains resources to render images with the help of OpenGL.
 *
 *
 * This file is part of the Obviously library.
 *
 * Copyright(c) 2010-2012 Georg-Simon-Ohm University, Nuremberg.
 * http://www.ohm-university.eu
 *
 * This file may be licensed under the terms of of the
 * GNU General Public License Version 2 (the ``GPL'').
 *
 * Software distributed under the License is distributed
 * on an ``AS IS'' basis, WITHOUT WARRANTY OF ANY KIND, either
 * express or implied. See the GPL for the specific language
 * governing rights and limitations.
 *
 * You should have received a copy of the GPL along with this
 * program. If not, go to http://www.gnu.org/licenses/gpl.html
 * or write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

#include "Obvious2D.h"

#include <cstring>
#include <sstream>
#include <iostream>
#include <iomanip>


using namespace std;


Obvious2D* Obvious2D::_this[32];
bool Obvious2D::_is_glut_initialized = false;
bool Obvious2D::_instance_map[32] = {0};
std::mutex Obvious2D::_mutex;

bool _showSerial;

using fpOnCloseEvent   = void (*)();
using fpOnToggleScreen = void (*)();
using fpOnKeyboard     = void (*)(unsigned char, int, int);
using fpOnChangeSize   = void (*)(GLsizei, GLsizei);
using fpSetupGlut      = void (*)();
using fpDisplayFunc    = void (*)();

template <unsigned int instance>
void onCloseEvent();
static fpOnCloseEvent _onCloseEventSlot[] =
{
    &onCloseEvent<0>,
    &onCloseEvent<1>,
    &onCloseEvent<2>,
    &onCloseEvent<3>,
    &onCloseEvent<4>,
    &onCloseEvent<5>,
    &onCloseEvent<6>,
    &onCloseEvent<7>,
    &onCloseEvent<8>,
    &onCloseEvent<9>,
    &onCloseEvent<10>,
    &onCloseEvent<11>,
    &onCloseEvent<12>,
    &onCloseEvent<13>,
    &onCloseEvent<14>,
    &onCloseEvent<15>,
    &onCloseEvent<16>,
    &onCloseEvent<17>,
    &onCloseEvent<18>,
    &onCloseEvent<19>,
    &onCloseEvent<20>,
    &onCloseEvent<21>,
    &onCloseEvent<22>,
    &onCloseEvent<23>,
    &onCloseEvent<24>,
    &onCloseEvent<25>,
    &onCloseEvent<26>,
    &onCloseEvent<27>,
    &onCloseEvent<28>,
    &onCloseEvent<29>,
    &onCloseEvent<30>,
    &onCloseEvent<31>
};

template <unsigned int instance>
void onToggleScreen();
static fpOnToggleScreen _onToggleScreenSlot[] =
{
    &onToggleScreen<0>,
    &onToggleScreen<1>,
    &onToggleScreen<2>,
    &onToggleScreen<3>,
    &onToggleScreen<4>,
    &onToggleScreen<5>,
    &onToggleScreen<6>,
    &onToggleScreen<7>,
    &onToggleScreen<8>,
    &onToggleScreen<9>,
    &onToggleScreen<10>,
    &onToggleScreen<11>,
    &onToggleScreen<12>,
    &onToggleScreen<13>,
    &onToggleScreen<14>,
    &onToggleScreen<15>,
    &onToggleScreen<16>,
    &onToggleScreen<17>,
    &onToggleScreen<18>,
    &onToggleScreen<19>,
    &onToggleScreen<20>,
    &onToggleScreen<21>,
    &onToggleScreen<22>,
    &onToggleScreen<23>,
    &onToggleScreen<24>,
    &onToggleScreen<25>,
    &onToggleScreen<26>,
    &onToggleScreen<27>,
    &onToggleScreen<28>,
    &onToggleScreen<29>,
    &onToggleScreen<30>,
    &onToggleScreen<31>
};

template <unsigned int instance>
void onKeyboard(unsigned char key, int x, int y);
static fpOnKeyboard _onKeyboardSlot[] =
{
    &onKeyboard<0>,
    &onKeyboard<1>,
    &onKeyboard<2>,
    &onKeyboard<3>,
    &onKeyboard<4>,
    &onKeyboard<5>,
    &onKeyboard<6>,
    &onKeyboard<7>,
    &onKeyboard<8>,
    &onKeyboard<9>,
    &onKeyboard<10>,
    &onKeyboard<11>,
    &onKeyboard<12>,
    &onKeyboard<13>,
    &onKeyboard<14>,
    &onKeyboard<15>,
    &onKeyboard<16>,
    &onKeyboard<17>,
    &onKeyboard<18>,
    &onKeyboard<19>,
    &onKeyboard<20>,
    &onKeyboard<21>,
    &onKeyboard<22>,
    &onKeyboard<23>,
    &onKeyboard<24>,
    &onKeyboard<25>,
    &onKeyboard<26>,
    &onKeyboard<27>,
    &onKeyboard<28>,
    &onKeyboard<29>,
    &onKeyboard<30>,
    &onKeyboard<31>
};

template <unsigned int instance>
void onChangeSize(GLsizei w, GLsizei h);
static fpOnChangeSize _onChangeSizeSlot[] =
{
    &onChangeSize<0>,
    &onChangeSize<1>,
    &onChangeSize<2>,
    &onChangeSize<3>,
    &onChangeSize<4>,
    &onChangeSize<5>,
    &onChangeSize<6>,
    &onChangeSize<7>,
    &onChangeSize<8>,
    &onChangeSize<9>,
    &onChangeSize<10>,
    &onChangeSize<11>,
    &onChangeSize<12>,
    &onChangeSize<13>,
    &onChangeSize<14>,
    &onChangeSize<15>,
    &onChangeSize<16>,
    &onChangeSize<17>,
    &onChangeSize<18>,
    &onChangeSize<19>,
    &onChangeSize<20>,
    &onChangeSize<21>,
    &onChangeSize<22>,
    &onChangeSize<23>,
    &onChangeSize<24>,
    &onChangeSize<25>,
    &onChangeSize<26>,
    &onChangeSize<27>,
    &onChangeSize<28>,
    &onChangeSize<29>,
    &onChangeSize<30>,
    &onChangeSize<31>
};

template <unsigned int instance>
void setupGlut();
static fpSetupGlut _setupGlutSlot[] =
{
    &setupGlut<0>,
    &setupGlut<1>,
    &setupGlut<2>,
    &setupGlut<3>,
    &setupGlut<4>,
    &setupGlut<5>,
    &setupGlut<6>,
    &setupGlut<7>,
    &setupGlut<8>,
    &setupGlut<9>,
    &setupGlut<10>,
    &setupGlut<11>,
    &setupGlut<12>,
    &setupGlut<13>,
    &setupGlut<14>,
    &setupGlut<15>,
    &setupGlut<16>,
    &setupGlut<17>,
    &setupGlut<18>,
    &setupGlut<19>,
    &setupGlut<20>,
    &setupGlut<21>,
    &setupGlut<22>,
    &setupGlut<23>,
    &setupGlut<24>,
    &setupGlut<25>,
    &setupGlut<26>,
    &setupGlut<27>,
    &setupGlut<28>,
    &setupGlut<29>,
    &setupGlut<30>,
    &setupGlut<31>
};

template <unsigned int instance>
void displayFunc();
static fpDisplayFunc _displayFunc[] =
{
    &displayFunc<0>,
    &displayFunc<1>,
    &displayFunc<2>,
    &displayFunc<3>,
    &displayFunc<4>,
    &displayFunc<5>,
    &displayFunc<6>,
    &displayFunc<7>,
    &displayFunc<8>,
    &displayFunc<9>,
    &displayFunc<10>,
    &displayFunc<11>,
    &displayFunc<12>,
    &displayFunc<13>,
    &displayFunc<14>,
    &displayFunc<15>,
    &displayFunc<16>,
    &displayFunc<17>,
    &displayFunc<18>,
    &displayFunc<19>,
    &displayFunc<20>,
    &displayFunc<21>,
    &displayFunc<22>,
    &displayFunc<23>,
    &displayFunc<24>,
    &displayFunc<25>,
    &displayFunc<26>,
    &displayFunc<27>,
    &displayFunc<28>,
    &displayFunc<29>,
    &displayFunc<30>,
    &displayFunc<31>
};

int getFreeSlot()
{
  int id = -1;
  for(int i=0; i<32; i++)
  {
    if(Obvious2D::_instance_map[i]==false)
    {
      id = i;
      break;
    }
  }
  return id;
}

template <unsigned int instance>
void onCloseEvent()
{
  Obvious2D* viewer = Obvious2D::_this[instance];
  viewer->terminate();
  if(glutGameModeGet(GLUT_GAME_MODE_ACTIVE)) glutLeaveGameMode();
}

template <unsigned int instance>
void onToggleScreen()
{
  Obvious2D* viewer = Obvious2D::_this[instance];
  viewer->toggleFullscreen();
}

// Custom keyboard handler for registered callback functions
template <unsigned int instance>
void onKeyboard(unsigned char key, int x, int y)
{
  Obvious2D* viewer = Obvious2D::_this[instance];
  viewer->processCallback(key);
}

// Resize handler
template <unsigned int instance>
void onChangeSize(GLsizei w, GLsizei h)
{
  Obvious2D* viewer = Obvious2D::_this[instance];
  viewer->setWidth(w);
  viewer->setHeight(h);
  glViewport(0, 0, w, h);
  _setupGlutSlot[instance]();
  glutPostRedisplay();
}

template <unsigned int instance>
void setupGlut()
{
  glDisable(GL_ALPHA_TEST);
  glDisable(GL_DEPTH_TEST);
  glDisable(GL_BLEND);
  glDisable(GL_DITHER);
  glDisable(GL_FOG);
  glDisable(GL_LIGHTING);
  glDisable(GL_LOGIC_OP);
  glDisable(GL_STENCIL_TEST);
  glDisable(GL_TEXTURE_1D);
  glDisable(GL_CULL_FACE);

  glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_CONTINUE_EXECUTION);
  //glutSetOption(GLUT_ACTION_ON_WINDOW_CLOSE, GLUT_ACTION_EXIT);

  glutCloseFunc (_onCloseEventSlot[instance]);
  glutKeyboardFunc(_onKeyboardSlot[instance]);
  glutReshapeFunc(_onChangeSizeSlot[instance]);
  glutDisplayFunc(_displayFunc[instance]);
}

template <unsigned int instance>
void displayFunc()
{
  glutPostRedisplay();
}

Obvious2D::Obvious2D(unsigned int width, unsigned int height, std::string title)
{
  char fake[]      = "dummy";
  char *fakeargv[] = { fake, NULL };
  int argc         = 1;
  _font = GLUT_BITMAP_8_BY_13;

  if(width==0 || height==0)
  {
    cout << "Obvious2D:: Wrong width and height passed" << endl;
    abort();
  }
  else if(Obvious2D::_is_glut_initialized==false)
  {
    glutInit(&argc, fakeargv);
    glutInitDisplayMode(GLUT_RGB | GLUT_DOUBLE | GLUT_DEPTH);
    Obvious2D::_is_glut_initialized = true;
  }

  int id = getFreeSlot();

  if(id==-1)
  {
    cout << "Obvious2D:: Maximum number of instances reached" << endl;
    abort();
  }

  glutInitWindowSize(width, height);
  glutInitWindowPosition(0, 0);
  _handle = glutCreateWindow(title.c_str());


  GLenum err = glewInit();
  if (GLEW_OK != err) {
      fprintf(stderr, "Error: %s\n", glewGetErrorString(err));
  }

  const GLubyte* version = glGetString(GL_VERSION);
  if (version) {
      std::cout << "OpenGL version: " << version << std::endl;  // TODO: Mark as debug
  }
  else {
      std::cerr << "Failed to get OpenGL version" << std::endl;
  }

  _instanceID = id;
  Obvious2D::_instance_map[_instanceID] = true;

  _fpsDisplay      = new optris::FramerateCounter(100);
  _fullscreen      = false;
  _screen_width    = glutGet(GLUT_SCREEN_WIDTH);
  _screen_height   = glutGet(GLUT_SCREEN_HEIGHT);
  _width           = width;
  _height          = height;
  _init_width      = _width;
  _init_height     = _height;
  _borderLeft      = 0;
  _borderRight     = 0;
  _borderTop       = 0;
  _borderBottom    = 0;
  _showHelp        = true;
  _showFPS         = true;
  _showSerial      = false;
  _showFlagState   = true;
  _flagState       = "?";

  TextStruct ts;
  ts.text = std::string("q: Quit");
  unsigned char green[4] = {0,   255,   0, 255};
  unsigned char black[4] = {0,   0,   0, 255};
  ts.rgba[0] = green[0];
  ts.rgba[1] = green[1];
  ts.rgba[2] = green[2];
  ts.rgba[3] = green[3];
  ts.rgbaBG[0] = black[0];
  ts.rgbaBG[1] = black[1];
  ts.rgbaBG[2] = black[2];
  ts.rgbaBG[3] = black[3];

  _colorCanvas = new unsigned char[4];
  _colorCanvas[0] = 0;
  _colorCanvas[0] = 0;
  _colorCanvas[0] = 255;
  _colorCanvas[0] = 160;

  // Add standard quit key 'q' to help text
   _mCallback['q'] = _onCloseEventSlot[_instanceID];
   _helpText.push_back(ts);
   // Register fullscreen toggle method
  _mCallback['f']  = _onToggleScreenSlot[_instanceID];
  ts.text = std::string("f: Toggle Fullscreen");
  _helpText.push_back(ts);

  Obvious2D::_this[_instanceID] = this;

  _setupGlutSlot[_instanceID]();
  glPixelZoom(1.0, -1.0);

  _isAlive = true;


  glClearColor (0.0, 0.0, 0.0, 0.0);
  glShadeModel(GL_FLAT);
  glEnable(GL_DEPTH_TEST);

  glPixelStorei(GL_UNPACK_ALIGNMENT, 1);

  glGenTextures(1, &_texture);
  glBindTexture(GL_TEXTURE_2D, _texture);

  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_NEAREST);
  glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_NEAREST);
}

Obvious2D::~Obvious2D()
{
  delete _colorCanvas;
  if (glutGameModeGet(GLUT_GAME_MODE_ACTIVE)) glutLeaveGameMode();
  glutDestroyWindow(_handle);
  Obvious2D::_instance_map[_instanceID] = false;
  delete _fpsDisplay;
  cout << "Destroy window" << endl;
}

unsigned int Obvious2D::getWidth() const
{
  return _width;
}

unsigned int Obvious2D::getHeight() const
{
  return _height;
}

void Obvious2D::setWidth(unsigned int width)
{
  _width = width;
}

void Obvious2D::setHeight(unsigned int height)
{
  _height = height;
}

unsigned int Obvious2D::getInitWidth() const
{
  return _init_width;
}

unsigned int Obvious2D::getInitHeight() const
{
  return _init_height;
}

unsigned int Obvious2D::getScreenWidth() const
{
  return _screen_width;
}

unsigned int Obvious2D::getScreenHeight() const
{
  return _screen_height;
}

bool Obvious2D::getFullscreen() const
{
  return _fullscreen;
}

void Obvious2D::setFullscreen(bool fullscreen)
{
  if(fullscreen)
  {
    setWidth(getScreenWidth());
    setHeight(getScreenHeight());
    glutReshapeWindow(getWidth(), getHeight());
    glutFullScreen();
    _fullscreen = true;
  }
  else
  {
    setWidth(getInitWidth());
    setHeight(getInitHeight());
    glutReshapeWindow(getWidth(), getHeight());
    _fullscreen = false;
  }

  _setupGlutSlot[_instanceID]();
}

void Obvious2D::resizeWindow(int newWidth, int newHeight) {
    _width = newWidth;
    _height = newHeight;
    glutReshapeWindow(newWidth, newHeight);
}

void Obvious2D::toggleFullscreen()
{
  setFullscreen(!getFullscreen());
}

void Obvious2D::setBorder(unsigned int pixelsLeft, unsigned int pixelsRight, unsigned int pixelsTop, unsigned int pixelsBottom)
{
  _borderLeft   = pixelsLeft;
  _borderRight  = pixelsRight;
  _borderTop    = pixelsTop;
  _borderBottom = pixelsBottom;
}

void Obvious2D::setFont(void* font)
{
  _font = font;
}

void Obvious2D::setShowHelp(bool showHelp)
{
  _showHelp = showHelp;
}

void Obvious2D::setShowFPS(bool showFPS)
{
  _showFPS = showFPS;
}

void Obvious2D::showSerialNum(bool showSerial, int serial)
{
  _showSerial = showSerial;
  _serial = serial;
}

void Obvious2D::drawHelp()  const
{
  float borderScaleHor  = (float)(_width - _borderLeft - _borderRight) / (float)_width;
  float borderScaleVert = (float)(_height - _borderTop - _borderBottom) / (float)_height;
  // float widthScaled     = (float)_width * borderScaleHor;
  // float heightScaled    = (float)_height * borderScaleVert;

  int maxTextLength = 0;
  std::ostringstream strs;
  strs << std::fixed << std::setprecision(1) << _fpsDisplay->getFps();
  std::string sText("Display: ");
  sText.append(strs.str());
  sText.append(" fps");
  if (_fpsSrc > 0.0)
  {
    sText.append("/ Src: ");
    std::ostringstream strs2;
    strs2 << std::fixed << std::setprecision(1) << _fpsSrc;
    sText.append(strs2.str());
    sText.append(" fps");
  }
  const char* textFPS = (const char*)sText.c_str();
  int lines = 0;

  stringstream numToString ;
  std::string serialNumber;

  numToString << _serial;
  numToString >> serialNumber;

  std::string textSerial("S/N: ");

  textSerial.append(serialNumber);
  const char* textShowSerial = (const char*)textSerial.c_str();

  std::string textFlagState("Flag State: ");
  textFlagState.append(_flagState);
  const char *textShowFlagState = (const char*)textFlagState.c_str();

  if (_showSerial)
  {
    lines++;
    maxTextLength = getBitmapLength(textFPS);
  }

  if (_showFPS)
  {
    lines++;
    maxTextLength = getBitmapLength(textFPS);
  }

  if (_showFlagState)
  {
    lines++;
    maxTextLength = getBitmapLength(textFPS);
  }

  if (_showHelp)
  {

    for (const auto& help : _helpText)
    {
      int textLength = getBitmapLength(help.text.c_str());
      if (textLength>maxTextLength) 
      {
        maxTextLength = textLength;
      }
    }

    lines += static_cast<int>(_helpText.size());
  }

  int fontHeight = glutBitmapHeight(_font);
  int fontBorder = fontHeight/4;

  int borderTotal = 2*fontBorder;
  int lineHeight = fontHeight + borderTotal;

  // unsigned int textHeight = lineHeight;

  int xpos = _width - maxTextLength;
  if(xpos<0) xpos = 0;

  int posX = static_cast<int>((float)xpos * borderScaleHor + _borderLeft - borderTotal);
  int posY = static_cast<int>((float)(_height) * borderScaleVert - lineHeight + fontBorder + _borderBottom);

  int minX = posX - fontBorder;
  int maxX = static_cast<int>(posX + maxTextLength * borderScaleHor + fontBorder);
  int maxY = posY + lineHeight - borderTotal;
  int minY = maxY - lines * lineHeight;

  drawTextBackground(minX, maxX, minY, maxY, _colorCanvas);

  if (_showFPS)
  {
    // int wText = glutBitmapLength(_font, (const unsigned char*)textFPS);
    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*)textFPS);

    glColor4ub(BLACK[0], BLACK[1], BLACK[2], BLACK[3]);
    glWindowPos2i(posX-1, posY);
    glutBitmapString(_font, (const unsigned char*)textFPS);
    glWindowPos2i(posX+1, posY);
    glutBitmapString(_font, (const unsigned char*)textFPS);
    glWindowPos2i(posX, posY-1);
    glutBitmapString(_font, (const unsigned char*)textFPS);
    glWindowPos2i(posX, posY+1);
    glutBitmapString(_font, (const unsigned char*)textFPS);

    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*)textFPS);
    posY -= lineHeight;
  }

  if (_showFlagState)
  {
    // int wText = glutBitmapLength(_font, (const unsigned char*) textShowSerial);
    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);

    glColor4ub(BLACK[0], BLACK[1], BLACK[2], BLACK[3]);
    glWindowPos2i(posX-1, posY);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);
    glWindowPos2i(posX+1, posY);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);
    glWindowPos2i(posX, posY-1);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);
    glWindowPos2i(posX, posY+1);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);

    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*) textShowFlagState);
    posY -= lineHeight;
  }

  if (_showSerial)
  {
    // int wText = glutBitmapLength(_font, (const unsigned char*) textShowSerial);
    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);

    glColor4ub(BLACK[0], BLACK[1], BLACK[2], BLACK[3]);
    glWindowPos2i(posX-1, posY);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);
    glWindowPos2i(posX+1, posY);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);
    glWindowPos2i(posX, posY-1);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);
    glWindowPos2i(posX, posY+1);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);

    glColor4ub(GREEN[0], GREEN[1], GREEN[2], GREEN[3]);
    glWindowPos2i(posX, posY);
    glutBitmapString(_font, (const unsigned char*) textShowSerial);
    posY -= lineHeight;
  }

  // Draw help text
  if (_showHelp)
  {
    for (const auto& help : _helpText)
    {
      if (help.text.length()>0)
      {
        const auto* text = (const unsigned char*)help.text.c_str();

        // Shift text: 1 pixel in each direction to draw background
        glColor4ub(help.rgbaBG[0], help.rgbaBG[1], help.rgbaBG[2], help.rgbaBG[3]);
        glWindowPos2i(posX-1, posY);
        glutBitmapString(_font, text);
        glWindowPos2i(posX+1, posY);
        glutBitmapString(_font, text);
        glWindowPos2i(posX, posY-1);
        glutBitmapString(_font, text);
        glWindowPos2i(posX, posY+1);
        glutBitmapString(_font, text);

        glColor4ub(help.rgba[0], help.rgba[1], help.rgba[2], help.rgba[3]);
        glWindowPos2i(posX, posY);
        glutBitmapString(_font, text);

        posY -= lineHeight;
      }
    }
  }
}

void Obvious2D::drawInfo() const
{
  int lines = static_cast<int>(_infoText.size());

  if(lines==0) return;

  float borderScaleHor  = (float)(_width - _borderLeft - _borderRight) / (float)_width;
  // float borderScaleVert = (float)(_height - _borderTop - _borderBottom) / (float)_height;
  // float widthScaled     = (float)_width * borderScaleHor;
  // float heightScaled    = (float)_height * borderScaleVert;

  int maxTextLength = 0;
  for(const auto& info : _infoText)
  {
    int textLength = getBitmapLength(info.text.c_str());
    if(textLength>maxTextLength) maxTextLength = textLength;
  }

  int fontHeight = glutBitmapHeight(_font);
  int fontBorder = fontHeight/4;

  int borderTotal = 2*fontBorder;
  int lineHeight = fontHeight + borderTotal;

  int posX = _borderLeft + borderTotal;
  int posY = (lines - 1) * lineHeight + _borderBottom + borderTotal;

  int minX = posX - fontBorder;
  int maxX = static_cast<int>(posX + maxTextLength * borderScaleHor + fontBorder);
  int maxY = posY + fontHeight - fontBorder;// + hBoxBorder;
  int minY = posY - (lines-1) * lineHeight - fontBorder;

  drawTextBackground(minX, maxX, minY, maxY, _colorCanvas);

  // Draw info text
  for (const auto& info : _infoText)
  {
    if (info.text.length()>0)
    {

      glColor4ub(info.rgbaBG[0], info.rgbaBG[1], info.rgbaBG[2], info.rgbaBG[3]);

      // Draw progress bar
      float fMinX =  2.F * ((float)minX /(float)_width) - 1.F;
      float fMaxX =  2.F * ((float)(minX+(maxX-minX)*info.progress) /(float)_width) - 1.F;
      float fMinY =  2.F * ((float)(posY- fontBorder) /(float)_height) - 1.F;
      float fMaxY =  2.F * ((float)(posY+(lineHeight+fontBorder)/2.0) /(float)_height) - 1.F;
      glBegin(GL_POLYGON);
          glVertex2f(fMinX, fMinY);
          glVertex2f(fMaxX, fMinY);
          glVertex2f(fMaxX, fMaxY);
          glVertex2f(fMinX, fMaxY);
      glEnd();

      const auto* text = (const unsigned char*)info.text.c_str();
      // Shift text: 1 pixel in each direction to draw background
      glWindowPos2i(posX-1, posY);
      glutBitmapString(_font, text);
      glWindowPos2i(posX+1, posY);
      glutBitmapString(_font, text);
      glWindowPos2i(posX, posY-1);
      glutBitmapString(_font, text);
      glWindowPos2i(posX, posY+1);
      glutBitmapString(_font, text);

      glColor4ub(info.rgba[0], info.rgba[1], info.rgba[2], info.rgba[3]);
      glWindowPos2i(posX, posY);
      glutBitmapString(_font, text);

      posY -= lineHeight;
    }
  }
}

void Obvious2D::drawPopup() const
{
  int lines = static_cast<int>(_popupText.size());

  if(lines==0) return;

  float borderScaleHor  = (float)(_width - _borderLeft - _borderRight) / (float)_width;
  // float borderScaleVert = (float)(_height - _borderTop - _borderBottom) / (float)_height;
  float widthScaled     = (float)_width * borderScaleHor;
  // float heightScaled    = (float)_height * borderScaleVert;

  // int maxTextLength = getBitmapLength(_popupText[0].text.c_str());

  // glutBitmapHeight: font height is inter-line spacing and does not relate to the real font height, thus we set it to a fixed value
  float fontHeight = static_cast<float>(getBitmapHeight());
  float fontBorder = fontHeight/4;

  float borderTotal = 2*fontBorder;
  // float lineHeight = fontHeight + borderTotal;

  float posX = _borderLeft + borderTotal;
  float posY = borderTotal + _borderBottom + 1 + 3;
  float minX = posX - fontBorder;
  float maxX = widthScaled - fontBorder + _borderLeft;
  float maxY = posY + fontHeight + fontBorder + 1;
  float minY = posY - fontBorder - 1 - 2;

  drawTextBackground(static_cast<int>(minX - 3), static_cast<int>(maxX + 3), static_cast<int>(minY - 2), static_cast<int>(maxY + 4), WHITE);

  // Draw info text
  if (_popupText[0].text.length()>0)
  {
    glColor4ub(_popupText[0].rgbaBG[0], _popupText[0].rgbaBG[1], _popupText[0].rgbaBG[2], _popupText[0].rgbaBG[3]);

    // Draw progress bar
    float fMinX =  2.F * ((float)minX /(float)_width) - 1.F;
    float fMaxX =  2.F * ((float)(minX+(maxX-minX)*_popupText[0].progress) /(float)_width) - 1.F;
    float fMinY =  2.F * ((float)(minY) /(float)_height) - 1.F;
    float fMaxY =  2.F * ((float)(maxY) /(float)_height) - 1.F;

    glBegin(GL_POLYGON);
        glVertex2f(fMinX, fMinY);
        glVertex2f(fMaxX, fMinY);
        glVertex2f(fMaxX, fMaxY);
        glVertex2f(fMinX, fMaxY);
    glEnd();


    const auto* text = (const unsigned char*)_popupText[0].text.c_str();
    // Shift text: 1 pixel in each direction to draw background
    glWindowPos2i(static_cast<int>(posX  -1), static_cast<int>(posY));
    glutBitmapString(_font, text);
    glWindowPos2i(static_cast<int>(posX + 1), static_cast<int>(posY));
    glutBitmapString(_font, text);
    glWindowPos2i(static_cast<int>(posX), static_cast<int>(posY - 1));
    glutBitmapString(_font, text);
    glWindowPos2i(static_cast<int>(posX), static_cast<int>(posY + 1));
    glutBitmapString(_font, text);

    glColor4ub(_popupText[0].rgba[0], _popupText[0].rgba[1], _popupText[0].rgba[2], _popupText[0].rgba[3]);
    glWindowPos2i(static_cast<int>(posX), static_cast<int>(posY));
    glutBitmapString(_font, text);
  }
}

void Obvious2D::drawTextBackground(int minX, int maxX, int minY, int maxY, const unsigned char color[4]) const
{
  float fMinX =  2.F * ((float)minX /(float)_width) - 1.F;
  float fMaxX =  2.F * ((float)maxX /(float)_width) - 1.F;
  float fMinY =  2.F * ((float)minY /(float)_height) - 1.F;
  float fMaxY =  2.F * ((float)maxY /(float)_height) - 1.F;

  // Draw background of text
  glColor4ub(color[0], color[1], color[2], color[3]);
  glBegin(GL_POLYGON);
    glVertex2f(fMinX, fMinY);
    glVertex2f(fMaxX, fMinY);
    glVertex2f(fMaxX, fMaxY);
    glVertex2f(fMinX, fMaxY);
  glEnd();
}

bool Obvious2D::isAlive() const
{
  return _isAlive;
}

void Obvious2D::terminate()
{
  _isAlive = false;
}

int Obvious2D::getBitmapLength(const char* text) const
{
  float borderScaleHor = (float)(_width - _borderLeft - _borderRight) / (float)_width;
  float l = static_cast<float>(glutBitmapLength(_font, (const unsigned char*)text));
  return (int)(l/borderScaleHor + .5f);
}

int Obvious2D::getBitmapHeight() const
{
  float borderScaleVert = (float)(_height - _borderTop - _borderBottom) / (float)_height;
  float h = static_cast<float>(glutBitmapHeight(_font));
  return (int)(h / borderScaleVert + .5f);
}

void Obvious2D::draw(const unsigned char* image, 
                     unsigned int         width, 
                     unsigned int         height, 
                     unsigned int         channels, 
                     const std::string&   flagState,
                     double               fpsSrc)
{
  if (!_isAlive) 
  {
    return;
  }

  float pixelWidth      = 2.F/(float)_width;
  float pixelHeight     = 2.F/(float)_height;
  float borderLeft      = (float)_borderLeft * pixelWidth;
  float borderRight     = (float)_borderRight * pixelWidth;
  float borderTop       = (float)_borderTop * pixelHeight;
  float borderBottom    = (float)_borderBottom * pixelHeight;
  float borderScaleHor  = (float)(_width - _borderLeft - _borderRight) / (float)_width;
  float borderScaleVert = (float)(_height - _borderTop - _borderBottom) / (float)_height;

  std::lock_guard<std::mutex> lock(_mutex);
  glutSetWindow(_handle);

  glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

  if(channels==1)
  {
    //glDrawPixels(width, height, GL_LUMINANCE,GL_UNSIGNED_BYTE, image);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_LUMINANCE, width, height, 0, GL_LUMINANCE, GL_UNSIGNED_BYTE, image);
  }
  else if(channels==3)
  {
    //glDrawPixels(width, height, GL_RGB,GL_UNSIGNED_BYTE, image);
    #ifdef _WIN32
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_BGR, GL_UNSIGNED_BYTE, image);   // DirectShow (WIN) uses BGR 
    #else
      glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);   // UVC (Linux) uses RGB
    #endif
  }
  else
  {
    cout << "WARNING: draw method not implemented for channels=" << channels << endl;
    return;
  }

  _fpsDisplay->trigger();
  _fpsSrc = fpsSrc;

  _flagState = flagState;

  glEnable(GL_TEXTURE_2D);
  glTexEnvf(GL_TEXTURE_ENV, GL_TEXTURE_ENV_MODE, GL_REPLACE);
  glBindTexture(GL_TEXTURE_2D, _texture);
  glBegin(GL_QUADS);
  glTexCoord2f(0.0, 0.0); glVertex3f(-1.0F + borderLeft,   1.0F - borderTop,    0.0);
  glTexCoord2f(0.0, 1.0); glVertex3f(-1.0F + borderLeft,  -1.0F + borderBottom, 0.0);
  glTexCoord2f(1.0, 1.0); glVertex3f( 1.0F - borderRight, -1.0F + borderBottom, 0.0);
  glTexCoord2f(1.0, 0.0); glVertex3f( 1.0F - borderRight,  1.0F - borderTop,    0.0);
  glEnd();
  glDisable(GL_TEXTURE_2D);

  // Flip vertically for correct text display
  float ratioW = 1.001F*(float)_width/width;
  float ratioH = 1.001F*(float)_height/height;
  glPixelZoom(ratioW, ratioH);

  glEnable(GL_BLEND);
  glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
  glEnable( GL_LINE_SMOOTH );
  glPolygonMode(GL_FRONT_AND_BACK, GL_QUADS);

  drawHelp();
  drawPopup();

  if(_popupText.size()==0)
  {
    drawInfo();
  }

  float lineWidth = 1.5f;
  if(_width>320) lineWidth = 2.0f;
  if(_width>640) lineWidth = 2.5f;

  // float crossScale = (float)1920 / (float)_width;
  // float ratio = (float)_width/(float)_height;
  for (std::size_t j=0; j<_crosshairs.size(); j++)
  {
    CrossHair c = _crosshairs[j];
    float radiusW = c.radius*pixelWidth;
    float radiusH = c.radius*pixelHeight;
    float centerX = (((float)c.col)*pixelWidth) * borderScaleHor - 1.F + borderLeft;
    float centerY = (((float)c.row)*pixelHeight) * borderScaleVert  - 1.F + borderBottom;

    glColor4ub(c.rgbaBG[0], c.rgbaBG[1], c.rgbaBG[2], c.rgbaBG[3]);
    float lwFactor = 2.F;
    glLineWidth(lwFactor*lineWidth);
    glBegin(GL_LINES);
    float xLeft   = centerX-radiusW;
    float xRight  = centerX+radiusW;
    float yTop    = centerY+radiusH;
    float yBottom = centerY-radiusH;
    float dXSpot  = 3.F*pixelWidth;
    float dYSpot  = 3.F*pixelHeight;
    // left line
    glVertex2f(xLeft, centerY);
    glVertex2f(centerX-dXSpot, centerY);
    // right line
    glVertex2f(centerX+dXSpot, centerY);
    glVertex2f(xRight, centerY);
    // bottom line
    glVertex2f(centerX, yBottom);
    glVertex2f(centerX, centerY-dYSpot);
    // top line
    glVertex2f(centerX, centerY+dYSpot);
    glVertex2f(centerX, yTop);
    glEnd();

    const unsigned char* text = (const unsigned char*) c.text.c_str();
    int wText = glutBitmapLength(_font, text);
    int hText = glutBitmapHeight(_font);
    float offsetW = c.offset;
    float offsetH = c.offset;
    if(offsetW > 0.F)
      if(c.col>(_width-offsetW-wText)) offsetW = (-offsetW-wText);
    if(offsetH > 0.F)
      if(c.row>(_height-offsetH-hText)) offsetH = (-offsetH-hText);

    int posX = static_cast<int>((float)(c.col+offsetW) * borderScaleHor + _borderLeft);
    int posY = static_cast<int>((float)(c.row+offsetH) * borderScaleVert + _borderBottom);

    glWindowPos2i(posX-1, posY);
    glutBitmapString(_font, text);
    glWindowPos2i(posX+1, posY);
    glutBitmapString(_font, text);
    glWindowPos2i(posX, posY-1);
    glutBitmapString(_font, text);
    glWindowPos2i(posX, posY+1);
    glutBitmapString(_font, text);

    glColor4ub(c.rgba[0], c.rgba[1], c.rgba[2], c.rgba[3]);
    glLineWidth(lineWidth);
    glBegin(GL_LINES);
    // left line
    glVertex2f(xLeft, centerY);
    glVertex2f(centerX-dXSpot, centerY);
    // right line
    glVertex2f(centerX+dXSpot, centerY);
    glVertex2f(xRight, centerY);
    // bottom line
    glVertex2f(centerX, yBottom);
    glVertex2f(centerX, centerY-dYSpot);
    // top line
    glVertex2f(centerX, centerY+dYSpot);
    glVertex2f(centerX, yTop);
    glEnd();

    glWindowPos2i(posX, posY);
    glutBitmapString(_font, text);
  }

  glDisable(GL_BLEND);

  glutSwapBuffers();
  glutMainLoopEvent();

  _crosshairs.clear();
  _infoText.clear();
  _popupText.clear();

}

void Obvious2D::registerKeyboardCallback(char                 key, 
                                         fptrKeyboardCallback callback, 
                                         const std::string&   helpText, 
                                         const unsigned char  rgba[4], 
                                         const unsigned char  rgbaBG[4])
{
  _mCallback[key] = callback;

  TextStruct ts;
  ts.text = key;
  ts.text.append(": ");
  ts.text.append(helpText);

  ts.rgba[0] = rgba[0];
  ts.rgba[1] = rgba[1];
  ts.rgba[2] = rgba[2];
  ts.rgba[3] = rgba[3];

  ts.rgbaBG[0] = rgbaBG[0];
  ts.rgbaBG[1] = rgbaBG[1];
  ts.rgbaBG[2] = rgbaBG[2];
  ts.rgbaBG[3] = rgbaBG[3];

  _helpText.push_back(ts);
}

void Obvious2D::registerKeyboardClient(char                key, 
                                       Obvious2DClient*    client,
                                       const std::string&  helpText, 
                                       const unsigned char rgba[4],
                                       const unsigned char rgbaBG[4])
{
  _mClient[key] = client;

  TextStruct ts;
  ts.text = key;
  ts.text.append(": ");
  ts.text.append(helpText);

  ts.rgba[0] = rgba[0];
  ts.rgba[1] = rgba[1];
  ts.rgba[2] = rgba[2];
  ts.rgba[3] = rgba[3];

  ts.rgbaBG[0] = rgbaBG[0];
  ts.rgbaBG[1] = rgbaBG[1];
  ts.rgbaBG[2] = rgbaBG[2];
  ts.rgbaBG[3] = rgbaBG[3];

  _helpText.push_back(ts);
}

void Obvious2D::addCrosshair(unsigned int        x, 
                             unsigned int        y, 
                             const std::string&  text, 
                             const unsigned char rgba[4],
                             const unsigned char rgbaBG[4], 
                             float               radius, 
                             float               offset)
{
  CrossHair c;
  c.text = text;
  c.radius = radius;
  c.col = x;
  c.row = y;
  c.rgba[0] = rgba[0];
  c.rgba[1] = rgba[1];
  c.rgba[2] = rgba[2];
  c.rgba[3] = rgba[3];
  c.rgbaBG[0] = rgbaBG[0];
  c.rgbaBG[1] = rgbaBG[1];
  c.rgbaBG[2] = rgbaBG[2];
  c.rgbaBG[3] = rgbaBG[3];
  c.offset = offset;
  _crosshairs.push_back(c);
}

void Obvious2D::addVolatileInfoText(const std::string&  text, 
                                    const unsigned char rgba[4], 
                                    const unsigned char rgbaBG[4], 
                                    double              progress, 
                                    bool                popup)
{
  TextStruct ts;
  ts.text = text;

  ts.rgba[0] = rgba[0];
  ts.rgba[1] = rgba[1];
  ts.rgba[2] = rgba[2];
  ts.rgba[3] = rgba[3];

  if(rgbaBG)
  {
    ts.rgbaBG[0] = rgbaBG[0];
    ts.rgbaBG[1] = rgbaBG[1];
    ts.rgbaBG[2] = rgbaBG[2];
    ts.rgbaBG[3] = rgbaBG[3];
  }
  else
  {
    ts.rgbaBG[0] = 0;
    ts.rgbaBG[1] = 0;
    ts.rgbaBG[2] = 0;
    ts.rgbaBG[3] = 0;
  }

  if(progress<0.0) progress=0.0;
  if(progress>1.0) progress=1.0;

  ts.progress = progress;

  if(popup)
    _popupText.push_back(ts);
  else
    _infoText.push_back(ts);
}

void Obvious2D::clearVolatileInfoText()
{
  _infoText.clear();
  _popupText.clear();
}

void Obvious2D::setColorCanvas(const unsigned char color[4])
{
  memcpy(_colorCanvas, color, 4*sizeof(unsigned char));
}

void Obvious2D::processCallback(char key)
{
  fptrKeyboardCallback fptr = _mCallback[key];
    if(fptr!=nullptr)(*fptr)();
  Obvious2DClient* client = _mClient[key];
    if(client!=nullptr) client->keyboardCallback(key);
}
