// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;
using Optris.OtcSDK;
using SimpleViewCS.models;

namespace SimpleViewCS
{
    /// <summary>Main windows of the application.</summary>
    public partial class DisplayForm : Form
    {
        private IRImagerShow imagerShow = new();
        private System.Windows.Forms.Timer uiUpdateTimer = new();


        /// <summary>Constructor.</summary>
        public DisplayForm()
        {
            InitializeComponent();
        }

        /// <summary>Connects to the device specified in the configuration file.</summary>
        /// 
        /// <param name="filename">path to the configuration file of the device to connect to.</param>
        private void Connect(string filename)
        {
            try
            {
                uiUpdateTimer.Stop();

                imagerShow.Disconnect();
                imagerShow.Connect(filename);

                Text = "Optris Imager - " + imagerShow.GetDeviceType() + " (S/N " + imagerShow.GetSerialNumber().ToString() + ")";

                sbStatus.Text = "Connected.";
                sbFlag.Text = imagerShow.GetFlagState();

                uiUpdateTimer.Tick += new EventHandler(UpdateUI);
                uiUpdateTimer.Interval = 1;
                uiUpdateTimer.Start();
            }
            catch (SDKException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>Quickly connects to the first detected device on the USB port.</summary>
        private void QuickConnect()
        {
            try
            {
                uiUpdateTimer.Stop();

                imagerShow.Disconnect();
                imagerShow.QuickConnect();

                Text = "Optris Imager - " + imagerShow.GetDeviceType() + " (S/N " + imagerShow.GetSerialNumber().ToString() + ")";

                sbStatus.Text = "Connected.";
                sbFlag.Text = imagerShow.GetFlagState();

                uiUpdateTimer.Tick += new EventHandler(UpdateUI);
                uiUpdateTimer.Interval = 1;
                uiUpdateTimer.Start();
            }
            catch (SDKException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>Opens a file dialog to choose the configuration file of the device to connect to and starts the connection.</summary>
        private void ConnectWithConfigSelection()
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Please select the configuration file of the device to connect to...";
            openFileDialog.Filter = "XML configuration files (*.xml)|*.xml|All files (*.*)|*.*";
            openFileDialog.Multiselect = false;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                Connect(openFileDialog.FileName);
            }
        }

        /// <summary>Disconnects form the currently connected device.</summary>
        private void Disconnect()
        {
            if (!imagerShow.IsConnected)
            {
                return;
            }

            imagerShow.Disconnect();
            uiUpdateTimer.Stop();

            Text = "Optris Imager";
            sbStatus.Text = "Disconnected.";
            sbFlag.Text = "                  ";
            sbFPS.Text = "                  ";

            pictureBox.Image = null;
            pictureBox.Invalidate();
        }

        /// <summary>Callback of the UI update timer.</summary>
        private void UpdateUI(object? sender, EventArgs e)
        {
            if (!imagerShow.IsConnected || imagerShow.IsConnectionLost)
            {
                Disconnect();
                return;
            }

            sbFlag.Text = imagerShow.GetFlagState();
            sbFPS.Text = imagerShow.GetFPS().ToString() + " Hz";

            Bitmap? image = imagerShow.GetImage();

            if (image != null)
            {
                pictureBox.Image = image;
                pictureBox.Invalidate();
            }
        }


        /// <summary>Action called when the quick connect menu entry is clicked.</summary>
        private void miDeviceQuickConnect_Click(object sender, EventArgs e)
        {
            QuickConnect();
        }

        /// <summary>Action called when the connect menu entry is clicked.</summary>
        private void miDeviceConnect_Click(object? sender, EventArgs e)
        {
            ConnectWithConfigSelection();
        }

        /// <summary>Action called when the disconnect menu entry is clicked.</summary>
        private void miDeviceDisconnect_Click(object? sender, EventArgs e)
        {
            Disconnect();
        }

        /// <summary>Action called when the refresh flag menu entry is clicked.</summary>
        private void miDeviceRefreshFlag_Click(object sender, EventArgs e)
        {
            imagerShow.RefreshFlag();
        }

        /// <summary>Action called when the quit menu entry is clicked.</summary>
        private void msFileQuit_Click(object? sender, EventArgs e)
        {
            Disconnect();
            Application.Exit();
        }

        /// <summary>Action called prior to closing the window.</summary>
        private void DisplayForm_FormClosing(object? sender, FormClosingEventArgs e)
        {
            Disconnect();
        }
    }
}
