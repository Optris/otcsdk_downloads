// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using Optris.OtcSDK;


namespace SimpleViewCS
{
    internal static class Program
    {
        /// <summary>Program main entry point.</summary>
        [STAThread]
        static void Main()
        {
            // To customize application configuration such as set high DPI settings or default font,
            // see https://aka.ms/applicationconfiguration.
            ApplicationConfiguration.Initialize();

            // Initialize the SDK by setting log verbosity
            Sdk.init(Verbosity.Off, Verbosity.Off, "SimpleViewCS");

            try
            {
                Application.Run(new DisplayForm());
            }
            catch (SDKException ex)
            {
                MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}