// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    SimpleImagerClientPif.cpp
 * @author  Optris GmbH & Co. KG
 * @brief   Implementations of the main class for the minimal example.
 *          
 * @date 2025-03-31 
 */

#include "SimpleImagerClientPif.h"

#include <iostream>
#include <iomanip>
#include <sstream>

#include "otcsdk/IRImagerFactory.h"


SimpleImagerClientPif::SimpleImagerClientPif(unsigned long serialNumber)
  /*
   * The factory is implemented as a Singleton. Therefore, you have to call getInstance()
   * first before you can create an IRImager object.
   *
   * The native implementation allows you to access the thermal data of cameras connected
   * via USB or Ethernet.
   */
  : _delayOutput{true}
  , _imager{optris::IRImagerFactory::getInstance().create("native")}
{
  /*
   * Register this instance as a client/observer with the IRImager implementation to
   * receive updates on thermal data and more.
   */
  _imager->addClient(this);

  // Establishes a connection to the camera.
  _imager->connect(serialNumber);
}


void SimpleImagerClientPif::configurePif()
{
  // Get the PIF interface (reference only valid during an active camera connection)
  optris::ProcessInterface& pif = _imager->getPif();


  // Tip: You can change the PIF device type and count at runtime like this:
  // optris::PifConfig pifConfig = pif.getConfig(); // Preserves the existing PIF channel configurations. Create new object to reset them.

  // pifConfig.deviceType  = optris::PifDeviceType::Stackable;
  // pifConfig.deviceCount = 1;

  // pif.setConfig(pifConfig);


  // Get the type of connected PIF
  // Returns the type of the PIF that is really connected to the camera
  // Autonomous Cameras (Xi80, Xi 410, Xi 1M): Returns the type that is stored in the config on the camera
  optris::PifDeviceType pifType = pif.getDeviceType();
  std::cout << "\n" << pifType << " PIF\n\n";

  std::cout << pif.getConfigurableDeviceCount() << " configurable device(s), " << pif.getActualDeviceCount() << " are actually connected.\n\n";

  // Check, if connected PIF has a dedicated fail save channel
  std::string hasFailSave = pif.hasFs() ? "Yes" : "No";

  std::cout << std::setw(15) << std::left << "AVAILABILITY"
            << std::setw(6) << std::left << "AI"
            << std::setw(6) << std::left << "AO"
            << std::setw(6) << std::left << "DI"
            << std::setw(6) << std::left << "DO"
            << std::setw(6) << std::left << "FS" << std::endl;

  // Check number of actual available inputs and outputs
  std::cout << std::setw(15) << std::left << "Actual"
            << std::setw(6) << std::left << pif.getActualAiCount()
            << std::setw(6) << std::left << pif.getActualAoCount()
            << std::setw(6) << std::left << pif.getActualDiCount()
            << std::setw(6) << std::left << pif.getActualDoCount()
            << std::setw(6) << std::left << hasFailSave << "\n";

  // Check number of configurable inputs and outputs
  std::cout << std::setw(15) << std::left << "Configurable"
            << std::setw(6) << std::left << pif.getConfigurableAiCount()
            << std::setw(6) << std::left << pif.getConfigurableAoCount()
            << std::setw(6) << std::left << pif.getConfigurableDiCount()
            << std::setw(6) << std::left << pif.getConfigurableDoCount()
            << std::setw(6) << std::left << hasFailSave << "\n\n\n";


  // This example configures the first channel (AO, AI, ...) of the first PIF device 
  std::cout << "Configuring Channels\n\n";
  const int deviceIndex = 0;
  const int pinIndex    = 0;

  // Configure an AI channel
  std::cout << "AI" << deviceIndex + 1 << "." << pinIndex + 1 << ": ";
  if (pif.getConfigurableAiCount() >= 1) 
  {
    std::cout << "Set to \"Uncommitted Value\"." << std::endl;

    // Sets the AI to "Uncommitted Value" mode.
    // The converted input values (depending on gain/offset) will be available via the onPifUncommittedValue() callback function
    pif.setAiConfig(optris::PifAiConfig::createUncommittedValue(deviceIndex, 
                                                                pinIndex,
                                                                "Pressure Sensor",
                                                                "Pa", 
                                                                0.1F, 
                                                                0.0F));
  }
  else 
  {
    std::cout << "Not available." << std::endl;
  }

  // Configure an AO channel
  std::cout << "AO" << deviceIndex + 1 << "." << pinIndex + 1 << ": ";
  if (pif.getConfigurableAoCount() >= 1) 
  {
    std::cout << "Set to \"Internal Temperature\"." << std::endl;

    // Get the default analog output mode (0..10 V or 0..20 mA/4..20 mA) dependent on the connected device
    optris::PifAoOutputMode outputMode = pif.getDefaultAoOutputMode();

    // Sets the AO to "Internal Temperature" mode
    pif.setAoConfig(optris::PifAoConfig::createInternalTemperature(deviceIndex, 
                                                                   pinIndex, 
                                                                   outputMode, 
                                                                   0.1F, 
                                                                   0.0F));
  }
  else 
  {
    std::cout << "Not available." << std::endl;
  }


  // Configure a DI channel
  std::cout << "DI" << deviceIndex + 1 << "." << pinIndex + 1 << ": ";
  if (pif.getConfigurableDiCount() >= 1) 
  {
    std::cout << "Set to \"Flag Control\"." << std::endl;

    // Sets the DI to "Flag Control" mode
    // The flag therefore cycles when the input switches between high and low
    pif.setDiConfig(optris::PifDiConfig::createFlagControl(deviceIndex, pinIndex, true));
  }
  else 
  {
    std::cout << "Not available." << std::endl;
  }


  // Configure a DO channel
  std::cout << "DO" << deviceIndex + 1 << "." << pinIndex + 1 <<": ";
  if (pif.getConfigurableDoCount() >= 1) 
  {
    std::cout << "Set to \"External Communication\"." << std::endl;

    // Sets the DO to "External Communication" which enables the user to control the value of the output
    pif.setDoConfig(optris::PifDoConfig::createExternalCommunication(deviceIndex, pinIndex));

    // Set the output to a value
    pif.setDoValue(deviceIndex, pinIndex, true);
  }
  else 
  {
    std::cout << "Not available." << std::endl;
  }


  // Configure the FS channel
  std::cout << "FS   : ";
  if (pif.hasFs()) 
  {
    std::cout << "Set to \"On\"." << std::endl;

    // Activates the fail safe channel 
    pif.setFsConfig(optris::PifFsConfig::createOn());
  }
  else 
  {
    std::cout << "Not available." << std::endl;
  }

  std::cout << "\n\nPIF output is delayed for " << DELAY_TIME.count()  << " seconds ..." << std::endl;
  _configurationFinished = Clock::now();

  std::cout << "\n" << std::endl;
}


void SimpleImagerClientPif::run()
{
  /*
   * Run the imager synchronously (the run() method will block).
   *
   * As an alternative, the imager can be run asynchronously with the runAsync()
   * method. In this case the callbacks will be triggered from a separate
   * thread.
   */ 
   _imager->run();
}


void SimpleImagerClientPif::onThermalFrame(const optris::ThermalFrame& thermal, const optris::FrameMetadata& meta)
{
  // Get indices of available PIF inputs
  const int pifDeviceCount = meta.getPifActualDeviceCount();
  const int pifAiCount     = meta.getPifAiCountPerDevice();
  const int pifDiCount     = meta.getPifDiCountPerDevice();

  // For readability: Delays output of PIF-input values by DELAY_TIME seconds
  auto now = Clock::now();

  if (_delayOutput)
  {
    if (now - _configurationFinished < DELAY_TIME) 
    {
      return;
    }
    _delayOutput = false;
    _lastOutput  = now;
  }

  // For readability: Throttles output of PIF-input values to every OUTPUT_INTERVAL seconds
  if (now - _lastOutput < OUTPUT_INTERVAL)
  {
    return;  
  }
  _lastOutput = now;

  // Access the PIF input values directly
  try 
  {
    for (int deviceIndex = 0; deviceIndex < pifDeviceCount; deviceIndex++)
    {
      std::cout << "PIF Device " << deviceIndex +1 << "\n";

      // Analog inputs (voltages as float)
      for (int pinIndex = 0; pinIndex < pifAiCount; pinIndex++)
      {
        std::cout << "- AI" << deviceIndex + 1 << "." << pinIndex + 1 << " Value: " << meta.getPifAiValue(deviceIndex, pinIndex) << " V" << "\n";
      }

      // Digital inputs (boolean)
      for (int pinIndex = 0; pinIndex < pifDiCount; pinIndex++)
      {
        std::cout << "- DI" << deviceIndex + 1 << "." << pinIndex + 1 << " Value: " << meta.getPifDiValue(deviceIndex, pinIndex) << "\n";
      }
    }
  } 
  catch (const optris::SDKException &ex) 
  {
    std::cout << "Failed to get PIF input value: " << ex.what() <<std::endl;
  }

  std::cout << std::endl;
}


void SimpleImagerClientPif::onFlagStateChange(optris::FlagState flagState)
{
  std::cout << "Flag state: " << flagState << "\n"
            << std::endl;
}


void SimpleImagerClientPif::onPifUncommittedValue(const std::string& name, const std::string& unit, float value)
{
  std::cout << name << ": " << value << " " << unit << "\n"
            << std::endl;
}