# C++ Examples

Examples for the native C++ interface of the Thermal Camera SDK.


## Dependencies
### Linux
If you installed the SDK Debian package with the help of the `apt install` command, the package manager `apt` has already installed the basic tools
and libraries you need to compile the SDK. They include

  - `GCC` with the C++ front end
  - `CMake` for generating the build files
  - `libudev-dev`
  - `libusb-1.0-0-dev`
  - `libuvc-dev`

On Windows you have three options: 

  - Use Visual Studio as editor and build system
  - Use Visual Studio as editor and `CMake` as build system
  - Use a different editor like Visual Studio Code with `CMake` as build system

No matter which option you choose you will have to install the Microsoft Visual C++ compiler and its tool chain. Navigate to the Visual Studio
[download site](https://visualstudio.microsoft.com/) and get the installer for the Community Edition 2022. Click on the installer application and follow 
its instructions. At least you will have to install the workload "Desktop Development with C++" with the following additional components (Section: Compiler,
Buildtools and Runtimes):

  - MSVC v143 Buildtools
  - Windows 11 SDK
  - C++-CMake-Tools for Windows
  - Core Functions of Test Tools - Buildtools
  - C++ AddressSanitizer
  - vcpkg-Package-Manager
  - C++ ATL Support for Buildtools v143
  - C++ Modules for v143 Buildtools

Additionally you can install the "Visual Studio Editor". If you wish to use `CMake` you have to got to their [website](https://cmake.org/) and 
download their installer for Windows. Click it to start the installation process.


## Build the examples

### CMake
Navigate to the root folder of the example containing the `CMakeLists.txt`. Create a new folder named `build` and change into it:

__Linux__
```bash
mkdir build
cd build
```

__Windows__
```powershell
mkdir build
cd build
```

Now generate the build files (Linux: `make`, Windows: `msbuild`) and start the compilation:

__Linux__
```bash
cmake ..
cmake --build . --config Release --parallel
```

__Windows__
```powershell
cmake ..
cmake --build . --config Release
```

You can find the generated executables directly in the `build` folder on Linux and in the `build\Release` folder on Windows.

### Visual Studio
Navigate to the `cpp` folder and open the solution file of your chosen example. Hit one of the green triangle buttons in the tool bar to start the compilation.
Once completed the resulting application will automatically be started.


## Examples

### enumeration
Displays enumeration events (detection of attached cameras) on the command line.

Run the example application with the following command:

__Linux__
```bash
./enumeration
```

__Windows__
```powershell
.\enumeration
```

### minimal
Views the current flag state and the dimensions of thermal frame on the command line. This is the minimal implementation required to retrieve thermal data from 
an Optris thermal camera.

Run the example with the following command:

__Linux__
```bash
./minimal <serial number>
```

__Windows__
```powershell
cd Release
.\minimal <serial number>
```

If no serial number is provided, the program will use the first compatible camera attached via USB.

### pif
Displays details about a connected process interface, tries to configure the first channel of each available type and outputs the read input values of
all PIF input channels.

Run the example with the following command:

__Linux__
```bash
./pif <serial number>
```

__Windows__
```powershell
cd Release
.\pif <serial number>
```

If no serial number is provided, the program will use the first compatible camera attached via USB.


### simpleView
Views a false color image based on the thermal data from the camera. Additionally, it visualizes hot and cold spots and prints information about a custom
rectangular measurement field onto the console. Note, that this field is only 20x20 pixels in size and does not cover the entire image. For video formats
with very small heights or widths this measurement field will not be added.

On Linux this example requires some additional dependencies to compile and run. You can use the package manager `apt` to install them:

```bash
sudo apt install libglew-dev freeglut3-dev
```

Since Ubuntu 24.04 `freeglut3-dev` is considered a transitional package that will be phased out. It installs its successor `libglut-dev`. 

For Windows these dependencies are already included in the `external\` folder of the example. Please note, that a special set of CMake Find Modules are used to 
locate them.

Run the example with the following command:

__Linux__
```bash
./simpleView <serial number>
```

__Windows__
```powershell
cd Release
.\simpleView.exe <serial number>
```

You can provide multiple serial numbers. For every serial number a dedicated window will be opened. If no serial number is provided, the program will use the 
first compatible camera it finds on the USB ports.