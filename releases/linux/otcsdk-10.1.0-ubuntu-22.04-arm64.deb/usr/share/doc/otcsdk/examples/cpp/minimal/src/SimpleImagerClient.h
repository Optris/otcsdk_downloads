// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    SimpleImagerClient.h
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the minimal example.
 *          
 * @date 2025-03-31
 */

#pragma once

#include <memory>

#include "otcsdk/IRImager.h"
#include "otcsdk/IRImagerClient.h"
#include "otcsdk/FramerateCounter.h"


/**
 * @brief Minimal example implementation of an IRImagerClient.
 * 
 * Bare minimum required to run an imager instance and receive data from it via the Observer
 * pattern. See simpleView example for a more comprehensive implementation.
 */
class SimpleImagerClient : public optris::IRImagerClient
{
public:
  /**
   * @brief Constructor.
   * 
   * @param[in] serialNumber of the camera to connect to.
   *
   * @throw SDKException if an imager instance could not be created.
   */
  SimpleImagerClient(unsigned long serialNumber);


  /// Main run method.
  void run();


private:
  /**
   * @brief Callback method triggered by imager when a new thermal frame is available.
   *
   * @param[in] thermal thermal frame data.
   * @param[in] meta    data of thermal frame.
   */
  void onThermalFrame(const optris::ThermalFrame& thermal, const optris::FrameMetadata& meta) override;


  /**
   * @brief Callback method triggered by imager when the state of the shutter flag changes.
   *
   * @param[in] flagState of the shutter flag.
   */
  void onFlagStateChange(optris::FlagState flagState) override;


  /// Imager instance.
  std::shared_ptr<optris::IRImager> _imager;

  /// Latest state of the shutter flag.
  optris::FlagState _flagState;

  /// Measures frames per seconds
  optris::FramerateCounter _fps;
};