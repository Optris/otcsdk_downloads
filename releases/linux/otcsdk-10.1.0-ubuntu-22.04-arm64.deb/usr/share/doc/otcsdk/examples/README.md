# Optris Thermal Camera SDK Examples
The directories in this folder feature examples illustrating various capabilities of the SDK. Please refer to their respective
Readmes to learn more about them and about the prerequisites needed to compile and/or run them.

## General Preparations
On Linux you have to copy the examples files from its install location to a place where you can edit them at ease like your home
directory:

__Linux__
```bash
cp -r /usr/share/doc/otcsdk/examples ~
```

The second command is needed to change the ownership of the files from `root` to yourself. On Windows the installer already created
a copy of the examples in your `Documents` directory. If you want to restore the examples you can copy the `examples` folder from the
SDK installation directory. By default this directory is located at:

__Windows__
```powershell
C:\Program Files\Optris GmbH\Thermal Camera SDK\examples
```

You may also want to install a code editor, like [Visual Studio Code](https://code.visualstudio.com/) to take a closer look at the
source code of the examples.
