// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    IRImagerShow.cpp
 * @author  Optris GmbH & Co. KG
 * @brief   Definition of the IRImagerShow class.
 *          
 * @date 2024-06-19    
 */

#include "IRImagerShow.h"

#include <cstring>
#include <iostream>
#include <sstream>
#include <iomanip>

#include "otcsdk/IRImagerFactory.h"


IRImagerShow::IRImagerShow(unsigned int serialNumber)
  /*
   * The factory is implemented as a Singleton. Therefore, you have to call getInstance()
   * first before you can create an IRImager object.
   *
   * The native implementation allows you to access the thermal data of cameras connected
   * via USB or Ethernet.
   */
  : _imager{optris::IRImagerFactory::getInstance().create("native")}
  , _imageBuilder{nullptr}
  , _display{nullptr}
  , _fps{std::make_unique<optris::FramerateCounter>(100)}
  , _flagState(optris::FlagState::Initializing)
  , _thread{nullptr}
  , _connectionLost{false}
{
  // Register this object as an client/observer with the imager
  _imager->addClient(this);

  // Connect to the camera with the given serial number
  _imager->connect(serialNumber);

  // Setup and add a measurement field to the imager
  optris::MeasurementFieldConfig mfConfig;
  mfConfig.name      = "Simple View";
  mfConfig.positionX = 20;
  mfConfig.positionY = 20;
  mfConfig.shape     = optris::FieldShape::Rectangle;
  mfConfig.width     = 20;
  mfConfig.height    = 20;

  try
  {
    // This may fail, if the field is, e.g., not completely within the thermal frame.
    _imager->addMeasurementField(mfConfig);
  }
  catch (const optris::SDKException& ex)
  {
    std::cerr << ex.what() << std::endl;
  }

  /*
   * Instantiate the image builder for converting the thermal frame to false color images.
   *
   * The Windows version of the display implementation Obvious2D expects the bytes for the color values to be in the
   * sequence BGR instead of RGB.
   *
   * The width alignment refers to the size of the image rows in bytes. With a four byte alignment that size will always
   * be a multiple of four. This may result in some padding at the end of the end of each line.
   * Currently Obvious2D uses a one byte alignment. If you wish to change that, go to the constructor definition in the
   * Obvious2D.cpp and change the value in the following line:
   *
   * glPixelStorei(GL_UNPACK_ALIGNMENT, 1);
   *
   * Available values are 1, 2, 4 and 8. Do not forget to change the width alignment accordingly.
   */
#ifdef _WIN32
  _imageBuilder = std::make_unique<optris::ImageBuilder>(optris::ColorFormat::BGR, optris::WidthAlignment::OneByte);
#else
  _imageBuilder = std::make_unique<optris::ImageBuilder>(optris::ColorFormat::RGB, optris::WidthAlignment::OneByte);
#endif
  _imageBuilder->setPaletteScalingMethod(optris::PaletteScalingMethod::MinMax);
  
  // Instantiate and setup the display used to visualize the thermal image
  std::stringstream titleStream;
  titleStream << "Optris Imager - " << _imager->getDeviceType() << " (S/N " << _imager->getSerialNumber() << ")";

  _display = std::make_unique<Obvious2D>(_imager->getWidth(), _imager->getHeight(), titleStream.str());

  // Register keyboard shortcut for refreshing the shutter flag
  _display->registerKeyboardClient('r', this, "Refresh Flag", Obvious2D::GREEN, Obvious2D::BLACK);
}

IRImagerShow::~IRImagerShow() noexcept
{
  // Join an active frame grabbing thread
  if (_thread)
  {
    _imager->stopRunning();
    _thread->join();
  }
}


void IRImagerShow::startGrabbingThread()
{
  _thread = std::make_unique<std::thread>(&optris::IRImager::run, _imager);  
}

bool IRImagerShow::render()
{
  // If the connection was lost, quit
  if (_connectionLost)
  {
    return false;
  }

  // If the display is not alive, nothing needs to be rendered
  if (!_display->isAlive())
  {
    _imager->stopRunning();

    return false;
  }

  // Generate a false color image from thermal frame data
  {
    Lock lock{_thermalMutex};

    if (_thermal.isEmpty())
    {
      // Nothing to do
      return true;
    }
    _imageBuilder->setThermalFrame(_thermal);
  }

  // Conversion to false color image
  _imageBuilder->convertTemperatureToPaletteImage();

  int imageWidth  = _imageBuilder->getWidth();
  int imageHeight = _imageBuilder->getHeight();
  int radius      = 3;

  // Determine the lowest and hights temperatures in the frame
  optris::TemperatureRegion minRegion;
  optris::TemperatureRegion maxRegion;
  if (_imageBuilder->getMinMaxRegions(radius, minRegion, maxRegion))
  {
    // Draws a blue crosshair on the position of the lowest temperature in the thermal frame
    drawMeasurementInfo(imageWidth, 
                        imageHeight, 
                        (minRegion.x1 + minRegion.x2) / 2,
                        (minRegion.y1 + minRegion.y1) / 2, 
                        minRegion.temperature, 
                        Obvious2D::BLUE, 
                        Obvious2D::WHITE);

    // Draws a red crosshair on the position of the hottest temperature in the thermal frame
    drawMeasurementInfo(imageWidth, 
                        imageHeight, 
                        (maxRegion.x1 + maxRegion.x2) / 2, 
                        (maxRegion.y1 + maxRegion.y2) / 2, 
                        maxRegion.temperature, 
                        Obvious2D::RED, 
                        Obvious2D::WHITE);
  }

  // Calculate the mean temperature in a small region in the center of thermal frame
  optris::TemperatureRegion meanRegion(imageWidth  / 2 - radius, 
                                       imageHeight / 2 - radius, 
                                       imageWidth  / 2 + radius,
                                       imageHeight / 2 + radius);
  if (_imageBuilder->getMeanTemperatureInRegion(meanRegion))
  {
    // Draws a white cross hair in the center of the display with the mean temperature                                         
    drawMeasurementInfo(imageWidth,
                        imageHeight,
                        imageWidth / 2 - 1,
                        imageHeight / 2 - 1,
                        meanRegion.temperature,
                        Obvious2D::WHITE,
                        Obvious2D::BLACK);
  }
  
  // Draws the false color image on the display including the frames per second
  _display->draw(_imageBuilder->getImage().getData(),
                 imageWidth, 
                 imageHeight, 
                 3, 
                 optris::toString(_flagState),
                 _fps->getFps());
  
  return true; 
}


void IRImagerShow::onThermalFrame(const optris::ThermalFrame& thermal, const optris::FrameMetadata& meta)
{
  // Thread synchronization
  Lock lock{_thermalMutex};

  // Copy thermal frame data
  _thermal = thermal;

  // Trigger framerate counter
  _fps->trigger(); 
}

void IRImagerShow::onFlagStateChange(optris::FlagState flagstate)
{
  _flagState = flagstate;
}

void IRImagerShow::onMeasurementField(const optris::MeasurementField& field)
{
  std::cout << field.getName() << " measurement field (Index " << field.getIndex() << ") temperatures: (min = " << field.getMinTemperature() << ", max = " << field.getMaxTemperature() << ", mean = " << field.getMeanTemperature()  << ")" << std::endl;
}

void IRImagerShow::onPifUncommittedValue(const std::string& name, const std::string& unit, float value)
{
  std::cout << name << ": " << value << " " << unit << std::endl;
}

void IRImagerShow::onConnectionLost()
{
  _connectionLost = true;
}

void IRImagerShow::onConnectionTimeout()
{
  _connectionLost = true;
}

void IRImagerShow::keyboardCallback(char key)
{
  switch (key)
  {
    case 'r':
      _imager->forceFlagEvent();
      break;

    default:
      // Ignore
      break;
  }
}

void IRImagerShow::drawMeasurementInfo(unsigned int       imageWidth,
                                       unsigned int       imageHeight,
                                       unsigned int       positionX,
                                       unsigned int       positionY,
                                       float              temperature,
                                       const std::uint8_t color[4],
                                       const std::uint8_t backgroundColor[4])
{
  unsigned int displayWidth  = _display->getWidth();
  unsigned int displayHeight = _display->getHeight();

  // Handle a full screen display
  if (_display->getFullscreen())
  {
    displayWidth  = _display->getScreenWidth();
    displayHeight = _display->getScreenHeight();

    // Check aspect ratio, there might be a dual monitor configuration
    float aspectRatio = static_cast<float>(displayWidth) / static_cast<float>(displayHeight);
    // Note, there other aspect ratios than 16:9, e.g. 16:10 or wide screen ratios.
    if (aspectRatio > (16.F / 9.F + 1e-3))
    {
      displayWidth /= 2;
    }
  }

  std::stringstream text;
  text << std::fixed << std::setprecision(1) << temperature;

  float radius = 20.F;
  float offset = radius / 2.F;
  _display->addCrosshair(displayWidth * positionX / imageWidth,
                         displayHeight - displayHeight * positionY / imageHeight,
                         text.str(),
                         color,
                         backgroundColor,
                         radius,
                         offset);
}