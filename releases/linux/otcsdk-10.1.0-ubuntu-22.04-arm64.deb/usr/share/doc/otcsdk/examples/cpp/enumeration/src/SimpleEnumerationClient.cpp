// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    SimpleEnumerationClient.cpp
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the enumeration example.
 *          
 * @date 2025-03-31
 */

#include "SimpleEnumerationClient.h"

#include <iostream>
#include <iomanip>
#include <thread>
#include <chrono>

#include "otcsdk/enumeration/EnumerationManager.h"


SimpleEnumerationClient::SimpleEnumerationClient()
{
  printHeader();

  /*
   * Register this instance as a client/observer with the EnumerationManger. The
   * EnumerationManger is implemented using the Singleton pattern. Therefore,
   * you need to call getInstance() to interact with it.
   */
  optris::EnumerationManager::getInstance().addClient(this);
}


void SimpleEnumerationClient::run()
{
  /*
   * The EnumerationManger was already started in a separate thread by the Sdk::init() method. 
   * Therefore, the main thread has nothing to do.
   */
  while (true)
  {
    std::this_thread::sleep_for(std::chrono::milliseconds{500});
  }
}


void SimpleEnumerationClient::onDeviceDetected(optris::DeviceInfo deviceInfo) noexcept
{
  printEvent("Detected", deviceInfo);
}

void SimpleEnumerationClient::onDeviceDetectionLost(optris::DeviceInfo deviceInfo) noexcept
{
  printEvent("Lost", deviceInfo);
}


void SimpleEnumerationClient::printHeader()
{
  std::cout << "Enumeration Events (Ctrl + C to quit)\n\n"
            << std::setw(15) << std::left << "EVENT"
            << std::setw(15) << std::left << "DEVICE TYPE"
            << std::setw(15) << std::left << "S/N"
            << std::setw(15) << std::left << "FIRMWARE REV"
            << std::setw(15) << std::left << "HARDWARE REV"
            << std::setw(15) << std::left << "CONNECTION TYPE"
            << std::endl;
}

void SimpleEnumerationClient::printEvent(const std::string& event, const optris::DeviceInfo& deviceInfo)
{
  std::cout << std::setw(15) << std::left << event
            << std::setw(15) << std::left << deviceInfo.getDeviceType()
            << std::setw(15) << std::left << deviceInfo.getSerialNumber()
            << std::setw(15) << std::left << deviceInfo.getFirmwareRevision()
            << std::setw(15) << std::left << deviceInfo.getHardwareRevision()
            << std::setw(15) << std::left << deviceInfo.getConnectionInterface()
            << std::endl;
}