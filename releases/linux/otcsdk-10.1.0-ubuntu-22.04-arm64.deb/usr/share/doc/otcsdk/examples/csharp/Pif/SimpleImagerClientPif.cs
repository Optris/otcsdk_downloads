﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml;
using Optris.OtcSDK;

namespace Pif
{
    /// <summary>Minimal example implementation of an IRImagerClient.</summary>
    /// 
    /// Bare minimum required to run an imager instance and receive data from it via the Observer pattern.
    /// Adds a method that configures the Process Interface (PIF) and an additional callback for "Uncommitted Value".
    internal class SimpleImagerClientPif : IRImagerClient
    {
        private IRImager _imager;

        // Variables to delay and throttle the info-output of the PIF inputs (via the onThermalFrame()-callback).
        // Time by which the output should be delayed.
        private readonly TimeSpan DELAY_TIME = TimeSpan.FromSeconds(5);
        // Wait-time between outputs.
        private readonly TimeSpan OUTPUT_INTERVAL = TimeSpan.FromSeconds(1);

        // Timestamp gets set when configurePif() has finished.
        private DateTime _configurationFinished = DateTime.Now;
        // Timestamp to keep track of the time of the last standard output.
        private DateTime _lastOutput = DateTime.Now;
        // Turns off elapsed-time check in onThermalFrame()-callback.
        private bool _delayOutput = true;


        /// <summary>Constructor.</summary>
        /// <param name="serialNumber">
        ///     Serial number of the device to connect to or 0 if to the first compatible device.
        /// </param>
        public SimpleImagerClientPif(uint serialNumber)
        {
            /*
             * The factory is implemented as a Singleton. Therefore, you have to call getInstance()
             * first before you can create an IRImager instance.
             *
             * The native implementation allows to access the thermal data of cameras connected via
             * USB or Ethernet.
             */
            _imager = IRImagerFactory.getInstance().create("native");

            /*
             * Register this instance as a client/observer with the IRImager implementation to
             * receive updates on thermal data and more.
             */
            _imager.addClient(this);

            // Establish a connection to the device.
            _imager.connect(serialNumber);
        }


        /// <summary>Main run method.</summary>
        public void run()
        {
            /*
             * Run the imager synchronously (the run() method will block).
             *
             * As an alternative, the imager can be run asynchronously with the runAsync()
             * method. In this case the callbacks will be triggered from a separate
             * thread.
             */
            _imager.run();
        }

        /// <summary>Configures the process interface</summary>
        public void configurePif()
        {
            // Get the PIF interface (reference only valid during an active camera connection)
            ProcessInterface pif = _imager.getPif();


            // Tip: You can change the PIF device type and count at runtime like this:
            // optris::PifConfig pifConfig = pif.getConfig(); // Preserves the existing PIF channel configurations. Create new object to reset them.

            // pifConfig.deviceType  = PifDeviceType.Stackable;
            // pifConfig.deviceCount = 1;

            // pif.setConfig(pifConfig);


            // Get the type of connected PIF
            // Returns the type of the PIF that is really connected to the camera
            // Autonomous Cameras (Xi80, Xi 410, Xi 1M): Returns the type that is stored in the config on the camera
            PifDeviceType deviceType = pif.getDeviceType();
            Console.WriteLine("\n{0} PIF\n", deviceType.ToString());

            Console.WriteLine("{0} configurable device(s), {1} are actually connected.\n", pif.getConfigurableDeviceCount(), pif.getActualDeviceCount());


            // Check, if connected PIF has a dedicated fail save channel
            string hasFailSafe = pif.hasFs() ? "Yes" : "No";

            Console.WriteLine("{0, -15}{1, -6}{2, -6}{3, -6}{4, -6}{5, -6}", "AVAILABILITY",
                                                                             "AI",
                                                                             "AO",
                                                                             "DI",
                                                                             "DO",
                                                                             "FS");

            // Check number of actual available inputs and outputs
            Console.WriteLine("{0, -15}{1, -6}{2, -6}{3, -6}{4, -6}{5, -6}", "Actual",
                                                                             pif.getActualAiCount(),
                                                                             pif.getActualAoCount(),
                                                                             pif.getActualDiCount(),
                                                                             pif.getActualDoCount(),
                                                                             hasFailSafe);

            // Check number of configurable inputs and outputs
            Console.WriteLine("{0, -15}{1, -6}{2, -6}{3, -6}{4, -6}{5, -6}\n\n", "Configurable",
                                                                                 pif.getConfigurableAiCount(),
                                                                                 pif.getConfigurableAoCount(),
                                                                                 pif.getConfigurableDiCount(),
                                                                                 pif.getConfigurableDoCount(),
                                                                                 hasFailSafe);


            // This example configures the first channel (AO, AI, ...) of the first PIF device
            Console.WriteLine("Configuring Channels\n");
            int deviceIndex = 0;
            int pinIndex    = 0;

            // Configure an AI channel
            Console.Write("AI{0}.{1}: ", deviceIndex + 1, pinIndex + 1);
            if (pif.getConfigurableAiCount() >= 1)
            {
                Console.WriteLine("Set to \"Uncommitted Value\"");

                // Sets the AI to "Uncommitted Value" mode.
                // The converted input values (depending on gain/offset) will be available via the onPifUncommittedValue() callback function
                pif.setAiConfig(PifAiConfig.createUncommittedValue(deviceIndex,
                                                                   pinIndex,
                                                                   "Pressure Sensor",
                                                                   "Pa",
                                                                   0.1f,
                                                                   0.0f));
            }
            else
            {
                Console.WriteLine("Not available.");
            }

            // Configure an AO channel
            Console.Write("AO{0}.{1}: ", deviceIndex + 1, pinIndex + 1);
            if (pif.getConfigurableAoCount() >= 1)
            {
                Console.WriteLine("Set to \"Internal Temperature\"");

                // Get the default analog output range (0..10 V or 0..20 mA/4..20 mA) dependent on the connected device
                PifAoOutputMode outputMode = pif.getDefaultAoOutputMode();

                // Sets the AO to "Internal Temperature" mode.
                pif.setAoConfig(PifAoConfig.createInternalTemperature(deviceIndex,
                                                                      pinIndex,
                                                                      outputMode,
                                                                      0.1f,
                                                                      0.0f));
            }
            else
            {
                Console.WriteLine("Not available.");
            }

            // Configure a DI channel
            Console.Write("DI{0}.{1}: ", deviceIndex + 1, pinIndex + 1);
            if (pif.getConfigurableDiCount() >= 1)
            {
                Console.WriteLine("Set to \"Flag Control\"");

                // Sets the DI to "Flag Control" mode
                // The flag therefore cycles when the input switches between high and low
                pif.setDiConfig(PifDiConfig.createFlagControl(deviceIndex, pinIndex, true));
            }
            else
            {
                Console.WriteLine("Not available.");
            }

            // Configure a DO channel
            Console.Write("DO{0}.{1}: ", deviceIndex + 1, pinIndex + 1);
            if (pif.getConfigurableDoCount() >= 1)
            {
                Console.WriteLine("Set to \"External Communication\"");

                // Sets the DO to "External Communication" which enables the user to control the value of the output
                pif.setDoConfig(PifDoConfig.createExternalCommunication(deviceIndex, pinIndex));
                
                // Set the output to a value
                pif.setDoValue(deviceIndex, pinIndex, true);
            }
            else
            {
                Console.WriteLine("Not available.");
            }

            // Configure the FS channel
            Console.Write("FS   : ");
            if (pif.hasFs())
            {
                Console.WriteLine("Set to \"On\"");

                // Activates the fail safe channel
                pif.setFsConfig(PifFsConfig.createOn());
            }
            else
            {
                Console.WriteLine("Not available.");
            }

            Console.WriteLine("\n\nPIF output is delayed for {0} seconds...\n", DELAY_TIME.TotalSeconds);
            _configurationFinished = DateTime.Now;
        }

        /// <summary>Callback method triggered by imager when a new thermal frame is available.</summary>
        /// 
        /// <param name="thermal">thermal frame data.</param>
        /// <param name="meta">data of the thermal frame.</param>
        public override void onThermalFrame(ThermalFrame thermal, FrameMetadata meta)
        {
            // Get indices of available PIF inputs
            int pifDeviceCount = meta.getPifActualDeviceCount();
            int pifAiCount     = meta.getPifAiCountPerDevice();
            int pifDiCount     = meta.getPifDiCountPerDevice();

            // For readability: Delays output of PIF-input values by DELAY_TIME seconds
            DateTime now = DateTime.Now;

            if (_delayOutput)
            {
                if (now - _configurationFinished < DELAY_TIME)
                {
                    return;
                }
                _delayOutput = false;
                _lastOutput  = now;
            }

            // For readability: Throttles output of PIF-input values to every OUTPUT_INTERVAL seconds
            if (now - _lastOutput < OUTPUT_INTERVAL)
            {
                return;
            }
            _lastOutput = now;

            // Access the PIF input values directly
            try
            {
                for (int deviceIndex = 0; deviceIndex < pifDeviceCount; deviceIndex++)
                {
                    Console.WriteLine("PIF Device {0}", deviceIndex + 1);

                    // Analog inputs (voltages as float)
                    for (int pinIndex = 0; pinIndex < pifAiCount; pinIndex++)
                    {
                        Console.WriteLine("- AI{0}.{1} Value: {2} V", deviceIndex + 1, pinIndex + 1, meta.getPifAiValue(deviceIndex, pinIndex));
                    }

                    // Digital inputs (boolean)
                    for (int pinIndex = 0; pinIndex < pifDiCount; pinIndex++)
                    {
                        Console.WriteLine("- DI{0}.{1}: {2}", deviceIndex + 1, pinIndex + 1, meta.getPifDiValue(deviceIndex, pinIndex));
                    }
                }
            }
            catch (SDKException ex)
            {
                Console.WriteLine("Failed to get PIF input value: {0}", ex.Message);
            }

            Console.WriteLine();
        }

        /// <summary>Callback method triggered by imager when the state of the shutter flag changes.</summary>
        /// 
        /// <param name="flagState">of the shutter flag.</param>
        public override void onFlagStateChange(FlagState flagState)
        {
            Console.WriteLine("Flag state: {0}\n", flagState.ToString());
        }

        /// <summary>Callback method triggered by imager when a changed uncommitted PIF analog input value was received.</summary>
        /// 
        /// <param name="name">configured name of the uncommitted value.</param>
        /// <param name="unit">configured unit of the uncommitted value.</param>
        /// <param name="value">calculated from the PIF analog input value.</param>
        public override void onPifUncommittedValue(string name, string unit, float value)
        {
            Console.WriteLine("{0}: {1} {2}\n", name, value, unit);
        }
    }
}
