﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Optris.OtcSDK;

namespace Enumeration
{
    /// <summary>Simple example implementation of an EnumerationClient that outputs enumerations events.</summary>
    /// 
    /// An EnumerationClient serves as observer to the EnumerationManger that constantly when devices for newly
    /// attached or removed devices.
    internal class SimpleEnumerationClient : EnumerationClient
    {
        /// <summary>Constructor.</summary> 
        public SimpleEnumerationClient() 
        {
            printHeader();

            /*
             * Register this instance as a client/observer with the EnumerationManger.
             * The EnumerationManger is implemented using the Singleton pattern. Therefore,
             * you need to call getInstance() to interact with it.
             */
            EnumerationManager.getInstance().addClient(this);
        }

        /// <summary>Main run method.</summary>
        public void run()
        {
            /*
             * The EnumerationManger was already started in a separate thread by the Sdk::init() method. 
             * Therefore, the main thread has nothing to do.
             */
            while (true)
            {
                Thread.Sleep(500);
            }
        }

        /// <summary>Called when a new device was detected.</summary>
        /// 
        /// This happens, for example, if a camera is plugged in to the computer via USB.
        /// 
        /// <param name="deviceInfo"> about the detected device.</param>
        public override void onDeviceDetected(DeviceInfo deviceInfo)
        {
            printEvent("Detected", deviceInfo);
        }

        /// <summary>Called when a previously detected device is now longer found.</summary>
        /// 
        /// This happens, for example, if a camera is unplugged from the computer..
        /// 
        /// <param name="deviceInfo"> about the lost device.</param>
        public override void onDeviceDetectionLost(DeviceInfo deviceInfo)
        {
            printEvent("Lost", deviceInfo);
        }


        /// <summary>Prints out the header for the enumeration events.</summary>
        private void printHeader()
        {
            Console.WriteLine("Enumeration Events (Ctrl + C to quit)");
            Console.WriteLine("{0, -15}{1, -15}{2, -15}{3, -15}{4, -15}{5, -15}", "EVENT",
                                                                                  "DEVICE TYPE",
                                                                                  "S/N",
                                                                                  "FIRMWARE REV",
                                                                                  "HARDWARE REV",
                                                                                  "CONNECTION TYPE");
        }

        /// <summary>Prints out an enumeration event.</summary>
        /// <param name="eventType">to print.</param>
        /// <param name="deviceInfo">to print.</param>
        private void printEvent(string eventType, DeviceInfo deviceInfo) 
        {
            Console.WriteLine("{0, -15}{1, -15}{2, -15}{3, -15}{4, -15}{5, -15}", eventType,
                                                                                  deviceInfo.getDeviceType().ToString(),
                                                                                  deviceInfo.getSerialNumber(),
                                                                                  deviceInfo.getFirmwareRevision(),
                                                                                  deviceInfo.getHardwareRevision(),
                                                                                  deviceInfo.getConnectionInterface());
        }
    }
}
