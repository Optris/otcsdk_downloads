﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using Optris.OtcSDK;


namespace Enumeration
{
    internal class Program
    {
        ///<summary>Program main entry point.</summary>
        static void Main(string[] args)
        {
            // Initialize the SDK by providing log verbosity
            Sdk.init(Verbosity.Error, Verbosity.Off, "Enumeration");

            SimpleEnumerationClient client = new();
            client.run();
        }
    }
}
