﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Optris.OtcSDK;

namespace Minimal
{
    /// <summary>Minimal example implementation of an IRImagerClient.</summary>
    /// 
    /// Bare minimum required to run an imager instance and receive data from it via the Observer
    /// pattern. See SimpleViewCS example for a more comprehensive implementation.
    internal class SimpleImagerClient : IRImagerClient
    {
        private IRImager         _imager;
        private FlagState        _flagState;
        private FramerateCounter _fps;


        /// <summary>Constructor.</summary>
        /// <param name="serialNumber">
        ///     Serial number of the device to connect to or 0 if to the first compatible device.
        /// </param>
        public SimpleImagerClient(uint serialNumber) 
        {
            // Latest state of the shutter flag
            _flagState = FlagState.Initializing;

            // Measures FPS
            _fps = new FramerateCounter(100);

            /*
             * The factory is implemented as a Singleton. Therefore, you have to call getInstance()
             * first before you can create an IRImager object.
             *
             * The native implementation allows to access the thermal data of cameras connected via
             * USB or Ethernet.
             */
            _imager = IRImagerFactory.getInstance().create("native");

            /*
             * Register this instance as a client/observer with the IRImager implementation to
             * receive updates on thermal data and more.
             */
            _imager.addClient(this);

            // Establish a connection to the device.
            _imager.connect(serialNumber);
        }


        /// <summary>Main run method.</summary>
        public void run()
        {
            /*
             * Run the imager synchronously (the run() method will block).
             *
             * As an alternative, the imager can be run asynchronously with the runAsync()
             * method. In this case the callbacks will be triggered from a separate
             * thread.
             */
            _imager.run();
        }

        /// <summary>Callback method triggered by imager when a new thermal frame is available.</summary>
        /// 
        /// <param name="thermal">thermal frame data.</param>
        /// <param name="meta">data of the thermal frame.</param>
        public override void onThermalFrame(ThermalFrame thermal, FrameMetadata meta)
        {
            _fps.trigger();

            // When the flag transitioned out of Initializing the thermal data is valid and can be displayed.
            if (_flagState != FlagState.Initializing)
            {
                Console.Write("{0, -10}{1, -10}{2, -10}{3, -20}{4, -15}\r", thermal.getWidth(),
                                                                            thermal.getHeight(),
                                                                            Math.Round(_fps.getFps(), 0),
                                                                            Math.Round(thermal.getTemperature(thermal.getWidth() / 2, thermal.getHeight() / 2), 2),
                                                                            _flagState.ToString());

            }
        }

        /// <summary>Callback method triggered by imager when the state of the shutter flag changes.</summary>
        /// 
        /// <param name="flagState">of the shutter flag.</param>
        public override void onFlagStateChange(FlagState flagState)
        {
            // When the flag transitioned out of Initializing the thermal data is valid. Thus, print the header of the output table.
            if (flagState != _flagState && _flagState == FlagState.Initializing)
            {
                Console.WriteLine("\nThermal Frame\n");
                Console.WriteLine("{0, -10}{1, -10}{2, -10}{3, -20}{4, -15}", "WIDTH",
                                                                              "HEIGHT",
                                                                              "FPS",
                                                                              "TEMP CENTER PIXEL",
                                                                              "FLAG STATE");
            }

            _flagState = flagState;
        }
    }
}
