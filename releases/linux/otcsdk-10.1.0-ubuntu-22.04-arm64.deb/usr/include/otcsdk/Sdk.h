// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   Sdk.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a static class that allows for the basic configuration of the SDK and for retrieving basic information
 *         about the SDK.
 * 
 * @date 2025-04-22
 */

#pragma once

#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/common/VersionInfo.h"


/// Main SDK namespace.
namespace optris
{

/// Represents the different logging verbosity levels.
enum class Verbosity 
{ 
  Off     = 1,  ///< Off.
  Error   = 2,  ///< Error.
  Warning = 3,  ///< Warning.
  Info    = 4,  ///< Info.
  Debug   = 5,  ///< Debug.
};

/// Represents the different sources from which the calibration files can be acquired.
enum class CalibrationFileSource
{
  Device,      ///< The calibration files are fetched from the on-board memory of the device. Not supported by all devices. 
  Filesystem,  ///< The calibration files are copied from a local filesystem directory.
  Internet,    ///< The calibration files are downloaded from Optris servers. Requires internet access.
  Empty,       ///< No calibration source wanted.
};


/// Static class granting access to SDK wide configuration and utility functions.
class Sdk
{
public:
  /// No constructor.
  Sdk() = delete;


  /**
   * @brief Initializes the SDK.
   * 
   * It sets the verbosity levels of the internal logger of the SDK and starts the EnumerationManager in a dedicated thread
   * to monitor the availability of devices.
   * 
   * @param[in] logScreen         defines the minimum verbosity level of log messages displayed on the standard output and error.
   * @param[in] logFile           defines the minimum verbosity level of log messages out to the logfile.
   * @param[in] logFilenamePrefix for the log file (logFilenamePrefix_YYYY_MM_DD-hh-mm-ss.log). If empty, it defaults to "OtcSDK".
   */
  OTC_SDK_API static void init(Verbosity logScreen, Verbosity logFile, std::string logFilenamePrefix = "");


  /**
   * @brief Sets the priority of the calibration file sources.
   * 
   * The priority of the sources needs to be set prior to connecting to a device. If you want to use less than three potential calibration
   * file source, set the one you do not require to Empty. The different sources have individual requirements for them to work:
   * 
   * - Device. Not all types of Optris cameras have their calibration files stored on-device. 
   * - Filesystem. The source directory should be accessible and the SDK should have the rights to copy the calibration files from
   *   it to their target destination. The source directory needs to be specified via the Sdk::setCalibrationFileSourceDirectory()
   *   method.
   * - Internet. Access to the internet is required.
   * 
   * @note The SDK does not yet feature the ability to download the calibration from the device.
   * 
   * @param[in] first  source with the highest priority.
   * @param[in] second source with a medium priority.
   * @param[in] third  source with the lowest priority.
   * 
   * @return true, if priority was successfully set. False, otherwise.
   */
  OTC_SDK_API static bool setCalibrationFileSources(CalibrationFileSource first, CalibrationFileSource second, CalibrationFileSource third);

  /**
   * @brief Sets the source directory from which calibration files can be copied.
   * 
   * If set to an empty string, the SDK will skip this option of acquiring calibration files.
   * 
   * @param[in] sourceDirectoryPath from which calibration files can be copied.
   * 
   * @return true, if the source directory was set successfully. False, otherwise.
   */
  OTC_SDK_API static bool setCalibrationFileSourceDirectory(const std::string& sourceDirectoryPath);


  /**
   * @brief Returns an object holding version and build information about the SDK.
   * 
   * @return object holding version and build information about the SDK.
   */
  OTC_SDK_API static VersionInfo getVersionInfo();
};

} // namespace optris