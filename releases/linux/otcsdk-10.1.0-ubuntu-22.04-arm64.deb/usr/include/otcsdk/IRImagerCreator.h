// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImagerCreator.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface definition for classes instantiating IRImager implementations.
 * 
 * @date 2025-03-14
 */

#pragma once

#include <memory>

#include "otcsdk/IRImager.h"


namespace optris 
{

/// Defines the interface for classes that instantiate IRImager implementations.
class IRImagerCreator
{
public:
  /// Constructor.
  IRImagerCreator() = default;

  /// No copy constructor.
  IRImagerCreator(const IRImagerCreator&) = delete;
  /// No copy assignment.
  IRImagerCreator& operator=(const IRImagerCreator&) = delete;

  /// No move constructor.
  IRImagerCreator(IRImagerCreator&&) = delete;
  /// No move assignment.
  IRImagerCreator& operator=(IRImagerCreator&&) = delete;

  /// Destructor.
  virtual ~IRImagerCreator() = default;
  

  /**
   * @brief Creates an instance of an IRImager implementation.
   * 
   * @return shared pointer to the created instance.
   *
   * @throw SDKException if the instantiation fails.
   */
  virtual std::shared_ptr<IRImager> create() noexcept(false) = 0;
};

} // namespace optris