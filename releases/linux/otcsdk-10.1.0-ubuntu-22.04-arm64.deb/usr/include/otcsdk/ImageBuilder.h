// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   ImageBuilder.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that converts thermal frames into false color images.
 * 
 * @date 2024-12-19
 */

#pragma once

#include <memory>
#include <array>

#include "otcsdk/Api.h"

#include "otcsdk/common/ThermalFrame.h"
#include "otcsdk/common/Image.h"


namespace optris
{

/**
 * @brief Characterizes a rectangular region by the indexes of the upper left and the lower right corners
 *        along with an associated temperature.
 * 
 * Note that the origin of coordinates is located in upper left corner with the x-axis pointing right and
 * the y-axis pointing downwards.
 * 
 *  +---> x
 *  |
 *  v     1-----------+
 *  y     |           |
 *        |           |
 *        +-----------2
 *  
 *  => x1 <= x2 & y1 <= y2
 */
struct OTC_SDK_API TemperatureRegion
{
  /// Constructor.
  TemperatureRegion() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] x1 x index of the upper left corner.
   * @param[in] y1 y index of the upper left corner.
   * @param[in] x2 x index of the lower right corner.
   * @param[in] y2 y index of the lower right corner. 
   */
  TemperatureRegion(int x1, int y1, int x2, int y2) noexcept;

  /// Resets the temperature and the coordinates of the corners.
  void reset() noexcept;

  /**
   * @brief Returns whether the region fits within a rectangle of the given dimensions.
   *
   * @param[in] width   in pixels of the rectangle to fit the region in.
   * @param[in] height  in pixels of the rectangle to fit the region in.
   * @param[in] padding in pixels applied to the region in all directions during the check.
   * 
   * @return true if the region fits in the given rectangle. False otherwise.
   */
  bool fitsInRectangle(int width, int height, int padding = 0) const noexcept;


  /// Associated temperature in °C.
  float temperature;

  /// X index of the upper left corner.
  int x1;
  /// Y index of the upper left corner.
  int y1;

  /// X index of the lower right corner.
  int x2;
  /// Y index of the lower right corner.
  int y2;
};


/**
 * @brief Represents the available coloring palettes.
 *  
 * 
 */ 
enum class ColoringPalette
{
  AlarmBlue,    ///< @image html color_palette_alarm_blue.jpg
  AlarmBlueHi,  ///< @image html color_palette_alarm_blue_hi.jpg
  GrayBW,       ///< @image html color_palette_gray_bw.jpg
  GrayWB,       ///< @image html color_palette_gray_wb.jpg
  AlarmGreen,   ///< @image html color_palette_alarm_green.jpg
  Iron,         ///< @image html color_palette_iron.jpg
  IronHi,       ///< @image html color_palette_iron_hi.jpg
  Medical,      ///< @image html color_palette_medical.jpg
  Rainbow,      ///< @image html color_palette_rainbow.jpg
  RainbowHi,    ///< @image html color_palette_rainbow_hi.jpg
  AlarmRed,     ///< @image html color_palette_alarm_red.jpg
};


/// Represents the false color conversion strategies.
enum class PaletteScalingMethod
{
  Manual,  ///< User-defined upper and lower limit (fixed values).
  MinMax,  ///< Dynamic determination of minimum and maximum temperature as upper and lower limit.
  Sigma1,  ///< Dynamic determination of upper and lower limit from standard deviation of temperature image.
  Sigma3,  ///< Same as Sigma1, but with factor 3.
};


/// Creates false color images from thermal frames.
class ImageBuilder
{
public:
  /// Type for look up tables.
  using LookupTable = std::array<unsigned int, 65536>;


  /**
   * @brief Constructor.
   * 
   * Be mindful of which color format and width alignment you choose. Please refer to the documentation of the
   * enums for more details.
   *
   * @param[in] colorFormat    for the generated false color image.
   * @param[in] widthAlignment for the generated false color image.
   */
  OTC_SDK_API ImageBuilder(ColorFormat colorFormat, WidthAlignment widthAlignment);


  /**
   * @brief Sets a new thermal frame.
   *
   * The provide frame will be copied to an internal buffer.
   * 
   * @param[in] thermalFrame data.
   */
  OTC_SDK_API void setThermalFrame(const ThermalFrame& thermalFrame);

  /**
   * @brief Grants read access to the stored thermal frame.
   * 
   * @return const reference to the stored thermal frame.
   */
  const ThermalFrame& getThermalFrame() const noexcept;

  /**
   * @brief Returns the width in pixels of the thermal frame.
   *  
   * @return width in pixels of the thermal frame.
   */
  int getWidth() const noexcept;

  /**
   * @brief Returns the height in pixels of thermal frame.
   *
   * @return height in pixels of thermal frame.
   */
  int getHeight() const noexcept;

  /**
   * @brief Returns the temperature the from last acquired image at specified pixel index.
   *
   * @param[in] index pixel index.
   *
   * @return temperature in °C.
   *
   * @throw SDKException if index is out of range.
   */
  OTC_SDK_API float getTemperature(int index) const;

  /**
   * @brief Returns the temperature from last acquired image at specified pixel coordinates.
   *
   * The origin of coordinates is located in the upper left corner with the x-axis pointing right and
   * the y-axis pointing downwards.
   * 
   * @param[in] x coordinates.
   * @param[in] y coordinates.
   *
   * @return temperature in °C.
   *
   * @throw SDKException if coordinates are out of range.
   */
  OTC_SDK_API float getTemperature(int x, int y) const;

  /**
   * @brief Returns the mean temperature in °C of a rectangular region.
   *
   * Before providing the region to this method you have to define the rectangular area it covers by
   * specifying its upper left and lower right corners.
   * 
   * @param[out] meanRegion in which to calculate the mean temperature.
   *
   * @return true if a mean temperature could be calculated. False if no thermal data is available or
   *         if the region coordinates are inconstent or if the region is too large for the frame.
   */
  OTC_SDK_API bool getMeanTemperatureInRegion(TemperatureRegion& meanRegion);

  /**
   * @brief Returns the region of minimum/maximum temperature in °C with the given radius.
   *
   * The method will fill in all the data for the min and max temperature region.
   * 
   * @param[in]  radius    radius of the region.
   * @param[out] minRegion region of minimum mean temperature.
   * @param[out] maxRegion region of maximum mean temperature.
   *
   * @return true if minimum/maximum temperature could be calculated. False if no thermal data is available
   *         or if the radius is to large for the frame.
   */
  OTC_SDK_API bool getMinMaxRegions(int radius, TemperatureRegion& minRegion, TemperatureRegion& maxRegion);


  // Image conversion
  /**
   * @brief Sets the temperature range for the manual scaling method.
   *
   * @param[in] min lower limit in °C.
   * @param[in] max upper limit in °C.
   */
  OTC_SDK_API void setManualTemperatureRange(float min, float max);

  /**
   * @brief Returns the minimum temperature used to scale the image.
   *
   * @return temperature in °C.
   */
  OTC_SDK_API float getIsothermalMin() const noexcept;

  /**
   * @brief Returns the maximum temperature used to scale the image.
   *
   * @return Temperature in °C
   */
  OTC_SDK_API float getIsothermalMax() const noexcept;

  /**
   * @brief Sets the scaling method for the false color conversion.
   *
   * @param[in] method scaling method.
   */
  void setPaletteScalingMethod(PaletteScalingMethod method) noexcept;

  /**
   * @brief Returns the current scaling method for the false color conversion.
   *
   * @return scaling method.
   */
  PaletteScalingMethod getPaletteScalingMethod() const noexcept;

  /**
   * @brief Sets the palette for the false color conversion.
   *
   * @param[in] palette coloring palette to set.
   */
  void setPalette(ColoringPalette palette) noexcept;

  /**
   * @brief Returns the palette for the false color conversion.
   *
   * @return used coloring palette.
   */
  OTC_SDK_API ColoringPalette getPalette() const noexcept;

  /**
   * @brief Grants read access to the generated false color image.
   * 
   * @return const reference to the generated false color image.
   */
  const Image& getImage() noexcept;

  /**
   * @brief Returns the image size in bytes including potential width padding.
   * 
   * @return image size in bytes including potential width padding.
   */
  int getImageSizeInBytes() const noexcept;

  /**
   * @brief Returns the image stride in bytes.
   * 
   * The stride is the image width in bytes including potential padding.
   * 
   * @return image stride in bytes.
   */
  int getImageStride() const noexcept;

  /**
   * @brief Copies the false color image data to the given destination array.
   * 
   * @param[out] destination array to copy the false color image data to.
   * @param[in]  size        in bytes. The specified size is limited to [0, image size in bytes].
   */
  OTC_SDK_API void copyImageDataTo(unsigned char* destination, int size) const noexcept;
  
  /**
   * @brief Creates a lookup table for the false color conversion..
   *
   * @return lookup table.
   */
  OTC_SDK_API LookupTable createLookupTable();


  /// Triggers the image conversion.
  OTC_SDK_API void convertTemperatureToPaletteImage();

  /**
   * @brief Image conversion to RBG with lookup table. This method is efficient, but works only with fixed temperature ranges (manual mode).
   * 
   * @param[in] lut lookup table.
   */
  OTC_SDK_API void convertTemperatureToPaletteImage(const LookupTable& lut);


private:
  /// Type of palette table used for the false color conversion.
  using PaletteTable = unsigned char (*)[3];


  /**
   * @brief Returns the palette table for the false color conversion.
   *
   * @param[out] table coloring palette table as RGB triple.
   */
  void getPaletteTable(PaletteTable& table) const noexcept;


  /// Calculates an image integral (speedup purpose).
  void calculateIntegralImage();

  /// Calculates the scaling boundaries based on minimal and maximal temperature.
  void calcMinMaxScalingFactor();

  /**
   * @brief Calculates the scaling boundaries based on standard deviation.
   *
   * @param[in] sigma multiplication factor for sigma range
   */
  void calcSigmaScalingFactor(float sigma);


  /// Thermal frame.
  ThermalFrame _thermalFrame;
  /// Temperature converter.
  TemperatureConverter _converter;

  /// Integral image.
  std::unique_ptr<unsigned long[]> _integral;
  /// Flag for recomputing the integral image.
  bool _integralIsDirty;

  /// False color image.
  Image _image;

  /// Indicates the temperature range scaling method.
  PaletteScalingMethod _scalingMethod;

  /// Minimum temperature of the display range.
  unsigned short _min;
  /// Maximum temperature of the display range.
  unsigned short _max;

  /// Coloring palette for the false color conversion.
  ColoringPalette _palette;
};


// Inline implementations
inline const ThermalFrame& ImageBuilder::getThermalFrame() const noexcept
{
  return _thermalFrame;
}

inline int ImageBuilder::getWidth() const noexcept
{
  return _thermalFrame.getWidth();
}

inline int ImageBuilder::getHeight() const noexcept
{
  return _thermalFrame.getHeight();
}

inline void ImageBuilder::setPaletteScalingMethod(PaletteScalingMethod method) noexcept
{
  _scalingMethod = method;
}

inline PaletteScalingMethod ImageBuilder::getPaletteScalingMethod() const noexcept
{
  return _scalingMethod;
}

inline void ImageBuilder::setPalette(ColoringPalette palette) noexcept
{
  _palette = palette;
}

inline ColoringPalette ImageBuilder::getPalette() const noexcept
{
  return _palette;
}

inline const Image& ImageBuilder::getImage() noexcept
{
  return _image;
}

inline int ImageBuilder::getImageSizeInBytes() const noexcept
{
  return _image.getSizeInBytes();
}

inline int ImageBuilder::getImageStride() const noexcept 
{ 
  return _image.getStride(); 
}

} // namespace optris
