// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImagerClient.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the base class for all clients observing an IRImager.
 * 
 * @date 2024-12-10
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/common/FlagState.h"
#include "otcsdk/common/Frame.h"
#include "otcsdk/common/FrameMetadata.h"
#include "otcsdk/common/SnapshotEvent.h"
#include "otcsdk/common/ThermalFrame.h"
#include "otcsdk/fields/MeasurementField.h"


namespace optris
{

/**
 * @brief Base class for clients observing an IRImager.
 * 
 * The architecture is following the Observer design pattern. To receive data like thermal frames from your device
 * derive your own class from it and implement the callback methods. After creating an instance of you need to
 * register it with an IRImager object by calling its IRImager::addClient() method.
 */
class IRImagerClient
{
public:
  /// Constructor.
  IRImagerClient() = default;

  /// No copy constructor.
  IRImagerClient(const IRImagerClient&) = default;
  /// No copy assignment.
  IRImagerClient& operator=(const IRImagerClient&) = default;

  /// Move constructor.
  IRImagerClient(IRImagerClient&&) = default;
  /// Move assignment.
  IRImagerClient& operator=(IRImagerClient&&) = default;

  /// Destructor.
  virtual ~IRImagerClient() = default;


  /**
   * @brief Callback method for thermal frames.
   *
   * The provided references will remain valid outside the callback but the data that they are pointing to will be 
   * overwritten. Make a copy (C++) or use the clone() method (other languages) if you want to use them outside of  
   * the callback.
   * 
   * The references are const. Thus, you have only read access to the objects they are referring to. Attempts to
   * manipulate their content will cause issues.
   * 
   * This callback will also be triggered during the initial startup calibration phase following a successful device
   * connection. During this time the thermal data is unreliable. You can detect this phase by checking whether the
   * flag state stored in the meta data (FrameMetadata::getFlagState()) is set to Initializing.
   * 
   * @param[in] thermal frame.
   * @param[in] meta    additional meta data.
   */
  virtual void onThermalFrame(const ThermalFrame&   thermal,  
                              const FrameMetadata&  meta) 
  { }

  /**
   * @brief Callback method for thermal frames triggered with a raising edge event on PIF digital input or software 
   *        trigger.
   *
   * The provided references will remain valid outside the callback but the data that they are pointing to will be 
   * overwritten. Make a copy (C++) or use the clone() method (other languages) if you want to use them outside of  
   * the callback.
   * 
   * The references are const. Thus, you have only read access to the objects they are referring to. Attempts to
   * manipulate their content will cause issues.
   * 
   * For future use.
   * 
   * @param[in] thermal frame.
   * @param[in] energy  frame.
   * @param[in] meta    additional meta data for both frames.
   * @param[in] events  snapshot events.
   */
  virtual void onThermalFrameEvent(const ThermalFrame&               thermal,
                                   const Frame&                      energy,
                                   const FrameMetadata&              meta,
                                   const std::vector<SnapshotEvent>& events)
  { }

  /**
   * @brief Callback method for flag state events. The method is called when the flag state changes.
   *
   * @param[in] flagState current flag state.
   */
  virtual void onFlagStateChange(FlagState flagState)
  { }

  /**
   * @brief Callback method for measurement fields. The method is called when the calculation has finished.
   * 
   * The provided reference will remain valid outside the callback but the data that it is pointing to will be 
   * overwritten. Make a copy (C++) or use the clone() method (other languages) if you want to use it outside
   * of the callback.
   * 
   * The reference is const. Thus, you have only read access to the object it is referring to. Attempts to
   * manipulate its content will cause issues.
   *
   * @param[in] field measurement field.
   */
  virtual void onMeasurementField(const MeasurementField& field) 
  { }

  /**
   * @brief Called when an updated uncommitted value is available.
   * 
   * The callback is only triggered when the corresponding PIF analog input signal has changed.
   * 
   * @param[in] name  of the uncommitted value as specified in the configuration.
   * @param[in] unit  of the uncommitted value as specified in the con
   * @param[in] value calculated from the PIF analog input signal based on the configured gain and offset.
   */
  virtual void onPifUncommittedValue(const std::string& name, const std::string& unit, float value)
  { }

  /**
   * @brief Called when a connection loss is detected.
   * 
   * A connection loss can not be recovered. This happens, for example, if the USB connection is interrupted by
   * pulling the plug.
   * 
   * It is up to the client to call IRImager:disconnect(). This gives the client the ability to ensure a graceful
   * disconnect on its end.
   */
  virtual void onConnectionLost()
  { }

  /**
   * @brief Called when a connection timeout is detected.
   * 
   * Unlike with connection losses you may recover from a timeout. 
   * 
   * Connection timeouts are the only way to detect connection losses with Ethernet devices. This is due to the
   * fact that these devices continuously send UDP packages once they are powered. Besides receiving these packages
   * the SDK has no way of knowing whether the connection is lost.
   * 
   * It is up to the client to call IRImager:disconnect(). This gives the client the ability to ensure a graceful
   * disconnect on its end.
   */
  virtual void onConnectionTimeout()
  { }

  /**
   * @brief Callback method for synchronizing data. This is the very last method to be called for each raw data set.
   */
  virtual void onProcessExit() 
  { }
};

} // namespace optris