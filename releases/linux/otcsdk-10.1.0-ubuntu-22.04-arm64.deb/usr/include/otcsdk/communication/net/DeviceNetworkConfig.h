// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   DeviceNetworkConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the on device network configuration.
 * 
 * @date 2024-12-19
 */

#pragma once

#include <cstdint>

#include "otcsdk/communication/net/IpAddress.h"
#include "otcsdk/communication/net/Port.h"


namespace optris
{

/// Encapsulates the on device network configuration.
class DeviceNetworkConfig
{
public:
  /// Constructor.
  DeviceNetworkConfig() = default;

  /**
   * @brief Constructor.
   * 
   * @param[in] deviceIp        address.
   * @param[in] destinationIp   address for the device to send data to.
   * @param[in] destinationPort for the device to send data to.
   * @param[in] subnetMask      of the network.
   */
  DeviceNetworkConfig(const IpAddress& deviceIp, 
                      const IpAddress& destinationIp,
                      const Port&      destinationPort,
                      const IpAddress& subnetMask) noexcept;

  
  /** 
   * @brief Returns the IP address of the device.
   * 
   * @returns IP address of the device. 
   */
  const IpAddress& getDeviceIp() const noexcept;

  /**
   * @brief Returns the IP address to which the device sends its data to.
   * 
   * @return IP address to which the device sends its data to.
   */
  const IpAddress& getDestinationIp() const noexcept;

  /**
   * @brief Returns the port to which the device sends its data to.
   * 
   * @return port to which the device sends its data to.
   */
  const Port& getDestinationPort() const noexcept;

  /**
   * @brief Returns the subnet mask.
   * 
   * @return subnet mask.
   */
  const IpAddress& getSubnetMask() const noexcept;
  

  /**
   * @brief Sets the device IP address.
   * 
   * @param[in] address to set.
   */
  void setDeviceIp(const IpAddress& address) noexcept;

  /**
   * @brief Sets the destination IP address to which the device sends its data to.
   * 
   * @param[in] address to set.
   */
  void setDestinationIp(const IpAddress& address) noexcept;

  /**
   * @brief Sets the port to which the device sends its data to.
   * 
   * @param[in] port to set.
   */
  void setDestinationPort(const Port& port) noexcept;

  /**
   * @brief Sets the subnet mask.
   * 
   * @param[in] subnetMask to set.
   */
  void setSubnetMask(const IpAddress& subnetMask) noexcept;


private:
  IpAddress _deviceIp;
  IpAddress _destinationIp;
  Port      _destinationPort;

  IpAddress _subnetMask; 
};


// Inline implementations
inline DeviceNetworkConfig::DeviceNetworkConfig(const IpAddress& deviceIp, 
                                                const IpAddress& destinationIp,
                                                const Port&      destinationPort,
                                                const IpAddress& subnetMask) noexcept
  : _deviceIp{deviceIp}
  , _destinationIp{destinationIp}
  , _destinationPort{destinationPort}
  , _subnetMask{subnetMask}
{ }

inline const IpAddress& DeviceNetworkConfig::getDeviceIp() const noexcept
{
  return _deviceIp;
}

inline const IpAddress& DeviceNetworkConfig::getDestinationIp() const noexcept
{
  return _destinationIp;
}

inline const Port& DeviceNetworkConfig::getDestinationPort() const noexcept
{
  return _destinationPort;
}

inline const IpAddress& DeviceNetworkConfig::getSubnetMask() const noexcept
{
    return _subnetMask;
}

inline void DeviceNetworkConfig::setDeviceIp(const IpAddress& address) noexcept
{
  _deviceIp = address;
}

inline void DeviceNetworkConfig::setDestinationIp(const IpAddress& address) noexcept
{
  _destinationIp = address;
}

inline void DeviceNetworkConfig::setDestinationPort(const Port& port) noexcept
{
    _destinationPort = port;
}

inline void DeviceNetworkConfig::setSubnetMask(const IpAddress& subnetMask) noexcept
{
  _subnetMask = subnetMask;
}

} // namespace optris
