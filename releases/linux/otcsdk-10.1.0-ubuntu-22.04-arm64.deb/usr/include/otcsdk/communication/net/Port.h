// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   Port.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing an network port.
 * 
 * @date 2025-02-10
 */

#pragma once

#include <cstdint>
#include <string>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"


namespace optris
{

/**
 * @brief Encapsulates a network port number.
 * 
 * Port number a usually separated by a : from an IP address like
 * 
 *  192.168.0.2:50101
 * 
 * Here the port number is 50101.
 */
class Port
{
public:
  /// Type used to store the port number.
  using Number = std::uint16_t;


  /**
   * @brief Constructor.
   * 
   * The port number is set to 0.
   */
  Port() noexcept;

  /**
   * @brief Constructor.
   * 
   * Native byte order is expected.
   * 
   * @param[in] number of the port in [0, 65535].
   */
  Port(Number number) noexcept;

  /**
   * @brief Sets the port number from the given string.
   * 
   * @param[in] port string.
   * 
   * @throw SDKException if the given string does not contain a valid port number. 
   */
  Port(const std::string& port);


  /// Resets the port number to 0.
  void reset() noexcept;

  /**
   * @brief Sets the port number to the given value.
   * 
   * Native byte order is expected.
   * 
   * @param[in] number port number to set.
   */
  void setNumber(Number number) noexcept;

  /**
   * @brief Returns the port number.
   * 
   * Native byte order is used.
   * 
   * @return port number.
   */
  Number getNumber() const noexcept;

  /**
   * @brief Sets the port number from the given string.
   * 
   * @param[in] port number string.
   * 
   * @throw SDKException if the given string does not contain a valid port number. 
   */
  OTC_SDK_API void setFromString(const std::string& port) noexcept(false);

  /**
   * @brief Returns the port number as a string.
   * 
   * @return port number as a string.
   */
  OTC_SDK_API std::string toString() const noexcept;

  
  /// Equality operator.
  bool operator==(const Port& rhs) const noexcept;
  /// Unequality operator.
  bool operator!=(const Port& rhs) const noexcept;
  /// Less than operator.
  bool operator<(const Port& rhs) const noexcept;


private:
  /// Stored port number.
  Number _number;
};

// Utility functions
/**
 * @brief Output stream operator for port numbers.
 * 
 * @param[in] out  stream to write the port number to.
 * @param[in] port to output.
 *
 * @return used output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const Port& port) noexcept;


// Inline implementations
inline Port::Port() noexcept
  : _number{0}
{ }

inline Port::Port(Number number) noexcept
  : _number{number}
{ }

inline Port::Port(const std::string& port)
{
  setFromString(port);
}

inline void Port::reset() noexcept
{
  _number = 0;
}

inline void Port::setNumber(Number number) noexcept
{
  _number = number;
}

inline Port::Number Port::getNumber() const noexcept
{
  return _number;
}

inline bool Port::operator==(const Port& rhs) const noexcept
{
  return _number == rhs._number;
}

inline bool Port::operator!=(const Port& rhs) const noexcept
{
  return _number != rhs._number;
}

inline bool Port::operator<(const Port& rhs) const noexcept
{
  return _number < rhs._number;
}

} // namespace optris