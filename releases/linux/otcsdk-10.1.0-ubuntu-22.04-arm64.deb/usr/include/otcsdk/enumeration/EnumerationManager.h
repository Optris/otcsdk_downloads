// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   EnumerationManager.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that monitors available devices.
 * 
 * @date 2024-09-23
 */

#pragma once

#include <vector>
#include <thread>
#include <mutex>
#include <memory>
#include <atomic>
#include <set>
#include <condition_variable>
#include <unordered_set>
#include <unordered_map>

#include "otcsdk/Api.h"
#include "otcsdk/common/DeviceInfo.h"
#include "otcsdk/enumeration/EnumerationClient.h"
#include "otcsdk/enumeration/EnumerationDetector.h"


namespace optris
{

/**
 * @brief Detects and monitors available devices.
 * 
 * It detects devices that the SDK can potentially connect to.
 * 
 * This class is implemented with the help of the Singleton design pattern. As a consequence, you have to use
 * the EnumerationManager::getInstance() method to interact with it.
 * 
 * Furthermore, allows the registration of observers aka. EnumerationClient that want be informed if the detection
 * status of a device changes.
 */
class EnumerationManager
{
public:
  /// No copy constructor.
  OTC_SDK_API EnumerationManager(const EnumerationManager&) = delete;
  /// No copy assignment.
  OTC_SDK_API EnumerationManager& operator=(const EnumerationManager&) = delete;

  /// No move constructor.
  OTC_SDK_API EnumerationManager(EnumerationManager&&) = delete;
  /// No move assignment.
  OTC_SDK_API EnumerationManager& operator=(EnumerationManager&&) = delete;

  /// Destructor.
  OTC_SDK_API virtual ~EnumerationManager();


  /**
   * @brief Returns an instance of the EnumerationManager.
   * 
   * Only one instance per program is available (Singleton).
   * 
   * @return EnumerationManager instance.
   */
  OTC_SDK_API static EnumerationManager& getInstance() noexcept;
   

  /**
   * @brief Returns information about the currently detected devices.
   * 
   * @param[in] seconds  <  0 the method waits indefintfly for the first detection pass to complete.
   *                     == 0 the method will not wait.
   *                     >  0 the method waits the given amount of seconds for th first detection pass 
   *                          to complete.
   * 
   * @return a vector holding the current detected devices.
   */
  OTC_SDK_API std::vector<DeviceInfo> getDetectedDevices(int seconds = 0);


  /**
   * @brief Adds an observer/client that will be updated if a device detection status changes.
   *
   * @param[in] client callback client.
   */
  OTC_SDK_API void addClient(EnumerationClient* client);

  /**
   * @brief Removes the given observer/client.
   *
   * @param[in] client to remove.
   */
  OTC_SDK_API bool removeClient(EnumerationClient* client);

  
  /**
   * @brief Runs the connection event detection continuously.
   * 
   * This method blocks until stopRunning() is called from a different thread or until the program
   * terminates.
   * 
   * @see stopRunning()
   */
  OTC_SDK_API void run();

  /**
   * @brief Runs the connection event detection continuously in a dedicated thread.
   * 
   * This method runs until stopRunning() is called from a different thread or until the program
   * terminates.
   * 
   * @note All callback methods of a registered EnumerationClient are called from this detection thread.
   * 
   * @return true if the thread started within a second. False otherwise.
   * 
   * @see stopRunning()
   */
  OTC_SDK_API bool runAsync();

  /// Stops the continuous connection event detection.
  OTC_SDK_API void stopRunning();

  /**
   * @brief Returns whether the connection event detection is running.
   * 
   * @return whether the connection event detection is running.
   */
  OTC_SDK_API bool isRunning() const noexcept;


  /**
   * @brief Sets the minimum period in milliseconds for a single connection event detection run.
   * 
   * @param[in] period in milliseconds to set.
   */
  OTC_SDK_API void setDetectionPeriod(int period) noexcept;

  /**
   * @brief Returns the minimum period in milliseconds for a single connection event detection run.
   * 
   * @return minimum period in milliseconds for a single connection event detection run.
   */
  OTC_SDK_API int getDetectionPeriod() const noexcept;


  /**
   * @brief Registers a new detector for connected devices.
   * 
   * Existing detectors with the same name will be overriden.
   *
   * @param[in] name     under which to register the detector.
   * @param[in] detector to register.
   */
  OTC_SDK_API void registerDetector(const std::string& name, std::shared_ptr<EnumerationDetector> detector);

  /**
   * @brief Return the detector registered under the given name.
   * 
   * @param[in] name of the desired detector.
   *
   * @return shared pointer to the detector or a nullptr if a detector with the given name is not registered.
   */
  OTC_SDK_API std::shared_ptr<EnumerationDetector> getDetector(const std::string& name);
  

private:
  using Mutex     = std::mutex;
  using Lock      = std::unique_lock<Mutex>;
  using Condition = std::condition_variable;
  

  EnumerationManager();


  void detectDevices();

  void notifyClientsOfDetection(const DeviceInfo& deviceInfo);
  void notifyClientsOfLostDetection(const DeviceInfo& deviceInfo);

  void waitForFirstPass(int seconds);


  Mutex                _detectedDevicesMutex;
  std::set<DeviceInfo> _detectedDevices;

  Mutex                        _runMutex;
  std::atomic<bool>            _shutdown;
  std::atomic<bool>            _running;
  std::atomic<int>             _period;
  std::unique_ptr<std::thread> _thread;	

  Mutex     _firstPassMutex;
  Condition _firstPassCondition;
  bool      _firstPassComplete;

  Mutex                                  _clientsMutex;
  std::unordered_set<EnumerationClient*> _clients;

  Mutex                                                                 _detectorsMutex;
  std::unordered_map<std::string, std::shared_ptr<EnumerationDetector>> _detectors;
};


// Inline implementations
inline void EnumerationManager::setDetectionPeriod(int period) noexcept
{
  _period = period;
}

inline int EnumerationManager::getDetectionPeriod() const noexcept
{
  return _period;
}

} // namespace optris