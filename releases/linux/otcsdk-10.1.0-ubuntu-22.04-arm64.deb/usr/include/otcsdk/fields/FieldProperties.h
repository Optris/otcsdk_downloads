// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   FieldProperties.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains various enums representing properties of fields.
 * 
 * @date 2025-07-23
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"


namespace optris
{

/// Represents the different available shapes of fields.
enum class FieldShape
{
  Rectangle,  ///< Rectangular field.
};

/// Represents the different field modes that define what data point is calculated.
enum class FieldMode
{
  Minimum,  ///< Minimum temperature in °C.
  Maximum,  ///< Maximum temperature in °C.
  Mean,     ///< Mean temperature in °C.
};


// Utility functions
/**
 * @brief Returns a string representation of the given field shape.
 * 
 * @note Use `fieldShapeToString()` in Python instead.
 * 
 * @param[in] shape for which a string representation is desired.
 * 
 * @return string representation of the given field shape.
 */
OTC_SDK_API std::string toString(FieldShape shape) noexcept;

/**
 * @brief Returns a string representation of the given field mode.
 * 
 * @note Use `fieldModeToString()` in Python instead.
 * 
 * @param[in] fieldMode for which a string representation is desired.
 * 
 * @return string representation of the given field mode.
 */
OTC_SDK_API std::string toString(FieldMode fieldMode) noexcept;

/**
 * @brief Ouput stream operator for field shapes.
 * 
 * @param[in] out   stream to ouput to.
 * @param[in] shape to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, FieldShape shape) noexcept;

/**
 * @brief Ouput stream operator for field mode.
 * 
 * @param[in] out       stream to ouput to.
 * @param[in] fieldMode to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, FieldMode fieldMode) noexcept;

} // namespace optris