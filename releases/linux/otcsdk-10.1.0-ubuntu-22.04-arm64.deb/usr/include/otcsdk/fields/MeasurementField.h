// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   MeasurementField.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the properties and data of a rectangular measurement field.
 * 
 * @date 2024-12-19
 */

#pragma once

#include <string>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/TemperatureConverter.h"
#include "otcsdk/fields/MeasurementFieldConfig.h"
#include "otcsdk/fields/MeasurementFieldIterator.h"


namespace optris
{

/**
 * @brief Rectangular measurement field with individual radiation parameters.
 *
 * Once added via the IRImager the setters will no loner affect the processing of the field because the IRImager creates an
 * internal copy of the field.
 */
class MeasurementField
{
  // Special iterator access.
  friend class ConstMeasurementFieldIterator;
  

public:
  /// Constructor.
  OTC_SDK_API MeasurementField() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] config  to create a measurement field from.
   * @param[in] fieldId uniquely identifying the measurement field.
   */
  OTC_SDK_API MeasurementField(const MeasurementFieldConfig& config, long long fieldId) noexcept;


  /// Copy constructor.
  OTC_SDK_API MeasurementField(const MeasurementField& rhs) = default;
  /// Copy assignment.
  OTC_SDK_API MeasurementField& operator=(const MeasurementField& rhs) = default;

  /// Move constructor.
  OTC_SDK_API MeasurementField(MeasurementField&& rhs) noexcept = default;
  /// Move assignment.
  OTC_SDK_API MeasurementField& operator=(MeasurementField&& rhs) noexcept = default;

  /// Destructor.
  OTC_SDK_API ~MeasurementField() = default;


  /**
   * @brief Returns the configuration of the measurement field.
   * 
   * @return configuration of the measurement field.
   */
  const MeasurementFieldConfig& getConfig() const noexcept;

  /**
   * @brief Returns the ID uniquely identifying the measurement field.
   * 
   * @return ID of the measurement field.
   */
  long long getId() const noexcept;

  /**
   * @brief Returns the index of the measurement field.
   * 
   * @return index of the measurement field. 
   */
  int getIndex() const noexcept;

  /**
   * @brief Sets the index of the measurement field.
   *
   * @param[in] index to set.
   */
  void setIndex(int index) noexcept;

  /**
   * @brief Returns the name of the measurement field.
   * 
   * @return name of the measurement field.
   */
  const std::string& getName() const noexcept;

  /**
   * @brief Sets the name of the measurement field.
   * 
   * @param[in] name of the measurement field.
   */
  void setName(const std::string& name) noexcept;

  /**
   * @brief Returns the field data value at the given index.
   * 
   * @param[in] index of the desired field data.
   * 
   * @return field data value at the given index.
   * 
   * @throw SDKException if the index is out of range.
   */
  OTC_SDK_API unsigned short getValue(int index) const;

  /**
   * @brief Returns the temperature in in °C at the given index.
   * 
   * @param[in] index of the desired field temperature.
   * 
   * @return temperature in in °C at the given index.
   * 
   * @throw SDKException if index is out of range.
   */
  float getTemperature(int index) const;

  /**
   * @brief Returns the field data value at the given coordinates.
   * 
   * @param[in] x coordinate.
   * @param[in] y coordinate.
   * 
   * @return field data value at the given coordinates.
   * 
   * @throw SDKException if the coordinates are out of range.
   */
  OTC_SDK_API unsigned short getValue(int x, int y) const;

  /**
   * @brief Returns the temperature in in °C at the given coordinates.
   * 
   * @param[in] x coordinate.
   * @param[in] y coordinate.
   * 
   * @return temperature in in °C at the given coordinate.
   * 
   * @throw SDKException if the coordinates are out of range.
   */
  float getTemperature(int x, int y) const noexcept(false);


  /**
   * @brief Returns an iterator with read access.
   * 
   * The iterator traverses the measurement field in a row major fashion.
   * 
   * @return iterator with read access.
   */
  ConstMeasurementFieldIterator getConstIterator() const noexcept;

  /**
   * @brief Returns the precision of the temperatures stored in the measurement field.
   * 
   * @return precision of the temperatures stored in the measurement field.
   */
  TemperaturePrecision getTemperaturePrecision() const noexcept;

  /**
   * @brief Returns the x-coordinate of the upper left corner.
   * 
   * @return x-coordinate of the upper left corner.
   */
  int getX() const noexcept;

  /**
   * @brief Returns the y-coordinate of the upper left corner.
   * 
   * @return y-coordinate of the upper left corner.
   */
  int getY() const noexcept;

  /**
   * @brief Sets the position of the measurement field  by providing the coordinates of the upper
   *        left corner.
   * 
   * @param[in] x coordinate of the upper left corner of the rectangular field.
   * @param[in] y coordinate of the upper left corner of the rectangular field.
   */
  void setPosition(int x, int y) noexcept;

  /**
   * @brief Returns the shape of the measurement field.
   * 
   * @return shape of the measurement field.
   */
  FieldShape getShape() const noexcept;

  /**
   * @brief Returns the mode for the measurement field.
   * 
   * @return mode for the measurement field.
   */
  FieldMode getMode() const noexcept;

  /**
   * @brief Sets the mode for the measurement field.
   * 
   * @param[in] mode to set.
   */
  void setMode(FieldMode mode) noexcept;

  /**
   * @brief Returns the width in pixels of the field.
   * 
   * @return width in pixels of the field.
   */
  int getWidth() const noexcept;

  /**
   * @brief Returns the height in pixels of the field.
   * 
   * @return height in pixels of the field.
   */
  int getHeight() const noexcept;

  /**
   * @brief Returns the overall size of the field (width * height).
   * 
   * @return size of the field.
   */
  int getSize() const noexcept;

  /**
   * @brief Resizes the measurement field.
   * 
   * @param[in] width  in pixels of the resized measurement field.
   * @param[in] height in pixels of the resized measurement field.
   */
  OTC_SDK_API void resize(int width, int height);


  /**
   * @brief Returns the emissivity of the field.
   * 
   * @return emissivity of the field. 
   */
  float getEmissivity() const noexcept;

  /**
   * @brief Returns the transmissivity of the field.
   * 
   * @return transmissivity of the field. 
   */
  float getTransmissivity() const noexcept;

  /**
   * @brief Returns the set ambient temperature in °C.
   * 
   * @return ambient temperature in °C. It will be equal or less to INVALID_TEMPERATURE if the
   *         SDK is forced to estimate it.
   */
  float getAmbientTemperature() const noexcept;


  /**
   * @brief Sets the radiation parameters stored in the measurement field.
   * 
   * @param[in] emissivity         for the measurement field. Should be in [0, 1].
   * @param[in] transmissivity     for the measurement field. Should be in [0, 1].
   * @param[in] ambientTemperature in °C. Set to INVALID_TEMPERATURE or less to force the SDK to estimate the
   *                               ambient temperature based on internal probe readings.
   *
   * @throw SDKException if emissivity or transmissivity is not in [0, 1].
   */
  OTC_SDK_API void setRadiationParameters(float emissivity, float transmissivity, float ambientTemperature);


  /**
   * @brief Returns the overall mean temperature of the field in °C.
   * 
   * @return overall mean temperature of the field in °C. 
   */
  float getMeanTemperature() const noexcept;

  /**
   * @brief Returns the minimum temperature in the field in °C.
   * 
   * @return minimum temperature in the field in °C. 
   */
  float getMinTemperature() const noexcept;

  /**
   * @brief Returns the maximum temperature in the field in °C.
   * 
   * @return maximum temperature in the field in °C. 
   */
  float getMaxTemperature() const noexcept;

  /**
   * @brief Returns the data point specified by the the mode of this field.
   * 
   * @return data point  specified by the the mode of this field.
   */
  OTC_SDK_API float getDataPoint() const noexcept;

  /**
   * @brief Sets the mean, minimum and maximum temperatures in °C.
   * 
   * @param[in] mean temperature in °C. 
   * @param[in] min  temperature in °C.
   * @param[in] max  temperature in °C.
   */
  void setTemperatures(float mean, float min, float max) noexcept;


  /**
   * @brief Returns the temperature converter.
   *
   * It can be used to convert and validate the thermal frame values to and from temperatures in °C.
   * 
   * @return temperature converter.
   */
  TemperatureConverter getConverter() const noexcept;
  

  /**
   * @brief Returns a complete copy of this frame.
   * 
   * @return a complete copy of this frame.
   */
  MeasurementField clone() const noexcept;

  /**
   * @brief Sets the thermal field data values.
   * 
   * The provided data may be modified based on the given temperature precision.
   *
   * @param[in] source     to set the field data values from.
   * @param[in] frameWidth width in pixels of the frame containing the measurement field.
   * @param[in] precision  of the temperature values.
   */
  OTC_SDK_API void setData(const unsigned short* source, int frameWidth, TemperaturePrecision precision);

  /**
   * @brief Sets the field data values from raw data.
   * 
   * @param[in] source    to set the field data values from.
   * @param[in] precision of the thermal values.
   */
  OTC_SDK_API void setFromRawData(const void* source, TemperaturePrecision precision);

  /**
   * @brief Copies the thermal data as degree Celsius to a one-dimensional array or vector.
   * 
   * @warning Make sure the destination has at least the size returned by getSize().
   * 
   * @param[out] destination to copy the internal data to.
   * @param[in]  size        as element count. The specified size is limited to [0, getSize()].
   */
  OTC_SDK_API void copyTemperaturesTo(float* destination, int size) const noexcept;

  /**
   * @brief Copies the internal values to a one-dimensional array or vector.
   * 
   * @warning Make sure the destination has at least the size returned by getSize().
   * 
   * @param[out] destination to copy the internal data to.
   * @param[in]  size        as element count. The specified size is limited to [0, getSize()].
   */
  OTC_SDK_API void copyDataTo(unsigned short* destination, int size) const noexcept;

  /**
   * @brief Returns a pointer to the first element of the internal value array.
   * 
   * @return pointer to the first element of the internal value array.
   */
  const unsigned short* getData() const noexcept;
  

private:
  /// Measurement field configuration.
  MeasurementFieldConfig _config;

  /// Id identifying the measurement field.
  long long _id;
  /// Index identifying the measurement field.
  int _index;

  /// Thermal values of the measurement field.
  std::vector<unsigned short> _values;

  /// Mean temperature in °C across the measurement field.
  float _meanTemperature;
  /// Minimum temperature in °C within the measurement field.
  float _minTemperature;
  /// Maximum temperature in °C within the measurement field.
  float _maxTemperature;

  /// Converts the internal values of the data field into temperature in °C.
  TemperatureConverter _converter;
};


// Inline implementations
inline const MeasurementFieldConfig& MeasurementField::getConfig() const noexcept
{
  return _config;
}

inline long long MeasurementField::getId() const noexcept
{
  return _id;
}

inline int MeasurementField::getIndex() const noexcept
{
  return _index;
}

inline void MeasurementField::setIndex(int index) noexcept
{
  _index = index;
}

inline const std::string& MeasurementField::getName() const noexcept
{
  return _config.name;
}

inline void MeasurementField::setName(const std::string& name) noexcept
{
  _config.name = name;
}

inline float MeasurementField::getTemperature(int index) const noexcept(false)
{
  return _converter.toTemperature(getValue(index));
}

inline float MeasurementField::getTemperature(int x, int y) const noexcept(false)
{
  return _converter.toTemperature(getValue(x, y));
}

inline ConstMeasurementFieldIterator MeasurementField::getConstIterator() const noexcept
{
  return ConstMeasurementFieldIterator{*this};
}

inline TemperaturePrecision MeasurementField::getTemperaturePrecision() const noexcept
{
  return _converter.getPrecision();
}

inline int MeasurementField::getX() const noexcept
{
  return _config.positionX;
}

inline int MeasurementField::getY() const noexcept
{
  return _config.positionY;
}

inline void MeasurementField::setPosition(int x, int y) noexcept
{
  _config.positionX = x;
  _config.positionY = y;
}

inline FieldShape MeasurementField::getShape() const noexcept
{
  return _config.shape;
}

inline FieldMode MeasurementField::getMode() const noexcept
{
  return _config.mode;
}

inline void MeasurementField::setMode(FieldMode mode) noexcept
{
  _config.mode = mode;
}

inline int MeasurementField::getWidth() const noexcept
{
  return _config.width;
}

inline int MeasurementField::getHeight() const noexcept
{
  return _config.height;
}

inline int MeasurementField::getSize() const noexcept
{
  return static_cast<int>(_values.size());
}

inline float MeasurementField::getEmissivity() const noexcept
{
  return _config.emissivity;
}

inline float MeasurementField::getTransmissivity() const noexcept
{
  return _config.transmissivity;
}

inline float MeasurementField::getAmbientTemperature() const noexcept
{
  return _config.ambientTemperature;
}

inline float MeasurementField::getMeanTemperature() const noexcept
{
  return _meanTemperature;
}

inline float MeasurementField::getMinTemperature() const noexcept
{
  return _minTemperature;
}

inline float MeasurementField::getMaxTemperature() const noexcept
{
  return _maxTemperature;
}

inline void MeasurementField::setTemperatures(float mean, float min, float max) noexcept
{
  _meanTemperature = mean;
  _minTemperature  = min;
  _maxTemperature  = max;
}

inline TemperatureConverter MeasurementField::getConverter() const noexcept
{
  return _converter;
}

inline MeasurementField MeasurementField::clone() const noexcept
{
  return MeasurementField{*this};
}

inline const unsigned short* MeasurementField::getData() const noexcept
{
  return _values.data();
}

} // namespace optris
