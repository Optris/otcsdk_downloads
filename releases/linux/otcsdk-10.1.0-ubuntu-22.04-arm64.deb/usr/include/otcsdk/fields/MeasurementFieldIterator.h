// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   MeasurementFieldIterator.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class realizing the iteration over measurement field data.
 * 
 * @date 2025-05-12
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"


namespace optris
{

// Forward declaration
class MeasurementField;


/// Iterates over a measurement field in a row major fashion and grants read access.
class ConstMeasurementFieldIterator
{
public:
  /// Container type storing the frame values.
  using Container = std::vector<unsigned short>;


  /**
   * @brief Constructor.
   * 
   * @param[in] field measurement field to iterate over.
   */
  OTC_SDK_API explicit ConstMeasurementFieldIterator(const MeasurementField& field) noexcept;


  /**
   * @brief Returns whether there is a next measurement field value.
   * 
   * @return true if there is a next measurement field value. False otherwise.
   */
  bool hasNext() const noexcept;

  /// Moves to the next measurement field value.
  OTC_SDK_API void next();


  /**
   * @brief Returns the current measurement field value.
   * 
   * @return current measurement field value.
   */
  unsigned short getValue() const noexcept;


  /**
   * @brief Returns the index of the current measurement field value.
   * 
   * @return index of the current measurement field value.
   */
  int getIndex() const noexcept;

  /**
   * @brief Returns the x-coordinate of the current measurement field value.
   * 
   * @return x-coordinate of the current measurement field value.
   */
  int getX() const noexcept;

  /**
   * @brief Returns the y-coordinate of the current measurement field value.
   * 
   * @return y-coordinate of the current measurement field value.
   */
  int getY() const noexcept;


private:
  /// Iterator pointing to the current field value.
  Container::const_iterator _iterator;
  /// Iterator pointing behind the end of the data array.
  Container::const_iterator _end;

  /// Width in pixels of the measurement field.
  int _width;

  /// Current index.
  int _index;
  /// Current x-coordinate.
  int _x;
  /// Current y-coordinate.
  int _y;
};


// Inline implementations
inline bool ConstMeasurementFieldIterator::hasNext() const noexcept
{
  return _iterator != _end;
}

inline unsigned short ConstMeasurementFieldIterator::getValue() const noexcept
{
  return *_iterator;
}

inline int ConstMeasurementFieldIterator::getIndex() const noexcept
{
  return _index;
}

inline int ConstMeasurementFieldIterator::getX() const noexcept
{
  return _x;
}

inline int ConstMeasurementFieldIterator::getY() const noexcept
{
  return _y;
}

} // namespace optris