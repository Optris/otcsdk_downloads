// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   DeviceInfo.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating important information about devices.
 * 
 * @date 2025-02-11
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/common/DeviceType.h"
#include "otcsdk/communication/net/IpAddress.h"
#include "otcsdk/communication/net/Port.h"


namespace optris
{

/**
 * @brief Holds important information about a device.
 * 
 * Instances of this class are provided by the EnumerationManager and can be used to establish an connection
 * through an IRImager implementation.
 */
class DeviceInfo
{
public:
  /// Constructor.
  OTC_SDK_API DeviceInfo() noexcept;


  /**
   * @brief Determines the device type based on the provided hardware and firmware revisions.
   * 
   * @return determined device type.
   */
  OTC_SDK_API static DeviceType determineDeviceType(unsigned short hardwareRevision, unsigned short firmwareRevision) noexcept;


  /**
   * @brief Sets the serial number of the device.
   * 
   * @param[in] serialNumber to set.
   */
  OTC_SDK_API void setSerialNumber(unsigned long serialNumber) noexcept;

  /**
   * @brief Returns the serial number of the device.
   * 
   * @return serial number of the device.
   */
  OTC_SDK_API unsigned long getSerialNumber() const noexcept;

  /**
   * @brief Sets the connection interface of the device.
   * 
   * This can, for example, be USB or Ethernet.
   * 
   * @param[in] connectionInterface to set.
   */
  OTC_SDK_API void setConnectionInterface(const std::string& connectionInterface) noexcept;

  /**
   * @brief Returns the connection interface of the device.
   * 
   * This can, for example, be USB or Ethernet.
   * 
   * @return connection interface of the device.
   */
  OTC_SDK_API const std::string& getConnectionInterface() const noexcept;

  /**
   * @brief Sets the IP address.
   * 
   * For Ethernet connections this refers to the IP address of the device.
   * 
   * @param[in] ipAddress address to set.
   */
  OTC_SDK_API void setIpAddress(const IpAddress& ipAddress) noexcept;

  /**
   * @brief Returns the IP address.
   * 
   * For Ethernet connections this refers to the IP address of the device.
   * 
   * @return IP address.
   */
  OTC_SDK_API const IpAddress& getIpAddress() const noexcept;

  /**
   * @brief Sets the port.
   * 
   * For Ethernet connections this refers to the port the device will send its data to.
   * 
   * @param[in] port to set.
   */
  OTC_SDK_API void setPort(const Port& port) noexcept;

  /**
   * @brief Returns the port.
   * 
   * For Ethernet connections this refers to the port the device will send its data to.
   * 
   * @return port.
   */
  OTC_SDK_API const Port& getPort() const noexcept;

  /**
   * @brief Return the device type.
   * 
   * @return device type.
   */
  OTC_SDK_API DeviceType getDeviceType() const noexcept;

  /**
   * @brief Sets the hardware and firmware revisions.
   * 
   * @param[in] hardware revision to set.
   * @param[in] firmware revision to set.
   */
  OTC_SDK_API void setRevisions(unsigned short hardware, unsigned short firmware) noexcept;

  /**
   * @brief Returns the hardware revision.
   * 
   * @return hardware revision.
   */
  OTC_SDK_API unsigned short getHardwareRevision() const noexcept;

    /**
   * @brief Returns the firmware revision.
   * 
   * @return firmware revision.
   */
  OTC_SDK_API unsigned short getFirmwareRevision() const noexcept;


  /**
   * @brief Returns a complete copy of this informatin.
   * 
   * @return a complete copy of this information.
   */
  OTC_SDK_API DeviceInfo clone() const noexcept;


  /// Equals operator.
  OTC_SDK_API bool operator==(const DeviceInfo& rhs) const noexcept;
  /// Unequals operator.
  OTC_SDK_API bool operator!=(const DeviceInfo& rhs) const noexcept;
  /// Less than operator.
  OTC_SDK_API bool operator<(const DeviceInfo& rhs) const noexcept;


private:
  unsigned long _serialNumber;

  std::string _connectionInterface;

  IpAddress _ipAddress;
  Port      _port;

  DeviceType _deviceType;

  unsigned short _hardwareRevision;
  unsigned short _firmwareRevision;
};


// Inline implementations
inline void DeviceInfo::setSerialNumber(unsigned long serialNumber) noexcept
{
  _serialNumber = serialNumber;
}

inline unsigned long DeviceInfo::getSerialNumber() const noexcept
{
  return _serialNumber;
}

inline void DeviceInfo::setConnectionInterface(const std::string& connectionInterface) noexcept
{
  _connectionInterface = connectionInterface;
}

inline const std::string& DeviceInfo::getConnectionInterface() const noexcept
{
  return _connectionInterface;
}

inline void DeviceInfo::setIpAddress(const IpAddress& ipAddress) noexcept
{
  _ipAddress = ipAddress;
}

inline const IpAddress& DeviceInfo::getIpAddress() const noexcept
{
  return _ipAddress;
}

inline void DeviceInfo::setPort(const Port& port) noexcept
{
  _port = port;
}

inline const Port& DeviceInfo::getPort() const noexcept
{
  return _port;
}

inline DeviceType DeviceInfo::getDeviceType() const noexcept
{
  return _deviceType;
}

inline unsigned short DeviceInfo::getHardwareRevision() const noexcept
{
  return _hardwareRevision;
}

inline unsigned short DeviceInfo::getFirmwareRevision() const noexcept
{
  return _firmwareRevision;
}

inline DeviceInfo DeviceInfo::clone() const noexcept
{
  return DeviceInfo{*this};
}

inline bool DeviceInfo::operator==(const DeviceInfo& rhs) const noexcept
{
  return _serialNumber == rhs._serialNumber;
}

inline bool DeviceInfo::operator!=(const DeviceInfo& rhs) const noexcept
{
  return _serialNumber != rhs._serialNumber;
}

inline bool DeviceInfo::operator<(const DeviceInfo& rhs) const noexcept
{
  return _serialNumber < rhs._serialNumber;
}

} // namespace optris