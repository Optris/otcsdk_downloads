// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   VersionInfo.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating version and build information about the SDK.
 * 
 * @date 2025-04-07
 */

#pragma once

#include <string>

#include "otcsdk/Api.h"


namespace optris
{

/**
 * @brief Encapsulates version and build information about the SDK.
 * 
 * The version is represented in the format: major.minor.patch.
 */
class VersionInfo
{
public:
  /// Constructor.
  VersionInfo() = default;


  /**
   * @brief Returns the SDK version as a string in the format: "major.minor.patch".
   * 
   * @return SDK version as string.
   */
  OTC_SDK_API std::string getVersionString() noexcept;

  /**
   * @brief Returns the major version of the SDK.
   * 
   * @return major version of the SDK.
   */
  OTC_SDK_API int getMajorVersion() noexcept;

  /**
   * @brief Returns the minor version of the SDK.
   * 
   * @return minor version of the SDK.
   */
  OTC_SDK_API int getMinorVersion() noexcept;

  /**
   * @brief Returns the patch version of the SDK.
   * 
   * @return patch version of the SDK.
   */
  OTC_SDK_API int getPatchVersion() noexcept;

  /**
   * @brief Compares the provided version with the one of the SDK.
   * 
   * @return 0  if both versions are equal.
   *         -1 if the SDK version is less than the provided one.
   *         +1 if the SDK version is greater than the provide one. 
   */
  OTC_SDK_API int compareVersion(int major, int minor, int patch) noexcept;


  /**
   * @brief Returns the build type of the SDK.
   * 
   * @return "Release" for release builds and "Debug" for debug builds.
   */
  OTC_SDK_API std::string getBuildType() noexcept;

  /**
   * @brief Returns the UTC build date of the SDK in ISO format.
   * 
   * @return the UTC build date in ISO format.
   */
  OTC_SDK_API std::string getBuildDate() noexcept;

  /**
   * @brief Returns the first part of the hash of the commit that was used to build the SDK.
   * 
   * @return first part of the hash of the commit that was used to build the SDK.
   */
  OTC_SDK_API std::string getCommitHash() noexcept;

  /**
   * @brief Returns the date of the commit that was used to build the SDK in ISO format.
   * 
   * @return date of the commit that was used to build the SDK in ISO format
   */
  OTC_SDK_API std::string getCommitDate() noexcept;

  /**
   * @brief Returns the branch name used to build the SDK.
   * 
   * @return branch name used to build the SDK.
   */
  OTC_SDK_API std::string getCommitBranch() noexcept;

  /**
   * @brief Returns the name of the SDK.
   * 
   * @return name of the SDK.
   */
  OTC_SDK_API std::string getName() noexcept;

  /**
   * @brief Returns the name of the company that created the SDK.
   * 
   * @return name of the company that created the SDK.
   */
  OTC_SDK_API std::string getCompany() noexcept;

  /**
   * @brief Returns the copyright string of the SDK.
   * 
   * @return copyright string of the SDK.
   */
  OTC_SDK_API std::string getCopyright() noexcept;

  /**
   * @brief Returns a description of the SDK.
   * 
   * @return description of the SDK.
   */
  OTC_SDK_API std::string getDescription() noexcept;

  /**
   * @brief Returns the name of the operating system for which the SDK was build for.
   * 
   * Examples: Windows, Linux.
   * 
   * @return name of the operating system for which the SDK was build for.
   */
  OTC_SDK_API std::string getBuildOS() noexcept;

  /**
   * @brief Returns the name of the platform for which the SDK was build for.
   * 
   * Examples: AMD64, ARM64.
   * 
   * @return name of the platform for which the SDK was build for.
   */
  OTC_SDK_API std::string getBuildPlatform() noexcept;
};

} // namespace optris