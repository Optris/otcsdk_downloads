// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   Slope.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the parameters for a linear transformation.
 * 
 * @date 2026-07-01
 */

#pragma once

#include <ostream>


namespace optris
{

/**
 * @brief Encapsulates the parameters of a linear transformation.
 * 
 * y(x) = gain * x + offset
 */
class Slope
{
public:
  /// Constructor.
  Slope() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] gain   of the linear transformation.
   * @param[in] offset of the linear transformation.
   */
  Slope(float gain, float offset) noexcept;


  /// Gain of the linear transformation.
  float gain;
  /// Offset of the linear transformation.
  float offset;
};


// Utility functions
/**
 * @brief Output stream operator for Slope.
 * 
 * @param[in] out   stream to use.
 * @param[in] slope to output. 
 *
 * @return used output stream. 
 */
std::ostream& operator<<(std::ostream& out, const Slope& slope) noexcept;


// Inline implementations
inline Slope::Slope() noexcept
  : gain{1.F}
  , offset{0.F}
{}

inline Slope::Slope(float gain, float offset) noexcept
  :gain{gain}
  , offset{offset}
{}

inline std::ostream& operator<<(std::ostream& out, const Slope& slope) noexcept
{
  return (out << "gain: " << slope.gain << ", offset: " << slope.offset);
}

} // namespace optris