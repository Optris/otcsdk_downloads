// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   SnapshotEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding all the information about a snapshot event.
 * 
 * @date 2024-12-09
 */

#pragma once

#include "otcsdk/Api.h"


namespace optris
{

/// Represents the different triggers of an event.
enum class SnapshotTrigger
{
  DigitalInput, ///< Triggered by digital input.
  AnalogInput,  ///< Triggered by analog input.
  Software,     ///< Triggered by software.
};


/// Represents the different event types.
enum class SnapshotType
{
  Snapshot,       ///< Event source is snapshot.
  SnapshotOnEdge  ///< Event source is snapshot on edge.
};


/// Encapsulates data about a snapshot event.
struct OTC_SDK_API SnapshotEvent
{
  /// Constructor.
  SnapshotEvent() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] trigger input trigger that created the snapshot event.
   * @param[in] channel on which the trigger occurred.
   * @param[in] type    of the snapshot event.
   */
  SnapshotEvent(SnapshotTrigger trigger, unsigned char channel, SnapshotType type) noexcept;


  /// Input trigger type of the snapshot event.
  SnapshotTrigger trigger;
  /// Analog or digital input channel of the snapshot event.
  unsigned char channel;
  /// Type of the snapshot event.
  SnapshotType type;
};


// Inline implementations
inline SnapshotEvent::SnapshotEvent() noexcept
  : trigger(SnapshotTrigger::DigitalInput)
  , channel(0)
  , type(SnapshotType::Snapshot)
{ }

inline SnapshotEvent::SnapshotEvent(SnapshotTrigger _trigger,  unsigned char _channel, SnapshotType _type) noexcept
  : trigger(_trigger)
  , channel(_channel)
  , type(_type)
{ }

}  // namespace optris