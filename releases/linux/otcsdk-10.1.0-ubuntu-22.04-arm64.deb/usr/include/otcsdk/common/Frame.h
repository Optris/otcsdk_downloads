// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   Frame.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing a data frame received from a device.
 * 
 * @date 2025-01-21
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/FrameIterator.h"


namespace optris
{

/**
 * @brief Represents a data frame received from a device.
 * 
 * The encapsulated data may represent thermal or energy measurements in an internal format. See the
 * specialized child classes like ThermalFrame for more details.
 * 
 * The origin of coordinates is located in the upper left corner with the x-axis pointing right and
 * the y-axis pointing down.
 */
class Frame
{
  // Special iterator access.
  friend class ConstFrameIterator;


public:
  /// Constructor.
  OTC_SDK_API Frame() noexcept;

  /// Copy constructor.
  OTC_SDK_API Frame(const Frame&) = default;
  /// Copy assignment.
  OTC_SDK_API Frame& operator=(const Frame&) = default;

  /// Move constructor.
  OTC_SDK_API Frame(Frame&&) = default;
  /// Move assignment.
  OTC_SDK_API Frame& operator=(Frame&&) = default;

  /// Destructor.
  OTC_SDK_API virtual ~Frame() noexcept = default;


  /**
   * @brief Returns the frame data value at the given index.
   * 
   * @param[in] index of the desired frame data.
   * 
   * @return frame data value at the given index.
   * 
   * @throw SDKException if the index is out of range.
   */
  OTC_SDK_API unsigned short getValue(int index) const noexcept(false);

  /**
   * @brief Returns the frame data value at the given coordinates.
   * 
   * @param[in] x coordinate.
   * @param[in] y coordinate.
   * 
   * @return frame data value at the given coordinates.
   * 
   * @throw SDKException if the coordinates are out of range.
   */
  OTC_SDK_API unsigned short getValue(int x, int y) const noexcept(false);


  /**
   * @brief Returns an iterator with read access.
   * 
   * The iterator traverses the frame in a row major fashion.
   * 
   * @return iterator with read access.
   */
  OTC_SDK_API ConstFrameIterator getConstIterator() const noexcept;


  /**
   * @brief Returns the width in pixels of the frame.
   * 
   * @return width in pixel of the frame.
   */
  OTC_SDK_API int getWidth() const noexcept;

  /**
   * @brief Returns the height in pixel of the frame.
   * 
   * @return height in pixels of the frame.
   */
  OTC_SDK_API int getHeight() const noexcept;

  /**
   * @brief Returns the overall size in pixels of the frame (width * height).
   * 
   * @return size in pixels of the frame.
   */
  OTC_SDK_API int getSize() const noexcept;

  /**
   * @brief Returns whether the frame is empty.
   * 
   * @return true if the frame is empty. False otherwise.
   */
  OTC_SDK_API bool isEmpty() const noexcept;


  /// Clears the frame data.
  OTC_SDK_API void clear();

  /**
   * @brief Resizes the frame.
   * 
   * @param[in] width  of the resized frame in pixels.
   * @param[in] height of the resized frame in pixels.
   */
  OTC_SDK_API void resize(int width, int height);


  /**
   * @brief Returns a complete copy of this frame.
   * 
   * @return a complete copy of this frame.
   */
  OTC_SDK_API Frame clone() const noexcept;

  /**
   * @brief Sets the frame data values.
   * 
   * @param[in] source to set the frame data values from.
   */
  OTC_SDK_API void setData(const unsigned short* source);

  /**
   * @brief Sets the frame data values from raw data.
   * 
   * @param[in] source to set the frame data values from.
   */
  OTC_SDK_API void setFromRawData(const void* source);

  /**
   * @brief Copies the internal data to a one-dimensional array or vector.
   * 
   * @warning Make sure the destination has at least the size returned by getSize().
   * 
   * @param[out] destination to copy the internal data to.
   * @param[in]  size        as element count. The specified size is limited to [0, getSize()].
   */
  OTC_SDK_API void copyDataTo(unsigned short* destination, int size) const noexcept;

  /**
   * @brief Returns a pointer to the first element of the internal value array.
   * 
   * @return pointer to the first element of the internal value array.
   */
  OTC_SDK_API const unsigned short* getData() const noexcept;


protected:
  /// Frame data.
  std::vector<unsigned short> _values;


private:
  /// Width of the frame in pixels.
  int _width;
  /// Height of the frame in pixels.
  int _height;
};


// Inline implementation
inline ConstFrameIterator Frame::getConstIterator() const noexcept
{
  return ConstFrameIterator{*this};
}

inline int Frame::getWidth() const noexcept
{
  return _width;
}

inline int Frame::getHeight() const noexcept
{
  return _height;
}

inline int Frame::getSize() const noexcept
{
  return static_cast<int>(_values.size());
}

inline bool Frame::isEmpty() const noexcept
{
  return _values.empty();
}

inline Frame Frame::clone() const noexcept
{
  return Frame{*this};
}

inline const unsigned short* Frame::getData() const noexcept
{
  return _values.data();
}

} // namespace optris
