// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   OperationMode.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface definition for classes specifying valid sets of configuration 
 *         settings.
 * 
 * @date 2025-04-14
 */

#pragma once

#include <string>


namespace optris
{

/**
 * @brief Defines the interface for classes realizing operation modes.
 * 
 * Each operation mode encapsulates a valid combination of the following configuration settings:
 * 
 *  - Optics
 *  - Temperature range
 *  - Output video format
 * 
 * The available operation modes depend on the device, its optics, its calibrations, the video format
 * definitions and the type of connection to the device (USB, Ethernet).
 */
class OperationMode
{
public:
  /// Constructor.
  OperationMode() = default;

  /// No copy constructor. 
  OperationMode(const OperationMode&) = delete;
  /// No copy assignment. 
  OperationMode& operator=(const OperationMode&) = delete;

  /// No move constructor. 
  OperationMode(OperationMode&&) = delete;
  /// No move assignment. 
  OperationMode& operator=(OperationMode&&) = delete;

  /// Destructor.
  virtual ~OperationMode() = default;


  // Optics
  /**
   * @brief Returns the field of view in degrees of the optics.
   * 
   * @return field of view in degrees of the optics.
   */
  virtual int getFieldOfView() const noexcept = 0;

  /**
   * @brief Returns an optional string that further specifies the optics.
   * 
   * @return optional string that further specifies the optics.
   */
  virtual std::string getOpticsText() const noexcept = 0;

  // Temperature range
  /**
   * @brief Returns the lower limit temperature in °C depended whether the range is extended.
   * 
   * @return lower limit temperature in °C depended whether the range is extended.
   */
  virtual float getTemperatureLowerLimit() const noexcept = 0;

  /**
   * @brief Returns the upper limit temperature in °C depended whether the range is extended.
   * 
   * @return upper limit temperature in °C depended whether the range is extended.
   */
  virtual float getTemperatureUpperLimit() const noexcept = 0;

  /**
   * @brief Returns the lower non extended limit temperature in °C.
   * 
   * @return lower non extended limit temperature in °C.
   */
  virtual float getTemperatureNormalLowerLimit() const noexcept = 0;

  /**
   * @brief Returns the upper non extended limit temperature in °CS.
   * 
   * @return upper non extended limit temperature in °C.
   */
  virtual float getTemperatureNormalUpperLimit() const noexcept = 0;

  /**
   * @brief Returns the lower extended limit temperature in °C.
   * 
   * If this limit can not be extened, this will return the same value as getTemperatureNormalLowerLimit().
   * 
   * @return lower extend limit temperature in °CS.
   */
  virtual float getTemperatureExtendedLowerLimit() const noexcept = 0;

  /**
   * @brief Returns the upper extended limit temperature in °C.
   * 
   * If this limit can not be extened, this will return the same value as getTemperatureNormalUpperLimit().
   * 
   * @return upper extend limit temperature in °CS.
   */
  virtual float getTemperatureExtendedUpperLimit() const noexcept = 0;

  /**
   * @brief Returns whether the temperature range is currently extended.
   * 
   * @return true, if the temperature range is currently extended. False, otherwise.
   */
  virtual bool isTemperatureRangeExtended() const noexcept = 0;

  // Video format
  /**
   * @brief Returns the width of the frame in pixels.
   * 
   * @return width of the frame in pixels.
   */
  virtual int getFrameWidth() const noexcept = 0;

  /**
   * @brief Returns the height of the frame in pixels.
   * 
   * @return height of the frame in pixels.
   */
  virtual int getFrameHeight() const noexcept = 0;

  /**
   * @brief Returns the framerate in Hz.
   * 
   * @return framerate in Hz.
   */
  virtual int getFramerate() const noexcept = 0;

  /**
   * @brief Returns a string representation of the operation mode.
   * 
   * @return string representation of the operation mode.
   */
  virtual std::string toString() const noexcept = 0;
};

} // namespace optris