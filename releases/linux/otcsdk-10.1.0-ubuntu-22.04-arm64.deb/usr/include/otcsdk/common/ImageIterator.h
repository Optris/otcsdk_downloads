// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   ImageIterator.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains class that realize the iteration over the pixels of false color images.
 * 
 * @date 2025-01-21
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/common/ImageInfo.h"
#include "otcsdk/common/Pixel.h"


namespace optris
{

// Forward declaration
class Image;


/**
 * @brief Iterates in a row major fashion over the image and grants read and write access to the pixels.
 * 
 * Potential width padding will be skipped.
 */
class ImageIterator
{
public:
  /// Container type storing the pixel values.
  using Container = std::vector<unsigned char>;
  

  /**
   * @brief Constructor.
   * 
   * @param[in] image to iterate over.
   */
  OTC_SDK_API explicit ImageIterator(Image& image) noexcept;


  /**
   * @brief Returns whether there is a next pixel.
   * 
   * @return true if there is a next pixel. False otherwise.
   */
  bool hasNext() const noexcept;

  /// Moves to the next pixel.
  OTC_SDK_API void next();


  /**
   * @brief Returns the current pixel.
   * 
   * @return current pixel.
   */
  OTC_SDK_API Pixel getPixel() const noexcept;

  /**
   * @brief Sets the current pixel.
   * 
   * @param[in] pixel to set.
   */
  OTC_SDK_API void setPixel(const Pixel& pixel) noexcept;

  /**
   * @brief Returns the current pixel index.
   * 
   * @return index of the current pixel.
   */
  int getIndex() const noexcept;

  /**
   * @brief Returns the x-coordinate of the current pixel.
   * 
   * @return x-coordinate of the current pixel.
   */
  int getX() const noexcept;

  /**
   * @brief Returns the y-coordinate of the current pixel.
   * 
   * @return y-coordinate of the current pixel.
   */
  int getY() const noexcept;


private:
  Container::iterator _iterator;
  Container::iterator _end;

  ImageInfo _info;

  int _index;
  int _x;
  int _y;
};


/**
 * @brief Iterates in a row major fashion over the image and grants read access to the pixels.
 * 
 * Potential width padding will be skipped.
 */
class ConstImageIterator
{
public:
  /// Container type storing the pixel values.
  using Container = std::vector<unsigned char>;


  /**
   * @brief Constructor.
   * 
   * @param[in] image to iterate over.
   */
  OTC_SDK_API explicit ConstImageIterator(const Image& image) noexcept;


  /**
   * @brief Returns whether there is a next pixel.
   * 
   * @return true if there is a next pixel. False otherwise.
   */
  bool hasNext() const noexcept;

  /// Moves to the next pixel.
  OTC_SDK_API void next();

  /**
   * @brief Returns the current pixel.
   * 
   * @return current pixel.
   */
  OTC_SDK_API Pixel getPixel() const noexcept;

  /**
   * @brief Returns the current pixel index.
   * 
   * @return index of the current pixel.
   */
  int getIndex() const noexcept;

  /**
   * @brief Returns the x-coordinate of the current pixel.
   * 
   * @return x-coordinate of the current pixel.
   */
  int getX() const noexcept;

  /**
   * @brief Returns the y-coordinate of the current pixel.
   * 
   * @return y-coordinate of the current pixel.
   */
  int getY() const noexcept;


private:
  Container::const_iterator _iterator;
  Container::const_iterator _end;

  ImageInfo _info;

  int _index;
  int _x;
  int _y;
};


// Inline implementations
inline bool ImageIterator::hasNext() const noexcept
{
  return _iterator != _end;
}

inline int ImageIterator::getIndex() const noexcept
{
  return _index;
}

inline int ImageIterator::getX() const noexcept
{
  return _x;
}

inline int ImageIterator::getY() const noexcept
{
  return _y;
}

inline bool ConstImageIterator::hasNext() const noexcept
{
  return _iterator != _end;
}

inline int ConstImageIterator::getIndex() const noexcept
{
  return _index;
}

inline int ConstImageIterator::getX() const noexcept
{
  return _x;
}

inline int ConstImageIterator::getY() const noexcept
{
  return _y;
}

} // namespace optris
