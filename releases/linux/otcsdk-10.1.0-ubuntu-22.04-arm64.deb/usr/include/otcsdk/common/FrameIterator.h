// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   FrameIterator.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that realizes the iteration over Frames.
 * 
 * @date 2025-01-30
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"


namespace optris
{

// Forward declaration
class Frame;


/// Iterates over the frame in a row major fashion and grants read access.
class ConstFrameIterator
{
public:
  /// Container type storing the frame values.
  using Container = std::vector<unsigned short>;


  /**
   * @brief Constructor.
   * 
   * @param[in] frame to iterate over.
   */
  OTC_SDK_API explicit ConstFrameIterator(const Frame& frame) noexcept;


  /**
   * @brief Returns whether there is a next frame value.
   * 
   * @return true if there is a next frame value. False otherwise.
   */
  OTC_SDK_API bool hasNext() const noexcept;

  /// Moves to the next frame value.
  OTC_SDK_API void next();


  /**
   * @brief Returns the current frame value.
   * 
   * @return current frame value.
   */
  OTC_SDK_API unsigned short getValue() const noexcept;


  /**
   * @brief Returns the index of the current frame value.
   * 
   * @return index of the current frame value.
   */
  OTC_SDK_API int getIndex() const noexcept;

  /**
   * @brief Returns the x-coordinate of the current frame value.
   * 
   * @return x-coordinate of the current frame value.
   */
  OTC_SDK_API int getX() const noexcept;

  /**
   * @brief Returns the y-coordinate of the current frame value.
   * 
   * @return y-coordinate of the current frame value.
   */
  OTC_SDK_API int getY() const noexcept;


private:
  Container::const_iterator _iterator;
  Container::const_iterator _end;

  int _width;

  int _index;
  int _x;
  int _y;
};


// Inline implementations
inline bool ConstFrameIterator::hasNext() const noexcept
{
  return _iterator != _end;
}

inline unsigned short ConstFrameIterator::getValue() const noexcept
{
  return *_iterator;
}

inline int ConstFrameIterator::getIndex() const noexcept
{
  return _index;
}

inline int ConstFrameIterator::getX() const noexcept
{
  return _x;
}

inline int ConstFrameIterator::getY() const noexcept
{
  return _y;
}

} // namespace optris