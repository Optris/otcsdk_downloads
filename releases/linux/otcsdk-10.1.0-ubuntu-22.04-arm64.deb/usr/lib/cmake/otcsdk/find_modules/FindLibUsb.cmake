#===============================================================
# Find module for libusb-1.0
#
# Inspired by
#   https://github.com/PatTheMav/cmake-finders/tree/master
#   by Patrick Heyer, MIT License
#===============================================================


include(FindPackageHandleStandardArgs)

# Try to use pkg-config tool to locate library
find_package(PkgConfig QUIET)
if(PKG_CONFIG_FOUND)
  pkg_search_module(PC_LibUsb QUIET libusb-1.0)
endif()

# Library include directory
find_path(
  LibUsb_INCLUDE_DIR
    NAMES libusb.h
    HINTS ${PC_LibUsb_INCLUDE_DIRS} /usr/include/libusb-1.0
    PATHS /usr/include /usr/local/include
)

# Library files
find_library(
  LibUsb_LIBRARY
    NAMES usb-1.0
    HINTS ${PC_LibUsb_LIBRARY_DIRS}
    PATHS /usr/lib /usr/local/lib
)

# Library version
if(PC_LibUsb_VERSION VERSION_GREATER 0)
  set(LibUsb_VERSION ${PC_LibUsb_VERSION})
else()
  set(LibUsb_VERSION 0.0.0)
endif()


# Export variables
find_package_handle_standard_args(
  LibUsb
  REQUIRED_VARS LibUsb_LIBRARY LibUsb_INCLUDE_DIR
  VERSION_VAR LibUsb_VERSION REASON_FAILURE_MESSAGE "Ensure that libusb-1.0 and its dev resources is installed on the system.")
mark_as_advanced(LibUsb_INCLUDE_DIR LibUsb_LIBRARY)


# Create library target
if(LibUsb_FOUND AND NOT TARGET LibUsb::LibUsb)
  add_library(
    LibUsb::LibUsb 
      UNKNOWN IMPORTED
  )

  set_target_properties(
    LibUsb::LibUsb
      PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${LibUsb_INCLUDE_DIR}"
        IMPORTED_LOCATION "${LibUsb_LIBRARY}"
        IMPORTED_LINK_INTERFACE_LANGUAGES "C"
        VERSION ${LibUsb_VERSION}
  )

  if (PKG_CONFIG_FOUND)
    set_target_properties(
      LibUsb::LibUsb
        PROPERTIES
          INTERFACE_COMPILE_OPTIONS "${PC_LibUsb_CFLAGS_OTHER}"
    )
  endif()
endif()