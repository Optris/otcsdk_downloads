#===============================================================
# Find module for libudev
#
# Modified version from
#   https://github.com/PatTheMav/cmake-finders/tree/master
#   by Patrick Heyer, MIT License
#===============================================================


include(FindPackageHandleStandardArgs)

# Try to use pkg-config tool to locate library
find_package(PkgConfig QUIET)
if(PKG_CONFIG_FOUND)
  pkg_search_module(PC_LibUdev QUIET libudev)
endif()

# Library include directory
find_path(
  LibUdev_INCLUDE_DIR
    NAMES libudev.h
    HINTS ${PC_LibUdev_INCLUDE_DIRS}
    PATHS /usr/include /usr/local/include
)

# Library files
find_library(
  LibUdev_LIBRARY
    NAMES udev
    HINTS ${PC_LibUdev_LIBRARY_DIRS}
    PATHS /usr/lib /usr/local/lib
)

# Library version
if(PC_LibUdev_VERSION VERSION_GREATER 0)
  set(LibUdev_VERSION ${PC_LibUdev_VERSION})
else()
  set(LibUdev_VERSION 0.0.0)
endif()


# Export variables
find_package_handle_standard_args(
  LibUdev
  REQUIRED_VARS LibUdev_LIBRARY LibUdev_INCLUDE_DIR
  VERSION_VAR LibUdev_VERSION REASON_FAILURE_MESSAGE "Ensure that libudev with its dev resources is installed on the system.")
mark_as_advanced(LibUdev_INCLUDE_DIR LibUdev_LIBRARY)


# Create library target
if(LibUdev_FOUND AND NOT TARGET LibUdev::LibUdev)
  add_library(
    LibUdev::LibUdev 
      UNKNOWN IMPORTED
  )

  set_target_properties(
    LibUdev::LibUdev
      PROPERTIES
        INTERFACE_INCLUDE_DIRECTORIES "${LibUdev_INCLUDE_DIR}"
        IMPORTED_LINK_INTERFACE_LANGUAGES "C"
        IMPORTED_LOCATION "${LibUdev_LIBRARY}"
        VERSION ${LibUdev_VERSION}
  )

  if (PKG_CONFIG_FOUND)
    set_target_properties(
      LibUdev::LibUdev
        PROPERTIES
          INTERFACE_COMPILE_OPTIONS "${PC_LibUdev_CFLAGS_OTHER}"
    )
  endif()
endif()