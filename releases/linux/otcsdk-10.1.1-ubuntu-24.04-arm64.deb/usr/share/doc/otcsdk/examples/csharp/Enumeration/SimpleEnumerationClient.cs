﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Optris.OtcSDK;

namespace Enumeration
{
    /// <summary>Simple example implementation of an EnumerationClient that outputs enumerations events.</summary>
    /// 
    /// An EnumerationClient serves as observer to the EnumerationManger that constantly when devices for newly
    /// attached or removed devices.
    internal class SimpleEnumerationClient : EnumerationClient
    {
        /// <summary>Constructor.</summary> 
        public SimpleEnumerationClient() 
        {
            /*
             * The EnumerationManger is implemented using the Singleton pattern. Therefore, you need to call getInstance() method to 
             * interact with it.
             */
            var manager = EnumerationManager.getInstance();

            /*
             * The Sdk.init() method automatically adds a detector for USB devices to the EnumerationManager and starts its detection
             * loop in a dedicated thread. If you wish to set up your own detection scheme, you will be able to remove all existing
             * detectors with the following command:
             */
            manager.clearDetectors();

            // Re-adds the detector for USB devices.
            manager.addUsbDetector();
            /*
             * Adds a detector for Ethernet devices on the network 192.168.0.0/24. The /24 specifies how many bits make up the network 
             * portion of the provided IP address (it is a shorthand for the subnet mask). The detector ignores the host part of the 
             * address. The routing logic of the operation system will choose the network interface that is used to access the
             * specified network.
             */
            manager.addEthernetDetector("192.168.0.0/24");

            printHeader();

            /*
             * Register this instance as a client/observer with the EnumerationManger.
             * The EnumerationManger is implemented using the Singleton pattern. Therefore,
             * you need to call getInstance() to interact with it.
             */
            EnumerationManager.getInstance().addClient(this);
        }

        /// <summary>Main run method.</summary>
        public void run()
        {
            /*
             * The EnumerationManger was already started in a separate thread by the Sdk::init() method. 
             * Therefore, the main thread has nothing to do.
             */
            while (true)
            {
                Thread.Sleep(500);
            }
        }

        /// <summary>Called when a new device was detected.</summary>
        /// 
        /// This happens, for example, if a camera is plugged in to the computer via USB.
        /// 
        /// <param name="deviceInfo"> about the detected device.</param>
        public override void onDeviceDetected(DeviceInfo deviceInfo)
        {
            printEvent("Detected", deviceInfo);
        }

        /// <summary>Called when a previously detected device is now longer found.</summary>
        /// 
        /// This happens, for example, if a camera is unplugged from the computer.
        /// 
        /// <param name="deviceInfo"> about the lost device.</param>
        public override void onDeviceDetectionLost(DeviceInfo deviceInfo)
        {
            printEvent("Lost", deviceInfo);
        }

        /// <summary>Called when a previously detected device changed its status or configuration.</summary>
        /// 
        /// This happens, for example, if a camera is opened by another program and starts streaming data.
        /// 
        /// <param name="deviceInfo"> about the changed device.</param>
        public override void onDeviceDetectionChanged(DeviceInfo deviceInfo)
        {
            printEvent("Changed", deviceInfo);
        }


        /// <summary>Prints out the header for the enumeration events.</summary>
        private void printHeader()
        {
            

            Console.WriteLine("Enumeration Events (Ctrl + C to quit)\n");
            Console.WriteLine("{0, -10}{1, -8}{2, -10}{3, -6}{4, -6}{5, -11}{6, -10}{7, -19}{8, -17}{9, -17}{10, -5}",
                "Event",
                "Device",
                "S/N",
                "HW",
                "FW",
                "Status",
                "Connect",
                "MAC-",
                "IP-Address",
                "IP-Address",
                "Port");

            Console.WriteLine("{0, -10}{1, -8}{2, -10}{3, -6}{4, -6}{5, -11}{6, -10}{7, -19}{8, -17}{9, -17}{10, -5}",
                " ",
                "Type",
                " ",
                "Rev.",
                "Rev.",
                " ",
                "Type",
                "Address",
                "Camera",
                "Local",
                " ");

            Console.WriteLine(new string('-', 120));
        }

        /// <summary>Prints out an enumeration event.</summary>
        /// <param name="eventType">to print.</param>
        /// <param name="deviceInfo">to print.</param>
        private void printEvent(string eventType, DeviceInfo deviceInfo) 
        {
            Console.WriteLine("{0, -10}{1, -8}{2, -10}{3, -6}{4, -6}{5, -11}{6, -10}{7, -19}{8, -17}{9, -17}{10, -5}",
                eventType,
                deviceInfo.getDeviceType().ToString(),
                deviceInfo.getSerialNumber(),
                deviceInfo.getHardwareRevision(),
                deviceInfo.getFirmwareRevision() == 0 ? "-" : deviceInfo.getFirmwareRevision(),
                deviceInfo.getConnectionState() == 0 ? "available" : "busy",
                deviceInfo.getConnectionInterface(),
                deviceInfo.getMacAddress().toUInt64() == 0 ? "-" : deviceInfo.getMacAddress().toString(),
                deviceInfo.getIpAddress().toUInt32() == 0 ? "-" : deviceInfo.getIpAddress().toString(),
                deviceInfo.getTargetIpAddress().toUInt32() == 0 ? "-" : deviceInfo.getTargetIpAddress().toString(),
                deviceInfo.getPort().getNumber() == 0 ? "-" : deviceInfo.getPort().toString()
            );
                
        }
    }
}
