// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    IRImagerShow.h
 * @author  Optris GmbH & Co. KG
 * @brief   Declaration of the IRImagerShow class.
 *          
 * @date    2024-06-19   
 */

#pragma once

#include <atomic>
#include <memory>
#include <thread>
#include <mutex>
#include <cstdint>

#include "otcsdk/IRImager.h"
#include "otcsdk/ImageBuilder.h"
#include "otcsdk/FramerateCounter.h"

#include "display/opengl/Obvious2D.h"
#include "display/opengl/Obvious2DClient.h"



/**
 * @brief Example client implementation. 
 * 
 * Use this class as a template for your own application. Derive your class from optris::IRImagerClient and  
 * register it with addClient to an IRImager object. The run method of the IRImager object will trigger the 
 * callbacks to deliver data.
 * 
 * This layout adheres to the Observer design pattern.
 */
class IRImagerShow : public optris::IRImagerClient, public Obvious2DClient
{
public:
  /**
   * @brief Constructor.
   *
   * @param[in] serialNumber of the device to connect to or 0 to automatically choose a device connected
   *                         via USB.
   */
  IRImagerShow(unsigned int serialNumber);

  /// Destructor.
  ~IRImagerShow() noexcept;


  /// Starts the frame grabbing thread.
  void startGrabbingThread();

  /**
   * @brief Renders the latest available thermal frame.
   * 
   * @return true if thermal frame was rendered successfully. False if rendering fails, the user hits q or
   *         the window is closed.
   */
  bool render();


private:
  /// Mutex type used for thread synchronization.
  using Mutex = std::mutex;
  /// Lock type used for thread synchronization.
  using Lock  = std::unique_lock<Mutex>;


  /**
   * @brief Callback method triggered by imager when a new thermal frame is available.
   *
   * @param[in] thermal frame data.
   * @param[in] meta    data of thermal frame.
   */
  void onThermalFrame(const optris::ThermalFrame& thermal, const optris::FrameMetadata& meta) override;

  /**
   * @brief Callback method triggered by imager when the state of the shutter flag changes.
   *
   * @param[in] flagState of the shutter flag.
   */
  void onFlagStateChange(optris::FlagState flagState) override;

  /**
   * @brief Callback method triggered by imager when the calculation of a new measurement field finished.
   * 
   * @param[in] field new measurement field.
   */
  void onMeasurementField(const optris::MeasurementField& field) override;

  /**
   * @brief Callback method triggered by imager when a changed uncommitted PIF analog input value was received.
   * 
   * @param[in] name  configured name of the uncommitted value.
   * @param[in] unit  configured unit of the uncommitted value.
   * @param[in] value calculated from the PIF analog input value.
   */
  void onPifUncommittedValue(const std::string& name, const std::string& unit, float value) override;

  /**
   * @brief Callback method triggered by imager when the video format has changed.
   * 
   * This happens during calls to IRImager::connect() or IRImager::setActiveOperationMode().
   * 
   * @param[in] width     of the frame in pixels.
   * @param[in] height    of the frame in pixels.
   * @param[in] framerate from the device in Hz (not subsampled).
   * @param[in] bitCount  defines the size of the data point for an individual pixel in bits.
   */
  void onVideoFormatChanged(int width, int height, float framerate, int bitCount) override;

  /// Callback method triggered by imager when a lost connection is detected.
  void onConnectionLost() override;

  /// Callback method triggered by imager when frames have not been received for a while.
  void onConnectionTimeout() override;

  /**
   * @brief Callback for keyboard shortcuts.
   * 
   * @param[in] key that triggered the callback.
   */
  void keyboardCallback(char key) override;

  /**
   * @brief Draws a crosshair on the display with the provided temperature.
   * 
   * @param[in] imageWidth      of the false color image.
   * @param[in] imageHeight     of the false color image.
   * @param[in] positionX       of the crosshair center.
   * @param[in] positionY       of the crosshair center.
   * @param[in] temperature     to display.
   * @param[in] color           of the crosshair and the temperature text.
   * @param[in] backgroundColor of the crosshair and the temperature text.
   */
  void drawMeasurementInfo(unsigned int       imageWidth, 
                           unsigned int       imageHeight, 
                           unsigned int       positionX, 
                           unsigned int       positionY, 
                           float              temperature,
                           const std::uint8_t color[4], 
                           const std::uint8_t backgroundColor[4]);

  /// Updates the displayed information about the operation mode.
  void updateOperationModeInfo();


  /// Grabs and processes thermal frames.
  std::shared_ptr<optris::IRImager> _imager;

  /// Converts thermal frames to false color images.
  std::unique_ptr<optris::ImageBuilder> _imageBuilder;

  /// Displays the false color images on screen.
  std::unique_ptr<Obvious2D> _display;

  /// Frame counter for received thermal frames.
  std::unique_ptr<optris::FramerateCounter> _fps;

  /// Synchronizes the thermal frame data.
  Mutex _thermalMutex;
  /// Thermal frame data.
  optris::ThermalFrame _thermal;

  /// Stores the current state of the shutter flag.
  std::atomic<optris::FlagState> _flagState;

  /// Frame grabbing thread.
  std::unique_ptr<std::thread> _thread;

  /// Flags a lost device connection.
  std::atomic<bool> _connectionLost;

  /// List of all available operation modes.
  std::vector<std::shared_ptr<optris::OperationMode>> _operationModes;
  /// Index of the active mode in the above vector.
  int _activeModeIndex;
};
