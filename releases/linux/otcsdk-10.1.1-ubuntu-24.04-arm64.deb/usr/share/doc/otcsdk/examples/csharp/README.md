# C# Examples

Examples illustrating how to use the C# language bindings of the SDK. 

> **NOTE** The examples use Windows Forms and are therefore only available on Windows.


## Dependencies
### Linux
Use the native package manager `apt` to install the the dotnet SDK

```bash
sudo apt install dotnet-sdk-8.0 dotnet8
```

### Windows
Install Visual Studio Community 2022 by going to its [website](https://visualstudio.microsoft.com/) and downloading the installer. Choose the
work load ".NET Desktop Development" and the "Visual Studio Editor".


## Examples
Navigate to the `csharp` folder and open the solution file of your chosen example. Hit one of the green triangle button to start the compilation.
Once completed the resulting application will be started automatically.


### Enumeration
Displays enumeration events (detection of attached cameras) on the command line.

__Linux__
```bash
./enumeration
```

__Windows__
```powershell
.\enumeration
```

To detect Ethernet devices you have to adjust the network address used by the `addEthernetDetector()` method to your own network configuration.


### Minimal
Views the current flag state and the dimensions of thermal frame on the command line. This is the minimal implementation required to retrieve thermal data from an Optris thermal camera.

__Linux__
```bash
./minimal <serial number>
```

__Windows__
```powershell
.\minimal <serial number>
```

If no serial number is provided, the program will use the device with the lowest serial number detected by the Enumeration Manager. To detect Ethernet devices you have to adjust the network address used by the `addEthernetDetector()` method to your own network configuration.


### Pif
Displays details about a connected process interface, tries to configure the first channel of each available type and outputs the read input values of all PIF input channels.

__Linux__
```bash
./pif <serial number>
```

__Windows__
```powershell
.\pif <serial number>
```

If no serial number is provided, the program will use the device with the lowest serial number detected by the Enumeration Manager. To detect Ethernet devices you have to adjust the network address used by the `addEthernetDetector()` method to your own network configuration.


### SimpleViewCS
Views a false color image based on the thermal data from the camera. 

Go to the menu item "Device" - "Quick Connect" to connect to the first available camera on the USB port.

To detect Ethernet devices you have to adjust the network address used by the `addEthernetDetector()` method to your own network configuration.