// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file    SimpleEnumerationClient.cpp
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the enumeration example.
 *          
 * @date 2025-03-31
 */

#include "SimpleEnumerationClient.h"

#include <iostream>
#include <iomanip>
#include <thread>
#include <chrono>
#include <string>

#include "otcsdk/enumeration/EnumerationManager.h"


SimpleEnumerationClient::SimpleEnumerationClient()
{
  /*
   * The EnumerationManger is implemented using the Singleton pattern. Therefore, you need to call getInstance() method to 
   * interact with it.
   */
  auto& manager = optris::EnumerationManager::getInstance();

  /*
   * The Sdk::init() method automatically adds a detector for USB devices to the EnumerationManager and starts its detection
   * loop in a dedicated thread. If you wish to set up your own detection scheme, you will be able to remove all existing
   * detectors with the following command:
   */
  manager.clearDetectors();

  // Re-adds the detector for USB devices.
  manager.addUsbDetector();
  /*
   * Adds a detector for Ethernet devices on the network 192.168.0.0/24. The /24 specifies how many bits make up the network 
   * portion of the provided IP address (it is a shorthand for the subnet mask). The detector ignores the host part of the 
   * address. The routing logic of the operation system will choose the network interface that is used to access the
   * specified network.
   */
  manager.addEthernetDetector("192.168.0.0/24");

  printHeader();

  // Register this instance as a client/observer with the EnumerationManger.
  manager.addClient(this);
}


void SimpleEnumerationClient::run()
{
  /*
   * The EnumerationManger was already started in a separate thread by the Sdk::init() method. 
   * Therefore, the main thread has nothing to do.
   */
  while (true)
  {
    std::this_thread::sleep_for(std::chrono::milliseconds{500});
  }
}


void SimpleEnumerationClient::onDeviceDetected(optris::DeviceInfo deviceInfo) noexcept
{
  printEvent("Detected", deviceInfo);
}

void SimpleEnumerationClient::onDeviceDetectionLost(optris::DeviceInfo deviceInfo) noexcept
{
  printEvent("Lost", deviceInfo);
}

void SimpleEnumerationClient::onDeviceDetectionChanged(optris::DeviceInfo deviceInfo) noexcept
{
  printEvent("Changed", deviceInfo);
}


void SimpleEnumerationClient::printHeader()
{
  std::cout << "Enumeration Events (Ctrl + C to quit)\n\n"
            << std::setw(10) << std::left << "Event"
            << std::setw(8)  << std::left << "Device"
            << std::setw(10) << std::left << "S/N"
            << std::setw(6)  << std::left << "HW"
            << std::setw(6)  << std::left << "FW"
            << std::setw(11) << std::left << "Status"
            << std::setw(10) << std::left << "Connect"
            << std::setw(19) << std::left << "MAC-"
            << std::setw(17) << std::left << "IP-Address"
            << std::setw(17) << std::left << "IP-Address"
            << std::setw(5)  << std::left << "Port"
            << std::endl;

std::cout   << std::setw(10) << std::left << " "
            << std::setw(8)  << std::left << "Type"
            << std::setw(10) << std::left << " "
            << std::setw(6)  << std::left << "Rev."
            << std::setw(6)  << std::left << "Rev."
            << std::setw(11) << std::left << " "
            << std::setw(10) << std::left << "Type"
            << std::setw(19) << std::left << "Address"
            << std::setw(17) << std::left << "Camera"
            << std::setw(17) << std::left << "Local"
            << std::setw(5)  << std::left << " "
            << std::endl << std::string(120, '-') << std::endl;
}

void SimpleEnumerationClient::printEvent(const std::string& event, const optris::DeviceInfo& deviceInfo)
{
  std::cout << std::setw(10) << std::left <<  event
            << std::setw(8)  << std::left <<  deviceInfo.getDeviceType()
            << std::setw(10) << std::left <<  deviceInfo.getSerialNumber()
            << std::setw(6)  << std::left <<  deviceInfo.getHardwareRevision()
            << std::setw(6)  << std::left << (deviceInfo.getFirmwareRevision() == 0 ? "-" : std::to_string(deviceInfo.getFirmwareRevision()))
            << std::setw(11) << std::left << (deviceInfo.isBusy() ? "busy" : "available")
            << std::setw(10) << std::left <<  deviceInfo.getConnectionInterface()
            << std::setw(19) << std::left << (deviceInfo.getMacAddress()       == 0 ? "-" : deviceInfo.getMacAddress().toString())
            << std::setw(17) << std::left << (deviceInfo.getIpAddress() == 0        ? "-" : deviceInfo.getIpAddress().toString())
            << std::setw(17) << std::left << (deviceInfo.getTargetIpAddress() == 0  ? "-" : deviceInfo.getTargetIpAddress().toString())
            << std::setw(5)  << std::left << (deviceInfo.getPort() == 0             ? "-" : std::to_string(deviceInfo.getPort().getNumber()))
            << std::endl;
}