﻿// Copyright (c) 2008-2025 Optris GmbH & Co. KG

namespace SimpleViewCS
{
    partial class DisplayForm
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox = new PictureBox();
            menuStrip1 = new MenuStrip();
            fileToolStripMenuItem = new ToolStripMenuItem();
            msFileQuit = new ToolStripMenuItem();
            msDevice = new ToolStripMenuItem();
            miDeviceQuickConnect = new ToolStripMenuItem();
            miDeviceConnect = new ToolStripMenuItem();
            miDeviceDisconnect = new ToolStripMenuItem();
            toolStripSeparator2 = new ToolStripSeparator();
            miDeviceCycleOperationMode = new ToolStripMenuItem();
            toolStripSeparator1 = new ToolStripSeparator();
            miDeviceRefreshFlag = new ToolStripMenuItem();
            statusStrip = new StatusStrip();
            sbOperationMode = new ToolStripStatusLabel();
            sbFlag = new ToolStripStatusLabel();
            sbFPS = new ToolStripStatusLabel();
            ((System.ComponentModel.ISupportInitialize)pictureBox).BeginInit();
            menuStrip1.SuspendLayout();
            statusStrip.SuspendLayout();
            SuspendLayout();
            // 
            // pictureBox
            // 
            pictureBox.BackColor = SystemColors.ControlDark;
            pictureBox.Dock = DockStyle.Fill;
            pictureBox.Location = new Point(0, 24);
            pictureBox.Name = "pictureBox";
            pictureBox.Size = new Size(800, 426);
            pictureBox.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox.TabIndex = 0;
            pictureBox.TabStop = false;
            // 
            // menuStrip1
            // 
            menuStrip1.Items.AddRange(new ToolStripItem[] { fileToolStripMenuItem, msDevice });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 24);
            menuStrip1.TabIndex = 1;
            menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            fileToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { msFileQuit });
            fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            fileToolStripMenuItem.Size = new Size(37, 20);
            fileToolStripMenuItem.Text = "&File";
            // 
            // msFileQuit
            // 
            msFileQuit.Name = "msFileQuit";
            msFileQuit.ShortcutKeys = Keys.Control | Keys.Q;
            msFileQuit.Size = new Size(142, 22);
            msFileQuit.Text = "&Quit";
            msFileQuit.TextAlign = ContentAlignment.TopLeft;
            msFileQuit.ToolTipText = "Quit Application";
            msFileQuit.Click += msFileQuit_Click;
            // 
            // msDevice
            // 
            msDevice.DropDownItems.AddRange(new ToolStripItem[] { miDeviceQuickConnect, miDeviceConnect, miDeviceDisconnect, toolStripSeparator2, miDeviceCycleOperationMode, toolStripSeparator1, miDeviceRefreshFlag });
            msDevice.Name = "msDevice";
            msDevice.Size = new Size(54, 20);
            msDevice.Text = "&Device";
            msDevice.ToolTipText = "Connect to the First Device Available";
            // 
            // miDeviceQuickConnect
            // 
            miDeviceQuickConnect.Name = "miDeviceQuickConnect";
            miDeviceQuickConnect.ShortcutKeys = Keys.F5;
            miDeviceQuickConnect.Size = new Size(281, 22);
            miDeviceQuickConnect.Text = "&Quick Connect";
            miDeviceQuickConnect.Click += miDeviceQuickConnect_Click;
            // 
            // miDeviceConnect
            // 
            miDeviceConnect.Name = "miDeviceConnect";
            miDeviceConnect.ShortcutKeys = Keys.Control | Keys.F5;
            miDeviceConnect.Size = new Size(281, 22);
            miDeviceConnect.Text = "&Connect With Configuration...";
            miDeviceConnect.ToolTipText = "Connect to Device WIth Configuration";
            miDeviceConnect.Click += miDeviceConnect_Click;
            // 
            // miDeviceDisconnect
            // 
            miDeviceDisconnect.Enabled = false;
            miDeviceDisconnect.Name = "miDeviceDisconnect";
            miDeviceDisconnect.ShortcutKeys = Keys.Control | Keys.D;
            miDeviceDisconnect.Size = new Size(281, 22);
            miDeviceDisconnect.Text = "&Disconnect";
            miDeviceDisconnect.ToolTipText = "Disconnect From Device";
            miDeviceDisconnect.Click += miDeviceDisconnect_Click;
            // 
            // toolStripSeparator2
            // 
            toolStripSeparator2.Name = "toolStripSeparator2";
            toolStripSeparator2.Size = new Size(278, 6);
            // 
            // miDeviceCycleOperationMode
            // 
            miDeviceCycleOperationMode.Enabled = false;
            miDeviceCycleOperationMode.Name = "miDeviceCycleOperationMode";
            miDeviceCycleOperationMode.ShortcutKeys = Keys.Control | Keys.C;
            miDeviceCycleOperationMode.Size = new Size(281, 22);
            miDeviceCycleOperationMode.Text = "Cycle &Operation Mode";
            miDeviceCycleOperationMode.ToolTipText = "Cycle Operation Modes";
            miDeviceCycleOperationMode.Click += miDeviceCycleOperationMode_Click;
            // 
            // toolStripSeparator1
            // 
            toolStripSeparator1.Name = "toolStripSeparator1";
            toolStripSeparator1.Size = new Size(278, 6);
            // 
            // miDeviceRefreshFlag
            // 
            miDeviceRefreshFlag.Enabled = false;
            miDeviceRefreshFlag.Name = "miDeviceRefreshFlag";
            miDeviceRefreshFlag.ShortcutKeyDisplayString = "";
            miDeviceRefreshFlag.ShortcutKeys = Keys.Control | Keys.R;
            miDeviceRefreshFlag.Size = new Size(281, 22);
            miDeviceRefreshFlag.Text = "&Refresh Flag";
            miDeviceRefreshFlag.ToolTipText = "Refresh Shutter Flag";
            miDeviceRefreshFlag.Click += miDeviceRefreshFlag_Click;
            // 
            // statusStrip
            // 
            statusStrip.Items.AddRange(new ToolStripItem[] { sbOperationMode, sbFlag, sbFPS });
            statusStrip.Location = new Point(0, 426);
            statusStrip.Name = "statusStrip";
            statusStrip.Size = new Size(800, 24);
            statusStrip.TabIndex = 2;
            statusStrip.Text = "statusStrip1";
            // 
            // sbOperationMode
            // 
            sbOperationMode.BorderSides = ToolStripStatusLabelBorderSides.Left | ToolStripStatusLabelBorderSides.Top | ToolStripStatusLabelBorderSides.Right | ToolStripStatusLabelBorderSides.Bottom;
            sbOperationMode.BorderStyle = Border3DStyle.SunkenOuter;
            sbOperationMode.Name = "sbOperationMode";
            sbOperationMode.Padding = new Padding(5, 0, 5, 0);
            sbOperationMode.Size = new Size(604, 19);
            sbOperationMode.Spring = true;
            sbOperationMode.TextAlign = ContentAlignment.MiddleLeft;
            sbOperationMode.ToolTipText = "Active Operation Mode";
            // 
            // sbFlag
            // 
            sbFlag.BorderSides = ToolStripStatusLabelBorderSides.Left | ToolStripStatusLabelBorderSides.Top | ToolStripStatusLabelBorderSides.Right | ToolStripStatusLabelBorderSides.Bottom;
            sbFlag.BorderStyle = Border3DStyle.SunkenOuter;
            sbFlag.DisplayStyle = ToolStripItemDisplayStyle.Text;
            sbFlag.Name = "sbFlag";
            sbFlag.Padding = new Padding(5, 0, 5, 0);
            sbFlag.Size = new Size(75, 19);
            sbFlag.Text = "                  ";
            sbFlag.ToolTipText = "Shutter Flag State";
            // 
            // sbFPS
            // 
            sbFPS.BorderSides = ToolStripStatusLabelBorderSides.Left | ToolStripStatusLabelBorderSides.Top | ToolStripStatusLabelBorderSides.Right | ToolStripStatusLabelBorderSides.Bottom;
            sbFPS.BorderStyle = Border3DStyle.SunkenOuter;
            sbFPS.DisplayStyle = ToolStripItemDisplayStyle.Text;
            sbFPS.Name = "sbFPS";
            sbFPS.Padding = new Padding(5, 0, 5, 0);
            sbFPS.Size = new Size(75, 19);
            sbFPS.Text = "                  ";
            sbFPS.TextAlign = ContentAlignment.MiddleRight;
            sbFPS.ToolTipText = "FPS";
            // 
            // DisplayForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(statusStrip);
            Controls.Add(pictureBox);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "DisplayForm";
            Text = "Optris Imager";
            FormClosing += DisplayForm_FormClosing;
            ((System.ComponentModel.ISupportInitialize)pictureBox).EndInit();
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            statusStrip.ResumeLayout(false);
            statusStrip.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem msDevice;
        private ToolStripMenuItem miDeviceConnect;
        private StatusStrip statusStrip;
        private ToolStripStatusLabel sbFlag;
        private ToolStripStatusLabel sbFPS;
        private ToolStripMenuItem miDeviceDisconnect;
        private ToolStripMenuItem fileToolStripMenuItem;
        private ToolStripMenuItem msFileQuit;
        private ToolStripMenuItem miDeviceQuickConnect;
        private ToolStripSeparator toolStripSeparator1;
        private ToolStripMenuItem miDeviceRefreshFlag;
        private ToolStripStatusLabel sbOperationMode;
        private ToolStripSeparator toolStripSeparator2;
        private ToolStripMenuItem miDeviceCycleOperationMode;
    }
}
