# Copyright (c) 2008-2025 Optris GmbH & Co. KG

"""
Enumeration Python3 example. 

2025-03-31 
"""

import sys
import time
import optris.otcsdk as otc


class SimpleEnumerationClient(otc.EnumerationClient):
    """
    Simple example implementations of an EnumerationClient that outputs enumeration events to the console.

    An EnumerationClient serves as observer to the EnumerationManger that constantly checks whether new devices 
    are attached or exiting ones are removed.
    """

    def __init__(self):
        """
        Constructor.
        """
        # Required to initialize base class
        super().__init__()

        # The EnumerationManger is implemented using the Singleton pattern. Therefore, you need to call its static getInstance()
        # method to interact with it.
        self._manager = otc.EnumerationManager.getInstance()

        # The Sdk.init() method automatically adds a detector for USB devices to the EnumerationManager and starts its detection
        # loop in a dedicated thread. If you wish to set up your own detection scheme, you will be able to remove all existing
        # detectors with the following command:
        self._manager.clearDetectors()

        # Re-adds the detector for USB devices.
        self._manager.addUsbDetector()
        # Adds a detector for Ethernet devices on the network 192.168.0.0/24. The /24 specifies how many bits make up the network
        # portion of the provided IP address (it is a shorthand for the subnet mask). The detector ignores the host part of the 
        # address. The routing logic of the operation system will choose the network interface that is used to access the
        # specified network.
        self._manager.addEthernetDetector("192.168.0.0/24")
        
        self.print_header()
        
        # Register this instance as a client/observer with the EnumerationManger.
        self._manager.addClient(self)

        # Thread to run the detection logic of the EnumerationManager
        self._thread = None
    

    def run(self):
        """
        Main run method.
        """
        # The EnumerationManger was already started in a separate thread by the Sdk::init() method. 
        # Therefore, the main thread has nothing to do but wait for keyboard interrupts.
        while(True):
            # Sleep and wait for Ctrl + C to be pressed. Note: EnumerationManager.run() does not recognize
            # a keyboard interrupt!
            try:
                time.sleep(1.)
            except KeyboardInterrupt:
                break


    def onDeviceDetected(self, deviceInfo):
        """ 
        Called when a new device was detected.

        This happens, for example, if a camera is plugged in to the computer via USB.
        """
        self.print_event("Detected", deviceInfo)
    
    def onDeviceDetectionLost(self, deviceInfo):
        """
        Called when a previously detected device is now longer found.

        This happens, for example, if a camera is unplugged from the computer.
        """
        self.print_event("Lost", deviceInfo)

    def onDeviceDetectionChanged(self, deviceInfo):
        """
        Called when a previously detected device changed its status or configuration.

        This happens, for example, if a camera is opened by another program and starts streaming data.
        """
        self.print_event("Changed", deviceInfo)


    def onDeviceDetectionChanged(self, deviceInfo):
        """
        Called when a previously detected device changed its configuration.
        """
        self.print_event("Change", deviceInfo)


    def print_header(self):
        """
        Prints out the header for the enumeration events.
        """
        print("Enumeration Events (Ctrl + C to quit)\n")
        print("{:<10}{:<8}{:<10}{:<6}{:<6}{:<11}{:<10}{:<19}{:<17}{:<17}{:<5}".format( 
            "Event",
            "Device",
            "S/N",
            "HW",
            "FW",
            "Status",
            "Connect",
            "MAC-",
            "IP-Address",
            "IP-Address",
            "Port"))
        
        print("{:<10}{:<8}{:<10}{:<6}{:<6}{:<11}{:<10}{:<19}{:<17}{:<17}{:<5}".format(
            " ",
            "Type",
            " ",
            "Rev.",
            "Rev.",
            " ",
            "Type",
            "Address",
            "Camera",
            "Local",
            " "))
        
        print('-' * 120)

    def print_event(self, event, deviceInfo):
        """
        Prints out an enumeration event.
        """
        print("{:<10}{:<8}{:<10}{:<6}{:<6}{:<11}{:<10}{:<19}{:<17}{:<17}{:<5}".format(
            event, 
            otc.deviceTypeToString(deviceInfo.getDeviceType()), 
            deviceInfo.getSerialNumber(), 
            deviceInfo.getHardwareRevision(),
            "-" if deviceInfo.getFirmwareRevision() == 0           else deviceInfo.getFirmwareRevision(),
            "available" if deviceInfo.getConnectionState() == 0    else "busy",
            deviceInfo.getConnectionInterface(),
            "-" if deviceInfo.getMacAddress().toUInt64() == 0      else str(deviceInfo.getMacAddress()),
            "-" if deviceInfo.getIpAddress().toUInt32() == 0       else str(deviceInfo.getIpAddress()),
            "-" if deviceInfo.getTargetIpAddress().toUInt32() == 0 else str(deviceInfo.getTargetIpAddress()),
            "-" if deviceInfo.getPort().getNumber() == 0           else str(deviceInfo.getPort()),
            ))

def main():
    """ 
    Main entry point.
    """
    # Initialize the SDK by providing logger verbosity
    otc.Sdk.init(otc.Verbosity_Error, otc.Verbosity_Off, sys.argv[0])

    client = SimpleEnumerationClient()
    client.run()


if __name__ == "__main__":
    main()