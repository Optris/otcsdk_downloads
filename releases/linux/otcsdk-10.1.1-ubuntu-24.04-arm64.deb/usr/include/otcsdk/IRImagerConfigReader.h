// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImagerConfigReader.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a static class that reads the SDK configuration XML files.
 * 
 * @date 2025-01-02
 */

#pragma once

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/IRImagerConfig.h"
#include "otcsdk/Unicode.h"


namespace optris
{

/// Reads SDK configuration XML files.
class IRImagerConfigReader
{
public:
  /// No constructor.
  IRImagerConfigReader() = delete;


  /**
   * @brief Reads the XML configuration file with the given filename.
   *
   * @param[in]  filename path to the XML configuration file.
   * 
   * @return read SDK configuration.
   * 
   * @throw SDKException if reading the XML configuration file failed.
   */
  OTC_SDK_API static IRImagerConfig readT(const TString& filename);

  /**
   * @brief Reads the XML configuration file with the given filename.
   *
   * @param[in]  filename path to the XML configuration file.
   * 
   * @return read SDK configuration.
   * 
   * @throw SDKException if reading the XML configuration file failed.
   */
  OTC_SDK_API static IRImagerConfig read(const std::string& filename);
};

} // namespace optris