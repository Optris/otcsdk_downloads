// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImager.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface for all classes representing Optris thermal cameras.
 * 
 * @date 2024-12-10
 */

#pragma once

#include <memory>
#include <vector>

#include "otcsdk/Exceptions.h"
#include "otcsdk/ProcessInterface.h"
#include "otcsdk/IRImagerClient.h"
#include "otcsdk/IRImagerConfig.h"
#include "otcsdk/common/DeviceType.h"
#include "otcsdk/common/DeviceInfo.h"
#include "otcsdk/common/OperationMode.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/common/TemperaturePrecision.h"
#include "otcsdk/communication/net/DeviceNetworkConfig.h"


namespace optris
{

/// Interface defining the API for interacting with Optris thermal cameras.
class IRImager
{
public:
  /// Constructor.
  IRImager() = default;

  /// No copy constructor.
  IRImager(const IRImager&) = delete;
  /// No copy assignment.
  IRImager& operator=(const IRImager&) = delete;

  /// No move constructor.
  IRImager(IRImager&&) = delete;
  /// No move assignment.
  IRImager& operator=(IRImager&&) = delete;

  /// Destructor.
  virtual ~IRImager() = default;


  // Device connection
  /**
   * @brief Connects to the device with the given configuration.
   *
   * @note If the serial number in IRImagerConfig is set to 0, the SDK will use the `EnumerationManager` to find a device
   *       to connect to. 
   *       Its remaining data points will be ignored and the SDK will generate a default configuration for the detected
   *       device but without saving it.
   * 
   * @param[in] config configuration.
   *
   * @throw SDKException if connecting fails.
   */
  virtual void connect(IRImagerConfig config) = 0;

  /**
   * @brief Connects to the device with the given device information.
   * 
   * @note If the serial number is set to 0, the SDK will use the `EnumerationManager` to find a device to connect to.
   * 
   * @param[in] deviceInfo device information.
   * 
   * @throw SDKException if connecting fails.
   */
  virtual void connect(const DeviceInfo& deviceInfo) = 0;

  /**
   * @brief Connects to the device with the given serial number.
   *
   * @note If the serial number is set to 0, the SDK will use the `EnumerationManager` to find a device to connect to.
   * 
   * @param[in] serialNumber of the device.
   * 
   * @throw SDKException if connecting fails.
   */
  virtual void connect(unsigned long serialNumber) = 0;
  
  /// Disconnects from the current device.
  virtual void disconnect() = 0;

  /**
   * @brief Returns whether a connection is established.
   * 
   * @return true if a connection is established. False otherwise.
   */
  virtual bool isConnected() const noexcept = 0;


  // Client/Observer management
  /**
   * @brief Adds an observer/client that will be updated when new data arrives.
   *
   * @param[in] client callback client.
   */
  virtual void addClient(IRImagerClient* client) = 0;

  /**
   * @brief Removes the given observer/client.
   * 
   * @param[in] client to remove.
   * 
   * @return true, if the client was removed. False otherwise.
   */
  virtual bool removeClient(IRImagerClient* client) = 0;


  // Processing controls
  /**
   * @brief Runs the processing loop continuously.
   * 
   * Blocks until stopRunning() or disconnect() is called from another thread or until the application
   * terminates.
   * 
   * @see stopRunning(), disconnect()
   */
  virtual void run() = 0;

  /**
   * @brief Runs the processing loop continuously in a dedicated thread.
   * 
   * Runs until stopRunning() or disconnect() is called from another thread or until the application
   * terminates.
   * 
   * @note All callback methods of a registered client now are called from this processing thread.
   * 
   * @return true if the thread started within a second. False otherwise.
   * 
   * @see stopRunning(), disconnect()
   */
  virtual bool runAsync() = 0;

  /// Stops the continuously running processing loop.
  virtual void stopRunning() = 0;

  /**
   * @brief Returns whether the processing loop is currently running.
   * 
   * @return true if the processing loop is running. False otherwise.
   */
  virtual bool isRunning() const noexcept = 0;


  // Device information
  /**
   * @brief Returns the type of device the IRImager is connected to.
   * 
   * @return type of device the IRImager is connected to or unknown if not connected.
   */
  virtual DeviceType getDeviceType() const = 0;

  /**
   * @brief Returns the serial number of the connected device.
   *
   * @return serial number of the connected device or 0 if not connected.
   */
  virtual unsigned long getSerialNumber() const = 0;

  /**
   * @brief Returns the hardware revision of the connected device.
   *
   * @return hardware revision number of the connected device or 0 if not connected.
   */
  virtual unsigned int getHardwareRevision() const = 0;

  /**
   * @brief Returns the firmware revision of the connected device.
   *
   * @return firmware revision number of the connected device or 0 if not connected.
   */
  virtual unsigned int getFirmwareRevision() const = 0;

  
  // Connection details
  /**
   * @brief Returns the name of the connection interface used to communication with the device.
   * 
   * @return name of the connection interface used to communication with the device or an empty
   *         string if not connected.
   */
  virtual std::string getConnectionInterface() const noexcept = 0;

  /**
   * @brief Returns the IP address of the connected device.
   * 
   * @note The returned value is only relevant when connected to an Ethernet device.
   *
   * @return IP address of the connected device or 192.168.0.101 if not connected. 
   */
  virtual IpAddress getIpAddress() const noexcept = 0;

  /**
   * @brief Returns the number of the port on which the device data is received.
   * 
   * @note The returned value is only relevant when connected to an Ethernet device.
   *
   * @return number of the port on which the device data is received or 50101 if not connected.
   */
  virtual Port getPort() const noexcept = 0;


  // Operation modes
  /**
   * @brief Returns the operation modes for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * The returned container is always sorted in an ascending order based on the optics, temperature range
   * and video format properties.
   *
   * With OperationMode::getIndex() you can conveniently inquire a mode for its index within the returned
   * container.
   * 
   * @return operation modes for the currently connected device.
   * 
   * @throw SDKException if not connected.
   *
   * @see OperationMode::getIndex()
   */
  virtual std::vector<std::shared_ptr<OperationMode>> getOperationModes() = 0;

  /**
   * @brief Sets the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * @param[in] mode to set active.
   *
   * @throw SDKException if not connected, if mode is not supported by device or if applying the mode fails.
   */
  virtual void setActiveOperationMode(const std::shared_ptr<OperationMode>& mode) = 0;

  /**
   * @brief Sets the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   * 
   * @note You can use "wildcards", if you do not want to specify the optics, temperature range or video format
   *       explicitly:
   *       - optics           : set opticsFieldOfView to 0 AND leave opticsText empty.
   *       - temperature range: set temperatureLowerLimit AND temperatureUpperLimit to 0.
   *       - video format     : set width, height AND framerate to 0.
   * 
   * @param[in] opticsFieldOfView      in degrees.
   * @param[in] opticsText             further specifying the optics if the field of view is not unique enough.
   * @param[in] temperatureLowerLimit  in degree Celsius (not extended).
   * @param[in] temperatureUpperLimit  in degree Celsius (not extended).
   * @param[in] width                  in pixel of the output frame.
   * @param[in] height                 in pixel of the output frame.
   * @param[in] framerate              in Hz (not sub-sampled).
   *
   * @throw SDKException SDKException if not connected, if mode is not supported by device or if applying the mode fails.
   */
  virtual void setActiveOperationMode(int                opticsFieldOfView, 
                                      const std::string& opticsText, 
                                      float              temperatureLowerLimit,
                                      float              temperatureUpperLimit, 
                                      int                width,
                                      int                height,
                                      int                framerate) = 0;

  /**
   * @brief Returns the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * @return active operation mode for the currently connected device.
   *
   * @throw SDKException if not connected.
   */
  virtual std::shared_ptr<OperationMode> getActiveOperationMode() = 0;


  // Optics options
  /**
   * @brief Enables or disables the Size of Source Correction.
   *
   * @param[in] enable indicates whether to enable or disable the Size of Source Correction.
   *
   * @throw SDKException if not connected.
   */
  virtual void setSoSCorrectionEnabled(bool enable) = 0;

  /**
   * @brief Checks if the Size of Source Correction is enabled.
   *
   * @return true if the Size of Source Correction is enabled, false otherwise.
   *
   * @throw SDKException if not connected.
   */
  virtual bool isSoSCorrectionEnabled() const = 0;

  
  // Temperature range options
  /**
   * @brief Die-/Enables temperature range extension.
   *
   * @attention Extended temperature ranges feature poor precision and should not be used for measurements. 
   *            The main purpose of this feature is to give users an easier time to physically align the 
   *            field of view of the device when a temperature range has a high lower limit.
   * 
   * @note Not all temperature ranges can be extended.
   *
   * @param[in] enabled if true temperature range extension is enabled.
   */
  virtual void setTemperatureRangeExtensionEnabled(bool enabled) = 0;
  
  /**
   * @brief Returns whether the temperature ranges are being extended.
   * 
   * @note Not all temperature ranges can be extended.
   * 
   * @return true, if the temperature ranges are being extended. False, otherwise or if not connected.
   * 
   * @see OperationMode::isTemperatureRangeExtended(),
   *      OperationMode::isTemperatureRangeExtendable()
   */
  virtual bool isTemperatureRangeExtensionEnabled() const noexcept = 0;

  /**
   * @brief Dis-/Enables high precision temperature measurements.
   * 
   * @note Not all temperature ranges on all devices feature high precision temperature measurements.
   *
   * @param[in] enabled if true high temperature measurements are enabled.
   *
   * @throws SDKException if setting enabled failed or if not connected.
   */
  virtual void setTemperatureHighPrecisionEnabled(bool enabled) = 0;

  /**
   * @brief Returns whether high precision temperature measurements are enabled.
   * 
   * @note Not all temperature ranges on all devices feature high precision temperature measurements.
   * 
   * @return true, if high precision temperature measurements are enabled. False, otherwise or if
   *         not connected.
   * 
   * @see OperationMode::isTemperatureHighPrecision(),
   *      OperationMode::isTemperatureHighPrecisionAvailable()
   */
  virtual bool isTemperatureHighPrecisionEnabled() const noexcept = 0;


  // Thermal frame
  /**
   * @brief Returns the width in pixels of the thermal frame.
   *
   * @return width in pixels of the thermal frame, i.e. number of columns or 0 if not connected.
   */
  virtual int getWidth() const = 0;

  /**
   * @brief Returns the height in pixels of thermal frame.
   *
   * @return height in pixels of the thermal frame, i.e. number of rows or 0 if not connected.
   */
  virtual int getHeight() const = 0;


  // Measurement fields
  /**
   * @brief Adds a measurement field that is processed for every new thermal frame.
   *
   * The resulting data can be accessed via the IRImagerClient::onMeasurementField() callback.
   *
   * @param[in] config of the measurement field to add.
   *
   * @return the index of the added measurement field.
   *
   * @throw SDKException if not connected or if the measurement field is not completely within the 
   *                     thermal frame or if adding it failed.
   */
  virtual int addMeasurementField(const MeasurementFieldConfig& config) = 0;
 

  // Shutter flag
  /**
   * @brief Sets the automatic triggering of flag cycles en-/disabled.
   *
   * @param[in] enable or disable automatic triggering of flag cycles.
   */
  virtual void setAutoFlagEnabled(bool enable) = 0;

  /**
   * @brief Returns whether flag cycles are triggered automatically.
   *
   * @return true, if flag cycles are triggered automatically. False is automatic triggering is diabled or if not connected.
   */
  virtual bool isAutoFlagEnabled() const = 0;

  /**
   * @brief Sets the minimum and maximum flag intervals in seconds.
   *
   * @param[in] minInterval minimal time in seconds that has to elapse before a new flag cycle is triggered.
   * @param[in] maxInterval maximum time in seconds that can elapse until a new flag cycle is triggered. Set to 0 to
   *                        deactivate.
   *
   * @throw SDKException if provided intervals are negative.
   */
  virtual void setFlagInterval(float minInterval, float maxInterval) = 0;

  /**
   * @brief Returns the minimum flag interval in seconds.
   * 
   * Minimum time that has to elapse before a new flag cycle is triggered.
   *
   * @return minimum flag interval in seconds or 0 if not connected.
   */
  virtual float getFlagMinInterval() const = 0;

  /**
   * @brief Returns the maximum flag interval in seconds.
   *
   * Maximum time that can elapse before a new flag cycle is triggered.
   * 
   * @return maximum flag interval in seconds or 0 if not connected.
   */
  virtual float getFlagMaxInterval() const = 0;

  /**
   * @brief Force a flag cycle manually.
   *
   * @param[in] time point of time in future in milliseconds, when the shutter flag should be closed.
   *
   * @throw SDKException if not connected.
   */
  virtual void forceFlagEvent(float time = 0.F) = 0;

  /**
   * @brief Returns whether the shutter flag is open.
   *
   * @return true if the shutter flag is open. False if the shutter flag is closed or if not
   *         connected.
   */
  virtual bool isFlagOpen() const = 0;

  /**
   * @brief Set the shutter flag forecast en-/disabled.
   *
   * @param enable of disable the shutter flag forecast.
   *
   * @throw SDKException if not connected.
   */
  virtual void setFlagForecastEnabled(bool enable) = 0;

  /**
   * @brief Returns whether the shutter flag forecast is en-/disabled.
   *
   * @return true if the shutter flag forecast is enabled. False if flag forecast is disabled or if not
   *         connected.
   */
  virtual bool isFlagForecastEnabled() const = 0;


  // Internal temperature probes
  /**
   * @brief Returns the temperature of the shutter flag in °C.
   *
   * @return temperature of the shutter flag in °C or INVALID_TEMPERATURE if not connected or
   *         35.0 °C if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureFlag() const = 0;

  /**
   * @brief Returns the temperature of the device housing in °C.
   *
   * @return temperature of the device housing in °C or INVALID_TEMPERATURE if not connected or 35.0 °C
   *         if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureBox() const = 0;

  /**
   * @brief Returns the temperature of the sensor chip.
   *
   * @return temperature of the sensor chip in °C or INVALID_TEMPERATURE if not connected or
   *         35.0 °C if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureChip() const = 0;


  // Sensor chip heating
  /**
   * @brief Enables the heating of the sensor chip.
   *
   * @param[in] enable indicates whether to enable heating.
   *
   * @throw SDKException if not connected.
   */
  virtual void setChipHeatingEnabled(bool enable) = 0;

  /**
   * @brief Return whether the sensor chip heating is enabled.
   *
   * @return true, if the sensor chip heating is enabled. False if heating is disabled of if not connected.
   */
  virtual bool isChipHeatingEnabled() const = 0;

  /**
   * @brief Sets the reference temperature in °C for the sensor chip heating.
   *
   * The specified temperature should be in [20, 55] °C. If not, the temperature will automatically be clipped.
   * The current chip temperature can be monitored with getTemperatureChip().
   *
   * @param[in] temperature to set in °C.
   *
   * @throw SDKException if not connected.
   */
  virtual void setTemperatureChipReference(float temperature) = 0;

  /**
   * @brief Returns the reference temperature in °C of the sensor chip heating.
   *
   * @return temperature of the sensor chip in °C or INVALID_TEMPERATURE if not connected.
   */
  virtual float getTemperatureChipReference() const = 0;


  // Radiation parameters
  /**
   * @brief Returns the source that currently defines the emissivity for the thermal frame.
   * 
   * @return source that currently defines the emissivity for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getEmissivitySource() const noexcept = 0;

  /**
   * @brief Returns the source that currently defines the transmissivity for the thermal frame.
   * 
   * @return source that currently defines the transmissivity for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getTransmissivitySource() const noexcept = 0;

  /**
   * @brief Returns the source that currently defines the ambient temperature for the thermal frame.
   * 
   * @return source that currently defines the ambient temperature for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getAmbientTemperatureSource() const noexcept = 0;

  /**
   * @brief Sets the radiation parameters (emissivity, transmissivity and ambient temperature).
   *
   * @param[in] radiation parameters to set.
   *
   * @throw SDKException if not connected or if parameters are invalid or if setting the parameters fails.
   */
  virtual void setRadiationParameters(const RadiationParameters& radiation) = 0;

  /**
   * @brief Returns the set/configured radiation parameters.
   *
   * @attention The radiation parameters may be modified via the process interface (PIF) and through automated
   *            ambient temperature estimations. This method return the parameters set in the configuration
   *            or vis IRImager::setRadiationParameters().
   *
   *            To get the actually applied parameters see the FrameMetadata::getRadiationParameters() for the
   *            thermal frame and the MeasurementField::getRadiationParameters() for measurement fields.
   *
   * @return the set/configured radiation parameters or their default values if not connected.
   */
  virtual RadiationParameters getRadiationParameters() const = 0;

  
  // Focus motor
  /**
   * @brief Sets the position of the focus motor.
   *
   * The position should be in [0, 100] %. If not, the position will automatically be clipped.
   *
   * @param[in] position focus motor position in %.
   *
   * @throw SDKException if not connected or if no focus motor is available.
   */
  virtual void setFocusMotorPosition(float position) = 0;

  /**
   * @brief Returns the position of the focus motor.
   *
   * @return focus motor position in % or -1.0 if not connected or if no focus motor is available.
   */
  virtual float getFocusMotorPosition() const = 0;


  // Reference temperature
  /**
   * @brief Sets a reference temperature to a known reference source inside the view of the device to improve measurement accuracy.
   *
   * @param[in] referenceTemperature real temperature of reference source.
   * @param[in] measuredTemperature  measured temperature from the device of reference source.
   * @param[in] ambientTemperature   in °C. Set it to INVALID_TEMPERATURE or less to force the SDK to estimate the
   *                                 ambient temperature based on thermal probe readings of the device.
   *
   * @throw SDKException if not connected.
   */
  virtual void setReferenceTemperature(float referenceTemperature, float measuredTemperature, float ambientTemperature = INVALID_TEMPERATURE) = 0;

  /**
   * @brief Resets a previously set reference temperature.
   * 
   * @throw SDKException if not connected.
   */
  virtual void resetReferenceTemperature() = 0;


  // Device network configuration
  /**
   * @brief Sets the network configuration of the device.
   * 
   * @param[in] networkConfig to set.
   * 
   * @throw SDKException if not connect via USB or if device does not support Ethernet or if setting the device network configuration
   *                     failed.
   */
  virtual void setDeviceNetworkConfig(const DeviceNetworkConfig& networkConfig) = 0;

  /**
   * @brief Returns the network configuration of the device.
   * 
   * @return network configuration of the device.
   * 
   * @throw SDKException if not connect via USB or if device does not support Ethernet or if getting the device network configuration
   *                     failed.
   */
  virtual DeviceNetworkConfig getDeviceNetworkConfig() = 0;


  // Process Interface
  /**
   * @brief Grants access to the process interface.
   * 
   * @warning The reference becomes invalid on disconnects.
   * 
   * @return reference to the process interface.
   * 
   * @throw SDKException if not connected.
   */
  virtual ProcessInterface& getPif() = 0;

  /**
   * @brief Grants read access to the process interface.
   * 
   * @warning The reference becomes invalid on disconnects.
   * 
   * @return constant reference to the process interface.
   * 
   * @throw SDKException if not connected.
   */
  virtual const ProcessInterface& getPif() const = 0;


  // Fail safe
  /**
   * @brief Interrups the all clear fail safe signal.
   * 
   * @note The client is only one source that can trigger the fail safe. If any of these sources detects an error, the fail safe
   *       will be triggered and it will only be released, if ALL the sources report an all clear.
   * 
   * @param[in] active if true the all clear signal is interrupted. If false, the all clear may be restored, if all other sources
   *                   report an all clear.
   * @param[in] reason to be displayed in the logs.
   * 
   * @throw SDKException if not connected.
   */
  virtual void interruptFailSafe(bool active, const std::string& reason) = 0;
};

} // namespace optris