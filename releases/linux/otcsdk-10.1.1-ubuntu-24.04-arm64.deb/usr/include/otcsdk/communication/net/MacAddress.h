// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   MacAddress.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing a MAC address.
 * 
 * @date 2025-09-19
 */

#pragma once

#include <cstdint>
#include <string>
#include <array>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"


namespace optris
{

/**
 * @brief Encapsulates a media access control address (MAC address).
 * 
 * A MAC address is usually specified by six bytes in hex notation separated by colons, like this:
 *
 * 12:34:56:78:9a:bc
 * 
 */
class MacAddress
{
public:
  /**
   * @brief Constructor.
   * 
   * All MAC address bytes are set to 0.
   */
  OTC_SDK_API MacAddress() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] mac address as an unsigned 64 bit integer.
   * 
   * @throw SDKException if the given value is outside [0x00, 0xffffffffffff]. 
   */
  OTC_SDK_API MacAddress(std::uint64_t mac);

  /**
   * @brief Constructor.
   * 
   * @param[in] mac address string in colon notation (a:b:c:d:e:f).
   * 
   * @throw SDKException if the given string does not contain a valid MAC address. 
   */
  OTC_SDK_API MacAddress(const std::string& mac);

  /**
   * @brief Constructor.
   * 
   * @param[in] a byte from an a:b:c:d:e:f MAC address.
   * @param[in] b byte from an a:b:c:d:e:f MAC address.
   * @param[in] c byte from an a:b:c:d:e:f MAC address.
   * @param[in] d byte from an a:b:c:d:e:f MAC address.
   * @param[in] e byte from an a:b:c:d:e:f MAC address.
   * @param[in] f byte from an a:b:c:d:e:f MAC address.
   */
  OTC_SDK_API MacAddress(std::uint8_t a, std::uint8_t b, std::uint8_t c, std::uint8_t d, std::uint8_t e, std::uint8_t f) noexcept;


  /// Resets all the bytes of the MAC address to 0 (0:0:0:0:0:0).
  OTC_SDK_API void reset() noexcept;

  /**
   * @brief Sets the MAC address from an unsigned 64 bit integer.
   *
   * @param[in] mac address as an unsigned 64 bit integer.
   *
   * @throw SDKException if the given value is outside [0x00, 0xffffffffffff]. 
   */
  OTC_SDK_API void setFromUInt64(std::uint64_t mac);

  /**
   * @brief Returns the MAC address as an unsigned 64 bit integer.
   *
   * @return MAC address as an unsigned 64 bit integer.
   */
  OTC_SDK_API std::uint64_t toUInt64() const noexcept;

  /**
   * @brief Sets the MAC address from the given string.
   * 
   * @param[in] mac address string in colon notation (a:b:c:d:e:f).
   * 
   * @throw SDKException if the given string does not contain a valid mac address. 
   */
  OTC_SDK_API void setFromString(const std::string& mac);

  /**
   * @brief Returns the MAC address as a string in colon notation (a:b:c:d:e:f).
   * 
   * @return MAC address as a string in colon notation (a:b:c:d:e:f).
   */
  OTC_SDK_API std::string toString() const noexcept;

  /**
   * @brief Sets the value of the byte with the given index.
   * 
   * @param[in] index of the byte to set.
   * @param[in] value to set.
   * 
   * @throw SDKException if index is out of range.
   */
  OTC_SDK_API void setByte(int index, std::uint8_t value);

  /**
   * @brief Returns the value of the byte with the given index.
   * 
   * @param[in] index of the desired byte.
   * 
   * @return value of the byte with the given index.
   * 
   * @throw SDKException if the index is out of range.
   */
  OTC_SDK_API std::uint8_t getByte(int index) const;
  
  
  /// Equality operator.
  bool operator==(const MacAddress& rhs) const noexcept;
  /// Equality operator.
  bool operator==(const std::uint64_t& rhs) const;
  /// Unequality operator.
  bool operator!=(const MacAddress& rhs) const noexcept;


private:
  /// Stored MAC address.
  std::array<std::uint8_t, 6> _bytes;
};

// Utility functions
/**
 * @brief Output stream operator for MAC addresses.
 * 
 * @param[in] out stream to write the MAC address to.
 * @param[in] mac to output.
 *
 * @return used output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const MacAddress& mac) noexcept;


// Inline implementations
inline bool MacAddress::operator==(const MacAddress& rhs) const noexcept
{
  return _bytes == rhs._bytes;
}

inline bool MacAddress::operator==(const std::uint64_t& rhs) const
{
  return toUInt64() == rhs;
}

inline bool MacAddress::operator!=(const MacAddress& rhs) const noexcept
{
  return !(_bytes == rhs._bytes);
}

} // namespace optris