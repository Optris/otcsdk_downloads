// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   MeasurementFieldConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the configuration of a measurement field.
 * 
 * @date 2025-07-23
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/fields/FieldProperties.h"


namespace optris
{

/// Encapsulates the configuration of a measurement field.
class MeasurementFieldConfig
{
public:
  /// Constructor.
  OTC_SDK_API MeasurementFieldConfig() noexcept;


  /**
   * @brief Validates the configuration settings.
   * 
   * @throw SDKException if the configuration contains invalid settings.
   */
  OTC_SDK_API void validate();


  /// Name of the measurement field.
  std::string name;
  
  /// Shape of the measurement field.
  FieldShape shape;

  /// Mode for the measurement field.
  FieldMode mode;

  /**
   * @brief x position of the measurement field in pixels.
   * 
   * Depending of the shape of the field this may refer to different things:
   * - rectangle: Position of the upper left corner.
   */
  int positionX;

  /**
   * @brief y position of the measurement field in pixels.
   * 
   * Depending of the shape of the field this may refer to different things:
   * - rectangle: Position of the upper left corner.
   */
  int positionY;


  /**
   * @brief Width of the measurement field in pixels.
   * 
   * Applicable for the following shapes:
   * - rectangle
   */
  int width;

  /**
   * @brief Height of the measurement field in pixels.
   * 
   * Applicable for the following shapes:
   * - rectangle
   */
  int height;


  /// Radiation parameters for the measurement field.
  RadiationParameters radiation;
};


// Utility functions
/**
 * @brief Ouput stream operator for measurement field configurations.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] config to output.
 *
 * @return used output stream. 
 */
std::ostream& operator<<(std::ostream& out, const MeasurementFieldConfig& config) noexcept;

} // namespace optris