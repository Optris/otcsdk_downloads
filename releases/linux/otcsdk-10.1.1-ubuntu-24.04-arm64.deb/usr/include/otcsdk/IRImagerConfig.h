// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImagerConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the SDK settings found in the configuration file.
 * 
 * @date 2024-12-09
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/communication/net/IpAddress.h"
#include "otcsdk/fields/MeasurementFieldConfig.h"
#include "otcsdk/pif/PifConfig.h"


namespace optris
{

/// Holds the SDK settings found in the configuration file.
class IRImagerConfig
{
public:
  /// Constructor.
  OTC_SDK_API IRImagerConfig() noexcept;


  /**
   * @brief Validates the configuration settings.
   * 
   * If a faulty setting can be replaced by a valid default this method will do so automatically and
   * print a log warning message. If no valid default is available a SDKException is throws instead.
   * 
   * @throw SDKException if configuration contains uncorrectable invalid settings.
   */
  OTC_SDK_API void validate();


  // General
  /// Version of the configuration file.
  int version;
  /// Serial number of the device.
  unsigned long serialNumber;


  /**
   * @brief Interface used to connect to the device (USB, Ethernet).
   * 
   * Case insensitive.
   */
  std::string connectionInterface;
  /// IP address of the device.
  IpAddress ipAddress;
  /// Local UDP port to which the device sends data to.
  unsigned short port;
  /**
   * @brief Flag indicating whether to only process UDP packages from the IP address specified by the
   *        ipAddress member variable.
   * 
   * Set to true to activate this check or set to false to deactivate it.
   */
  bool checkIp;
  /**
   * @brief Specifies the time in seconds that has to elapse without no new frame received until an 
   *        connection timeout occurs.
   * 
   * If connection timeout is detected the IRImager instance will call the IRImagerClient::onConnectionTimeout()
   * callback. 
   */
  int connectionTimeout;


  /**
   * @brief Internal queue size for buffers holding received frames.
   * 
   * This setting has no influence on the size of the buffers. Their size is determined by the used video
   * format.
   */
  unsigned short bufferQueueSize;

  /**
   * @brief Width in pixels of the output frame.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int width;
  /**
   * @brief Height in pixels of the output frame.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int height;
  /**
   * @brief Output framerate in Hz.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int framerate;

  /**
   * @brief Subsampled output framerate.
   * 
   * The SDK internally reduces the output framerate to this value. This setting has no effect on the device
   * itself, meaning the device will always send frames at the rate specified by the framerate member variable.
   * 
   * Set to a value in [0, framerate] to achieve subsampling or set to a value to less than 0 to deactivate this
   * feature.
   */
  float subsampledFramerate;


  /**
   * @brief Field of view of the optics in degree.
   * 
   * If the field of view is set to 0 and the opticsText is empty the SDK will use the first available optics.
   */
  int fieldOfView;
  /**
   * @brief Optional text further specifying the used optics.
   * 
   * If the field of view is set to 0 and the opticsText is empty the SDK will use the first available optics.
   */
  std::string opticsText;

  /**
   * @brief Use Size of Source Correction if available in calibration data.
   * 
   * If true, Size of Source Correction will automatically be used if available in calibration data.
   */
  bool enableSoSCorrection;


  /**
   * @brief Lower limit of the desired temperature range in °C.
   * 
   * Always use the temperatures for the not extended range.
   * 
   * If the minimum and maximum temperature are set to 0 the SDK will use the first available temperature range.
   */
  int minTemperature;
  /**
   * @brief Upper limit of the desired temperature range in °C.
   * 
   * Always use the temperatures for the not extended range.
   * 
   * If the minimum and maximum temperature are set to 0 the SDK will use the first available temperature range.
   */
  int maxTemperature;

  /**
   * @brief Extends the chosen temperature range if possible.
   * 
   * When extending the temperature range you do not need to change the values for minTemperature and maxTemperature.
   * The range is always specified by the non extended temperatures.
   * 
   * @warning Extended temperature ranges are intended to help you align the field of view of your camera. The precision
   *          of the temperature measurements in this mode may not be within the specification.
   */
  bool enableExtendedTemperatureRange;
  /**
   * @brief Use high precision temperatures if available.
   * 
   * If true, high precision temperatures will automatically be used if the device and the chosen temperature range
   * supports them.
   */
  bool enableHighPrecisionTemperature;

  /**
   * @brief Enable the automatic triggering of flag cycles.
   * 
   * Optris thermal cameras feature an internal shutter flag. It need to be closed periodically for the SDK to compensate
   * for drifting temperature measurements.
   * 
   * If set to true, flag cycles will be automatically triggered when one of the temperatures measured by internal probes
   * changes by more than 0.1 °C. 
   */
  bool autoFlag;
  /// Minimum time in seconds that has to pass before a new flag cycle can be triggered.
  float minInterval;
  /// Maximum time in seconds that can pass before a new flag cycle is forced.
  float maxInterval;
  

  /**
   * @brief Specified how and if the sensor chip is beeing heated.
   * 
   * The following modes are available:
   *  - floating: The sensor chip will not be heated.
   *  - auto    : The sensor chip will be heated to the temperature specified in the calibrations.
   *  - fixed   : The sensor chip will be heated to the temperature specified by the chipHeatingTemperature settings.
   * 
   * Case insensitive.
   */
  std::string chipHeatingMode;
  /// Temperature in °C for the fixed chipHeatingMode.
  float chipHeatingTemperature;


  /**
   * @brief Position of the focus motor in % ([0, 100]).
   * 
   * Should be in [0., 100.]. Set to a value less than 0 for the SDK to ignore this setting.
   */
  float focusMotorPosition;

  /**
   * @brief Radiation parameters for the overall thermal frame.
   * 
   * For the radiation parameters of measurement fields see the MeasurementFieldConfig class.
   */
  RadiationParameters radiation;


  /**
   * @brief Activate multithreading for postprocessing.
   * 
   * @warning Experimental setting.
   */
  bool enableMultiThreading;


  /**
   * @brief Indicates whether a flag timeout that caused the failure of a flag cycle should trigger the fail safe.
   * 
   * A flag timeout occurs when the shutter flag does not reach its expected state within a given time frame. If this happens, the current
   * flag cycle will be considered to have failed.
   */
  bool failSafeFlagTimeouts;

  /**
   * @brief Specifies the number of failed flag cycles to be tolerated before fail safe is triggered due to flag timeouts.
   * 
   * @see IRImagerConfig::failSafeTriggerOnFlagTimeout
   */
  int failSafeFlagTimeoutsMaxCycleFailures;

  /**
   * @brief Indicates whether a failure of the processing chain to reach all of its endpoints (thermal frame and measurement fields) within a given 
   *        time frame should trigger the fail safe.
   * 
   * If set to false, the fail safe will still be triggered when the processing chain itself crashes or gets stuck.
   */
  bool failSafeProcessingChainTimeouts;


  /// Measurement field configuration.
  std::vector<MeasurementFieldConfig> measurementFields;

  
  /// Processing interface configuration.
  PifConfig processInterface;
};


// Utility
/**
 * @brief Output stream operator for the IRImagerConfig.
 * 
 * @param[out] out    stream to output to.
 * @param[in]  config to output.
 *
 * @return used output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const IRImagerConfig& config);

} // namespace optris
