// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   Api.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains defines controlling the Windows DLL export and import of symbols.
 *
 * @date 2024-12-19
 *
 *
 * The following defines are used to mark classes, structs or functions as the
 * public API accessible in Windows DLLs.
 *
 * For a symbol to be accessible in a Windows DLL its source has to be marked with
 * __declspec(export) when compiling the library. On the other hand, when you want
 * to build against the dynamic library the same resources must be marked with
 *  __declspec(import) to signal to the toolchain that its implementation has to be
 * imported from that library.
 *
 * In order to use the same header files for building the dynamic library and for
 * building against it the preprocessor define logic below was established. It
 * covers the following cases:
 *
 * - Building a dynamic library on Windows (DLL)
 *   IR_DIRECT_SDK_EXPORT must be defined so that the marked resources appear
 *   as accessible symbols in the generated DLL.
 *
 * - Building against the dynamic SDK library (DLL)
 *   Nothing needs to be defined. The logic below ensures that all marked resources
 *   are imported from the Windows (DLL)
 *
 * - Building a static library on Windows (LIB)
 *   OTC_SDK_STATIC must be defined to that none of the marked resources receive
 *   special modifiers. They are unnecessary for a static library.
 *
 * - Building against the static library (LIB)
 *   OTC_SDK_STATIC must be defined to that none of the marked resources receive
 *   special modifiers. If using CMake to build against the SDK this define is
 *   automatically set.
 *
 * - Linux
 *   On Linux nothing needs to be defined for all the cases above. Its format for
 *   dynamic libraries does not require the same attention.
 */

#pragma once

// Symbol export to DLLs under Windows.
#if defined(_WIN32) && !defined(OTC_SDK_STATIC)
  /// Calls function with C conventions.
  #define OTC_SDK_C_CALL __cdecl
  #ifdef OTC_SDK_DLL_EXPORT
    /// Exposes the symbol of the marked resource in a Windows DLL.
    #define OTC_SDK_API __declspec(dllexport)
    /// Empty for Windows DLL generation.
    #define OTC_SDK_EXTERN
  #else
    /// Marks this resource as to be imported from a Windows DLL.
    #define OTC_SDK_API __declspec(dllimport)
    /// Marks a resource extern to ensure Windows DLL import.
    #define OTC_SDK_EXTERN extern
  #endif
#else
  /// Only needed when working with Windows DLLs.
  #define OTC_SDK_API
  /// Only needed when working with Windows DLLs.
  #define OTC_SDK_EXTERN
  /// Only needed when working with Windows DLLs.
  #define OTC_SDK_C_CALL
#endif
