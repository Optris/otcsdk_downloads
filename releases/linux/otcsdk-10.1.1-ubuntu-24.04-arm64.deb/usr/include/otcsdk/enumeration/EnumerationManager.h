// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   EnumerationManager.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that monitors available devices.
 * 
 * @date 2024-09-23
 */

#pragma once

#include <atomic>
#include <vector>
#include <thread>
#include <mutex>
#include <memory>
#include <set>
#include <condition_variable>
#include <unordered_set>
#include <unordered_map>

#include "otcsdk/Api.h"
#include "otcsdk/common/DeviceInfo.h"
#include "otcsdk/enumeration/EnumerationClient.h"
#include "otcsdk/enumeration/EnumerationDetector.h"


namespace optris
{

/**
 * @brief Detects and monitors available devices.
 * 
 * It detects devices that the SDK can potentially connect to.
 * 
 * This class is implemented with the help of the Singleton design pattern. As a consequence, you have to use
 * the EnumerationManager::getInstance() method to interact with it.
 * 
 * Furthermore, allows the registration of observers aka. EnumerationClient that want be informed if the detection
 * status of a device changes.
 */
class EnumerationManager
{
public:
  /// No copy constructor.
  OTC_SDK_API EnumerationManager(const EnumerationManager&) = delete;
  /// No copy assignment.
  OTC_SDK_API EnumerationManager& operator=(const EnumerationManager&) = delete;

  /// No move constructor.
  OTC_SDK_API EnumerationManager(EnumerationManager&&) = delete;
  /// No move assignment.
  OTC_SDK_API EnumerationManager& operator=(EnumerationManager&&) = delete;

  /// Destructor.
  OTC_SDK_API virtual ~EnumerationManager();


  /**
   * @brief Returns an instance of the EnumerationManager.
   * 
   * Only one instance per program is available (Singleton).
   * 
   * @return EnumerationManager instance.
   */
  OTC_SDK_API static EnumerationManager& getInstance();
   

  /**
   * @brief Returns information about the currently detected devices.
   * 
   * @note This method will never wait, if the EnumerationManger is not running. In this way clients
   *       can not unexpectedly get stuck in this method. 
   *
   * @param[in] seconds  <  0 the method waits indefintfly for the first detection pass to complete.
   *                     == 0 the method will not wait.
   *                     >  0 the method waits the given amount of seconds for th first detection pass 
   *                          to complete.
   * 
   * @return a vector holding the currently detected devices.
   */
  OTC_SDK_API std::vector<DeviceInfo> getDetectedDevices(int seconds = 0);
  

  /**
   * @brief Adds an observer/client that will be updated if a device detection status changes.
   *
   * @param[in] client callback client.
   */
  OTC_SDK_API void addClient(EnumerationClient* client);

  /**
   * @brief Removes the given observer/client.
   *
   * @param[in] client to remove.
   */
  OTC_SDK_API bool removeClient(EnumerationClient* client);

  
  /**
   * @brief Runs the connection event detection continuously.
   * 
   * This method blocks until stopRunning() is called from a different thread or until the program
   * terminates.
   * 
   * @see stopRunning()
   */
  OTC_SDK_API void run();

  /**
   * @brief Runs the connection event detection continuously in a dedicated thread.
   * 
   * This method runs until stopRunning() is called from a different thread or until the program
   * terminates.
   * 
   * @note All callback methods of a registered EnumerationClient are called from this detection thread.
   * 
   * @return true if the thread started within a second. False otherwise.
   * 
   * @see stopRunning()
   */
  OTC_SDK_API bool runAsync();

  /** 
   * @brief Stops the continuous connection event detection.
   *
   * This does not clear the list of currently detected devices.
   */
  OTC_SDK_API void stopRunning();

  /**
   * @brief Returns whether the connection event detection is running.
   * 
   * @return whether the connection event detection is running.
   */
  OTC_SDK_API bool isRunning() const noexcept;


  /**
   * @brief Sets the minimum period in milliseconds for a single connection event detection run.
   * 
   * @param[in] period in milliseconds to set.
   */
  OTC_SDK_API void setDetectionPeriod(int period) noexcept;

  /**
   * @brief Returns the minimum period in milliseconds for a single connection event detection run.
   * 
   * @return minimum period in milliseconds for a single connection event detection run.
   */
  OTC_SDK_API int getDetectionPeriod() const noexcept;


  /**
   * @brief Adds a detector for USB devices.
   * 
   * @return name of the added detector. It is "usb", if the detector was added successfully. An empty string, if 
   *         adding the detector failed or if a USB detector was already added.
   */
  OTC_SDK_API std::string addUsbDetector();

  /**
   * @brief Removes the detector for USB devices.
   * 
   * @return true, if an existing detector was removed. False otherwise.
   */
  OTC_SDK_API bool removeUsbDetector();

  /**
   * @brief Adds a detector for Ethernet devices in the specified network.
   * 
   * @param[in] networkAddress in CIDR notation: a.b.c.d/cider with a.b.c.d as the network IP address and
   *                           cidr as the number of bits that constitute the network portion of the IP
   *                           address. It is a shorthand for the subnet mask. Its value, typically, equals the number
   *                           of 1 bits in the subnet mask.
   *
   * @return name of the added detector. It is "<network address in CIDR notation>" (e.g. 192.168.0.0/24), if the
   *         detector was added successfully. An empty string, if the provided network address could not be parsed
   *         or if adding the detector failed or if a detector for this network was already added.
   */
  OTC_SDK_API std::string addEthernetDetector(const std::string& networkAddress);

  /**
   * @brief Remove the Ethernet detector for the specified network.
   * 
   * @param[in] networkAddress in CIDR notation: a.b.c.d/cider with a.b.c.d as the network IP address and
   *                           cidr as the number of bits that constitute the network portion of the IP
   *                           address. It is a shorthand for the subnet mask. Its value, typically, equals the number
   *                           of 1 bits in the subnet mask.
   *
   * @return true, if an exiting detector was removed. False if no detector for the given network existed or if
   *         the provided network address could not be parsed.
   */
  OTC_SDK_API bool removeEthernetDetector(const std::string& networkAddress);

  /**
   * @brief Adds a detector for Ethernet devices in the specified network.
   *
   * @param[in] networkAddress IP address of the network. Its host portion will be ignored.
   * @param[in] cidr           number of bits that constitute the network portion of the provided IP address. It is a
   *                           shorthand for the subnet mask. Its value, typically, equals the number of 1 bits in the
   *                           subnet mask.
   *
   * @return name of the added detector. It is "<network address in CIDR notation>" (e.g. 192.168.0.0/24), if the
   *         detector was added successfully. An empty string, if adding the detector failed or if a detector for 
   *         this network was already added.
   */
  OTC_SDK_API std::string addEthernetDetector(const IpAddress& networkAddress, int cidr);

  /**
   * @brief Remove the Ethernet detector for the specified network.
   * 
   * @param[in] networkAddress IP address of the network. Its host portion will be ignored.
   * @param[in] cidr           number of bits that constitute the network portion of the provided IP address. It is a
   *                           shorthand for the subnet mask. Its value, typically, equals the number of 1 bits in the
   *                           subnet mask.
   *
   * @return true, if an exiting detector was removed. False otherwise.
   */
  OTC_SDK_API bool removeEthernetDetector(const IpAddress& networkAddress, int cidr);

  /**
   * @brief Adds a new detector for connected devices.
   * 
   * @param[in] name     under which to register the detector. If an empty string is provided, no detector
   *                     will be added.
   * @param[in] detector to register.
   *
   * @return name of the added detector or an empty string if adding the detector failed or if a detector
   *         with the same name was already added. 
   */
  OTC_SDK_API std::string addDetector(const std::string& name, std::shared_ptr<EnumerationDetector> detector);

  /**
   * @brief Removes the detector with the given name.
   * 
   * @param[in] name of the detector to remove.
   *
   * @return true, if a detector with the given name was removed. False otherwise. 
   */
  OTC_SDK_API bool removeDetector(const std::string& name);

  /// Clears all added detectors.
  OTC_SDK_API void clearDetectors();

  /**
   * @brief Returns the names of all added detectors.
   * 
   * @return names of all added detectors. 
   */
  OTC_SDK_API std::vector<std::string> getDetectorNames();

  /**
   * @brief Return the detector registered under the given name.
   * 
   * @param[in] name of the desired detector.
   *
   * @return shared pointer to the detector or a nullptr if a detector with the given name is not registered.
   */
  OTC_SDK_API std::shared_ptr<EnumerationDetector> getDetector(const std::string& name);
  

private:
  using Mutex     = std::mutex;
  using Lock      = std::unique_lock<Mutex>;
  using Condition = std::condition_variable;
  

  EnumerationManager();


  void detectDevices();

  void notifyClientsOfDetection(const DeviceInfo& deviceInfo);
  void notifyClientsOfLostDetection(const DeviceInfo& deviceInfo);
  void notifyClientsOfChangedDetection(const DeviceInfo& deviceInfo);

  void waitForDetectionUpdate(int seconds);
  void notifyOfDetectionUpdate();


  Mutex                _detectedDevicesMutex;
  std::set<DeviceInfo> _detectedDevices;

  Mutex                        _runMutex;
  std::atomic<bool>            _shutdown;
  std::atomic<bool>            _running;
  std::atomic<int>             _period;
  std::unique_ptr<std::thread> _thread;	

  Mutex     _waitForDetectionUpdateMutex;
  Condition _waitForDetectionUpdateCondition;
  bool      _waitForDetectionUpdateComplete;

  Mutex _waitForDetectionUpdateConditionsMutex;
  bool  _newDetectorAdded;

  Mutex                                  _clientsMutex;
  std::unordered_set<EnumerationClient*> _clients;

  Mutex                                                                 _detectorsMutex;
  std::unordered_map<std::string, std::shared_ptr<EnumerationDetector>> _detectors;
};


// Inline implementations
inline void EnumerationManager::setDetectionPeriod(int period) noexcept
{
  _period = period;
}

inline int EnumerationManager::getDetectionPeriod() const noexcept
{
  return _period;
}

} // namespace optris