// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   DeviceType.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an enum representing the different types of Optris thermal cameras.
 * 
 * @date 2025-01-09
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"


namespace optris 
{

/// Represents the different types of Optris thermal cameras.
enum class DeviceType
{
  Unknown, 
  PI1,
  PI160, 
  PI2x0, 
  PI160orPI2x0, 
  PI4x0, 
  PI4x0I,
  PI640,
  PI640I,
  PI1M, 
  Xi80, 
  Xi160, 
  Xi320,
  Xi320MT,  
  Xi400, 
	Xi410,
  Xi410MT,
  Xi440,
  Xi640, 
  Xi1M, 
};


// Utility functions
/**
 * @brief Returns whether the given device is PI.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device is a PI. False otherwise.
 */
OTC_SDK_API bool isPI(DeviceType type) noexcept;

// Utility functions
/**
 * @brief Returns whether the given device is a Xi.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device is a Xi. False otherwise.
 */
OTC_SDK_API bool isXI(DeviceType type) noexcept;

// Utility functions
/**
 * @brief Returns whether the given device is of the 1M variety.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device is of the 1M variety. False otherwise.
 */
OTC_SDK_API bool is1MDevice(DeviceType type) noexcept;

/**
 * @brief Returns whether the given device is an MT device.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device is of the MT variety. False otherwise.
 */
OTC_SDK_API bool isMTDevice(DeviceType type) noexcept;

/**
 * @brief Returns whether the given device will answer on all commands, also on commands with no answer needed (such as set commands).
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device answers on all commands. False otherwise.
 */
OTC_SDK_API bool isDeviceAnsweringAllCommands(DeviceType type) noexcept;

/**
 * @brief Returns whether the given device supports the autonomous mode.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device supports the autonomous mode. False otherwise.
 */
OTC_SDK_API bool isAutonomousDevice(DeviceType type) noexcept;

/**
 * @brief Returns whether the given device supports Ethernet.
 * 
 * @param[in] type imager device type to check.
 * 
 * @return true if the given device supports Ethernet. False otherwise.
 */
OTC_SDK_API bool isEthernetDevice(DeviceType type) noexcept;

/**
 * @brief Returns a string representation of the given device type.
 * 
 * @note Use `deviceTypeToString()` in Python instead.
 * 
 * @param[in] deviceType for which a string representation is desired.
 * 
 * @return string respresentation of the given device type.
 */
OTC_SDK_API std::string toString(DeviceType deviceType) noexcept;

/**
 * @brief Output stream operator for device types.
 * 
 * @param[in] out        stream to use.
 * @param[in] deviceType to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, DeviceType deviceType) noexcept;

} // namespace optris