// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   ThermalFrame.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating a thermal frame received from a device.
 * 
 * @date 2025-02-14
 */

#pragma once

#include "otcsdk/Api.h"
#include "otcsdk/common/Frame.h"
#include "otcsdk/common/TemperatureConverter.h"


namespace optris 
{

/// Encapsulates thermal frame data received from a device.
class ThermalFrame : public Frame
{
public:
  /// Constructor.
  OTC_SDK_API ThermalFrame() = default;

  /// Copy constructor.
  OTC_SDK_API ThermalFrame(const ThermalFrame&) = default;
  /// Copy assignment.
  OTC_SDK_API ThermalFrame& operator=(const ThermalFrame&) = default;

  /// Move constructor.
  OTC_SDK_API ThermalFrame(ThermalFrame&&) = default;
  /// Move assignment.
  OTC_SDK_API ThermalFrame& operator=(ThermalFrame&&) = default;

  /// Destructor.
  OTC_SDK_API ~ThermalFrame() override = default;


  /**
   * @brief Returns the temperature in in °C at the given index.
   * 
   * @param[in] index of the desired frame temperature.
   * 
   * @return temperature in in °C at the given index.
   * 
   * @throw SDKException if index is out of range.
   */
  float getTemperature(int index) const;

  /**
   * @brief Returns the temperature in in °C at the given coordinates.
   * 
   * @param[in] x coordinate.
   * @param[in] y coordinate.
   * 
   * @return temperature in in °C at the given coordinate.
   * 
   * @throw SDKException if the coordinates are out of range.
   */
  float getTemperature(int x, int y) const;

  /**
   * @brief Returns the precision of the temperatures stored in the frame.
   * 
   * @return precision of the temperatures stored in the frame.
   */
  TemperaturePrecision getTemperaturePrecision() const noexcept;


  /**
   * @brief Copies the thermal data as degree Celsius to a one-dimensional array or vector.
   * 
   * @warning Make sure the destination has at least the size returned by getSize().
   * 
   * @param[out] destination to copy the internal data to.
   * @param[in]  size        as element count. The specified size is limited to [0, getSize()].
   */
  OTC_SDK_API void copyTemperaturesTo(float* destination, int size) const noexcept;

  /**
   * @brief Sets the thermal frame data values.
   * 
   * The provided data may be modified based on the given temperature precision.
   *
   * @param[in] source    to set the thermal frame data values from.
   * @param[in] precision of the temperature values.
   */
  OTC_SDK_API void setData(const unsigned short* source, TemperaturePrecision precision);

  /**
   * @brief Sets the thermal frame values from raw data.
   *
   * The data from the source is directly copied to the internal memory and is not modified based
   * on the provided temperature precision.
   * 
   * @param[in] source    to set the thermal frame data from.
   * @param[in] precision of the thermal values.
   */
  OTC_SDK_API void setFromRawData(const void* source, TemperaturePrecision precision);

  /**
   * @brief Returns the temperature converter.
   *
   * It can be used to convert and validate the thermal frame values to and from temperatures in °C.
   * 
   * @return temperature converter.
   */
  TemperatureConverter getConverter() const noexcept;

  /**
   * @brief Returns a complete copy of this frame.
   * 
   * @return a complete copy of this frame.
   */
  ThermalFrame clone() const noexcept;

  
private:
  TemperatureConverter _converter;
};


// Inline implementations
inline float ThermalFrame::getTemperature(int index) const noexcept(false)
{
  return _converter.toTemperature(getValue(index));
}

inline float ThermalFrame::getTemperature(int x, int y) const noexcept(false)
{
  return _converter.toTemperature(getValue(x, y));
}

inline TemperaturePrecision ThermalFrame::getTemperaturePrecision() const noexcept
{
  return _converter.getPrecision();
}

inline TemperatureConverter ThermalFrame::getConverter() const noexcept
{
  return _converter;
}

inline ThermalFrame ThermalFrame::clone() const noexcept
{
  return ThermalFrame{*this};
}

} // namespace optris