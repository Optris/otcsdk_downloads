// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   FrameMetadata.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the metadata associated with each frame.
 * 
 * @date 2025-01-02
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/FlagState.h"
#include "otcsdk/common/RadiationParameters.h"


namespace optris 
{
// Forward declaration
struct FrameMetadata2;


/**
 * @brief Encapsulates the metadata of frames provided by the devices.
 * 
 * This metadata is passed alongside the frame data from the devices via the streaming interface (e.g. USB, Ethernet).
 */
class FrameMetadata
{
public:
  /// Constructor.
  OTC_SDK_API FrameMetadata() noexcept;

  
  /**
   * @brief Creates a frame metadata object from raw metadata.
   * 
   * @param[in] raw                        metadata to convert.
   * @param[in] initializing               true if the device is currently performing the startup calibrations. False otherwise.
   * @param[in] pifActualDeviceCount       count of actually connected PIF devices.
   * @param[in] pifConfigurableDeviceCount count of configurable PIF devices.
   * 
   * @return frame metadata object.
   */
  static FrameMetadata fromRawMetadata(FrameMetadata2* raw, 
                                       bool            initializing, 
                                       int             pifActualDeviceCount,
                                       int             pifConfigurableDeviceCount);


  /**
   * @brief Returns the size of the raw metadata structure in bytes.
   * 
   * @return size of the raw metadata structure in bytes.
   */
  int getSize() const noexcept;

  /**
   * @brief Sets the size of the raw metadata structure in bytes.
   * 
   * @param[in] size of the raw metadata structure in bytes.
   */
  void setSize(int size) noexcept;


  /**
   * @brief Returns whether the data provided in the associated frame is reliable.
   * 
   * During the initial startup calibration the data provide by the device is not reliable.
   * 
   * @return true if the data provided in the associated frame is reliable. False otherwise.
   */
  bool isFrameDataReliable() const noexcept;


  /**
   * @brief Returns a consecutive number for each received frame.
   * 
   * @return consecutive number for each received frame.
   */
  unsigned int getCounter() const noexcept;

  /**
   * @brief Returns the frame number received from the device.
   * 
   * @note This counter may overflow.
   * 
   * @return frame number received form the device.
   */
  unsigned int getCounterHardware() const noexcept;

  /**
   * @brief Sets the frame counters.
   * 
   * @param[in] counter         to set.
   * @param[in] counterHardware to set.
   */
  void setCounters(unsigned int counter, unsigned int counterHardware) noexcept;


  /**
   * @brief Returns the frame timestamp in UNITS (10000000 units per second).
   * 
   * @return frame timestamp in UNITS (10000000 units per second).
   */
  long long getTimestamp() const noexcept;

  /**
   * @brief Returns the media timestamp.
   * 
   * @return media time stamp.
   */
  long long getTimestampMedia() const noexcept;

  /**
   * @brief Sets the timestamps.
   * 
   * @param[in] timestamp      frame timestamp in UNITS (10000000 units per second).
   * @param[in] timestampMedia media timestamp.
   */
  void setTimestamps(long long timestamp, long long timestampMedia) noexcept;


  /**
   * @brief Returns the state of the shutter flag at frame capturing time.
   * 
   * @return state of the shutter flag at frame capturing time.
   */
  FlagState getFlagState() const noexcept;

  /**
   * @brief Sets the state of the shutter flag.
   * 
   * @param[in] flagState to set.
   */
  void setFlagState(FlagState flagState) noexcept;


  /**
   * @brief Returns the shutter flag temperature in °C at frame capturing time.
   * 
   * @return shutter flag temperature in °C at frame capturing time.
   */
  float getTemperatureFlag() const noexcept;

  /**
   * @brief Returns the housing temperature in °C at frame capturing time.
   * 
   * @return housing temperature in °C at frame capturing time.
   */
  float getTemperatureBox() const noexcept;

  /**
   * @brief Returns the sensor chip temperature in °C at frame capturing time.
   * 
   * @return sensor chip temperature in °C at frame capturing time.
   */
  float getTemperatureChip() const noexcept;

  /**
   * @brief Set the flag, box and chip probe temperatures in °C.
   * 
   * @param[in] flag temperature in °C.
   * @param[in] box  temperature in °C.
   * @param[in] chip temperature in °C. 
   */
  void setProbeTemperatures(float flag, float box, float chip) noexcept;

  /**
   * @brief Returns the source of the emissivity value.
   * 
   * @return source of the emissivity value.
   */
  RadiationParameterSource getEmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the transmissivity value.
   * 
   * @return source of the transmissivity value. 
   */
  RadiationParameterSource getTransmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the ambient temperature value.
   * 
   * @return source of the ambient temperature value.
   */
  RadiationParameterSource getAmbientTemperatureSource() const noexcept;

  /**
   * @brief Grants read access to the radiation parameters use to process the thermal frame.
   *
   * @attention The radiation parameters may be modified via the process interface (PIF) and through automated
   *            ambient temperature estimations. This method return the parameters set in the configuration
   *            or vis IRImager::setRadiationParameters().
   *
   *            To get the set/configured parameters see IRImager::getRadiationParameters().
   *
   * @return read access to the radiation parameters use to process the thermal frame.
   */
  RadiationParameters getRadiationParameters() const noexcept;

  /**
   * @brief Sets the radiation parameters sources.
   * 
   * @param[in] emissivitySource         to set. 
   * @param[in] ambientTemperatureSource to set.
   */
  void setRadiationParameterSources(RadiationParameterSource emissivitySource,
                                    RadiationParameterSource ambientTemperatureSource) noexcept;

  /**
   * @brief Returns the analog input value on the given PIF channel.
   *
   * @warning The input values returned from channels on PIF devices that are just configurable but not
   *          actually connected to the camera (actualDeviceCount <= deviceIndex < configurableDeviceCount) 
   *          are invalid!
   * 
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * 
   * @return analog input value on the given PIF channel.
   * 
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API float getPifAiValue(int deviceIndex, int pinIndex) const;

  /**
   * @brief Returns the digital input value on the given PIF channel.
   * 
   * @warning The input values returned from channels on PIF devices that are just configurable but not
   *          actually connected to the camera (actualDeviceCount <= deviceIndex < configurableDeviceCount) 
   *          are invalid!
   *
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * 
   * @return digital input value on the given PIF channel.
   * 
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API bool getPifDiValue(int deviceIndex, int pinIndex) const;

  /**
   * @brief Returns the count of actually connected PIF devices.
   * 
   * @return count of actually connected PIF devices.
   */
  int getPifActualDeviceCount() const noexcept;

  /**
   * @brief Returns the count of configurable PIF devices.
   * 
   * @return count of configurable PIF devices.
   */
  int getPifConfigurableDeviceCount() const noexcept;

  /**
   * @brief Returns the count of analog input channels per PIF device.
   * 
   * @return count of analog input channels per PIF device.
   */
  int getPifAiCountPerDevice() const noexcept;

  /**
   * @brief Returns the count of digital input channels per PIF device.
   * 
   * @return count of digital input channels per PIF device.
   */
  int getPifDiCountPerDevice() const noexcept;

  /**
   * @brief Sets the counts of the PIF devices and input channels.
   * 
   * @param[in] actualDeviceCount       count of actual connected PIF devices.
   * @param[in] configurableDeviceCount count of configurable PIF devices.
   * @param[in] aiCountPerDevice        count of analog input channels per PIF device. 
   * @param[in] diCountPerDevice        count of digital input channels per PIF device.
   */
  OTC_SDK_API void setPifCounts(int actualDeviceCount,
                                int configurableDeviceCount, 
                                int aiCountPerDevice, 
                                int diCountPerDevice) noexcept;

  /**
   * @brief Sets the value of the specified PIF analog input channel.
   * 
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * @param[in] value       to set.
   *
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API void setPifAiValue(int deviceIndex, int pinIndex, float value);

  /**
   * @brief Sets the value of the specified PIF digital input channel.
   * 
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * @param[in] value       to set.
   *
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API void setPifDiValue(int deviceIndex, int pinIndex, bool value);


  /**
   * @brief Returns a complete copy of this metadata.
   * 
   * @return a complete copy of this metadata.
   */
  OTC_SDK_API FrameMetadata clone() const noexcept;


private:
  /// Size of this structure.
  unsigned short _size;
  
  /// Consecutively numbered for each received frame.
  unsigned int _counter;
  /// Hardware counter received from device, multiply with value returned by IRImager::getAvgTimePerFrame() to get a hardware timestamp.
  unsigned int _counterHardware;

  /// Time stamp in UNITS (10000000 units per second). 
  long long _timestamp;
  /// Time stamp media.
  long long _timestampMedia;

  /// State of shutter flag at capturing time.
  FlagState _flagState;

  /// Shutter flag temperature.
  float _temperatureFlag;
  /// Temperature inside camera housing.
  float _temperatureBox;
  /// Chip temperature.
  float _temperatureChip;

  /// Radiation parameter that were used to process the frame.
  RadiationParameters _radiation;
  /// Source of the emissivity value.
  RadiationParameterSource _emissivitySource;
  /// Source of the ambient temperature value.
  RadiationParameterSource _ambientTemperatureSource;

  /// Count of actually connected PIF devices.
  int _pifActualDeviceCount;
  /// Count of configurable PIF devices.
  int _pifConfigurableDeviceCount;

  /// Count of PIF analog input channel per device.
  int _pifAiCountPerDevice;
  /// List of the current input values of the PIF analog input channels.
  std::vector<float> _pifAiValues;

  /// Count of PIF digital input channels per device.
  int _pifDiCountPerDevice;
  /// List of the current input values of the PIF digital input channels.
  std::vector<bool> _pifDiValues;
};


// Inline implementations
inline int FrameMetadata::getSize() const noexcept
{
  return _size;
}

inline void FrameMetadata::setSize(int size) noexcept
{
  _size = size;
}

inline bool FrameMetadata::isFrameDataReliable() const noexcept
{
  return (_flagState != FlagState::Initializing);
}

inline unsigned int FrameMetadata::getCounter() const noexcept
{
  return _counter;
}

inline unsigned int FrameMetadata::getCounterHardware() const noexcept
{
  return _counterHardware;
}

inline void FrameMetadata::setCounters(unsigned int counter, unsigned int counterHardware) noexcept
{
  _counter         = counter;
  _counterHardware = counterHardware;
}

inline long long FrameMetadata::getTimestamp() const noexcept
{
  return _timestamp;
}

inline long long FrameMetadata::getTimestampMedia() const noexcept
{
  return _timestampMedia;
}

inline void FrameMetadata::setTimestamps(long long timestamp, long long timestampMedia) noexcept
{
  _timestamp      = timestamp;
  _timestampMedia = timestampMedia;
}

inline FlagState FrameMetadata::getFlagState() const noexcept
{
  return _flagState;
}

inline void FrameMetadata::setFlagState(FlagState flagState) noexcept
{
  _flagState = flagState;
}

inline float FrameMetadata::getTemperatureFlag() const noexcept
{
  return _temperatureFlag;
}

inline float FrameMetadata::getTemperatureBox() const noexcept
{
  return _temperatureBox;
}

inline float FrameMetadata::getTemperatureChip() const noexcept
{
  return _temperatureChip;
}

inline void FrameMetadata::setProbeTemperatures(float flag, float box, float chip) noexcept
{
  _temperatureFlag = flag;
  _temperatureBox  = box;
  _temperatureChip = chip;
}

inline RadiationParameters FrameMetadata::getRadiationParameters() const noexcept
{
  return _radiation;
}

inline RadiationParameterSource FrameMetadata::getEmissivitySource() const noexcept
{
  return _emissivitySource;
}

inline RadiationParameterSource FrameMetadata::getTransmissivitySource() const noexcept
{
  return RadiationParameterSource::Sdk;
}

inline RadiationParameterSource FrameMetadata::getAmbientTemperatureSource() const noexcept
{
  return _ambientTemperatureSource;
}

inline void FrameMetadata::setRadiationParameterSources(RadiationParameterSource emissivitySource,
                                                        RadiationParameterSource ambientTemperatureSource) noexcept
{
  _emissivitySource         = emissivitySource;
  _ambientTemperatureSource = ambientTemperatureSource;
}                                                

inline int FrameMetadata::getPifActualDeviceCount() const noexcept
{
  return _pifActualDeviceCount;
}

inline int FrameMetadata::getPifConfigurableDeviceCount() const noexcept
{
  return _pifConfigurableDeviceCount;
}

inline int FrameMetadata::getPifAiCountPerDevice() const noexcept
{
  return _pifAiCountPerDevice;
}

inline int FrameMetadata::getPifDiCountPerDevice() const noexcept
{
  return _pifDiCountPerDevice;
}

inline FrameMetadata FrameMetadata::clone() const noexcept
{
  return FrameMetadata{*this};
}

} // namespace optris