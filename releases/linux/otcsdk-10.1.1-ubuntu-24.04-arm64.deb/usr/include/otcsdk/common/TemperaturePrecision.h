// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   TemperaturePrecision.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an enum representing the different temperature precisions and constants denoting
 *         invalid temperatures.
 * 
 * @date 2025-02-17
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"


namespace optris
{

/// All temperatures in °C equal or lower are invalid.
static constexpr float INVALID_TEMPERATURE = -100.F;

/// All internal temperature values equal to this are invalid.
static constexpr unsigned short INVALID_VALUE = 0;


/// Represents the available temperature precisions.
enum class TemperaturePrecision
{
  Unknown  = 0,  ///< Unknown precision.
  Standard = 1,  ///< Standard precision.
  High     = 2,  ///< High precision.
};

/**
 * @brief Returns a string representation of the given temperature precision.
 * 
 * @note Use `temperaturePrecisionToString()` in Python instead.
 * 
 * @param[in] precision for which a string representation is desired.
 * 
 * @return string respresentation of the given temperature precision.
 */
OTC_SDK_API std::string toString(TemperaturePrecision precision) noexcept;

/**
 * @brief Ouput stream operator for temperature precisions.
 * 
 * @param[in] out       stream to ouput to.
 * @param[in] precision to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, TemperaturePrecision precision) noexcept;

} // namespace optris