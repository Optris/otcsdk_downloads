// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   OperationMode.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface definition for classes specifying valid sets of configuration 
 *         settings.
 * 
 * @date 2025-04-14
 */

#pragma once

#include <string>


namespace optris
{

/**
 * @brief Defines the interface for classes realizing operation modes.
 * 
 * Each operation mode encapsulates a valid combination of the following configuration settings:
 * 
 *  - Optics
 *  - Temperature range
 *  - Output video format
 * 
 * The available operation modes depend on the device, its optics, its calibrations, the video format
 * definitions and the type of connection to the device (USB, Ethernet).
 */
class OperationMode
{
public:
  /// Constructor.
  OperationMode() = default;

  /// No copy constructor. 
  OperationMode(const OperationMode&) = delete;
  /// No copy assignment. 
  OperationMode& operator=(const OperationMode&) = delete;

  /// No move constructor. 
  OperationMode(OperationMode&&) = delete;
  /// No move assignment. 
  OperationMode& operator=(OperationMode&&) = delete;

  /// Destructor.
  virtual ~OperationMode() = default;


  // General
  /**
   * @brief Returns the index of the mode.
   *
   * Convenience method to easily locate the mode within the container returned by IRImager::getOperationModes().
   *
   * @return index of the mode.
   *
   * @see IRImager::getOperationModes()
   */
  virtual int getIndex() const noexcept = 0;


  // Optics
  /**
   * @brief Returns the field of view in degrees of the optics.
   * 
   * @return field of view in degrees of the optics.
   */
  virtual int getFieldOfView() const noexcept = 0;

  /**
   * @brief Returns an optional string that further specifies the optics.
   * 
   * @return optional string that further specifies the optics.
   */
  virtual std::string getOpticsText() const noexcept = 0;

  /**
   * @brief Returns the serial number of the optics.
   * 
   * @return serial number of the optics.
   */
  virtual int getOpticsSerialNumber() const noexcept = 0;


  // Temperature range
  /**
   * @brief Returns the lower limit temperature in °C.
   * 
   * @note The returned temperature may vary depended on whether the temperature range is extended.
   * 
   * @return lower limit temperature in °C.
   * 
   * @see OperationMode::isTemperatureRangeExtended()
   */
  virtual float getTemperatureLowerLimit() const noexcept = 0;

  /**
   * @brief Returns the upper limit temperature in °C.
   * 
   * @note The returned temperature may vary depended on whether the temperature range is extended.
   * 
   * @return upper limit temperature in °C.
   * 
   * @see OperationMode::isTemperatureRangeExtended()
   */
  virtual float getTemperatureUpperLimit() const noexcept = 0;

  /**
   * @brief Returns the lower non-extended limit temperature in °C.
   * 
   * @return lower non-extended limit temperature in °C.
   */
  virtual float getTemperatureNormalLowerLimit() const noexcept = 0; 

  /**
   * @brief Returns the upper non-extended limit temperature in °C.
   * 
   * @return upper non-extended limit temperature in °C.
   */
  virtual float getTemperatureNormalUpperLimit() const noexcept = 0;

  /**
   * @brief Returns the lower extended limit temperature in °C.
   * 
   * The extended limit will equal the non-extended one, if the temperature range is not extendable.
   * 
   * @return lower extended limit temperature in °C.
   */
  virtual float getTemperatureExtendedLowerLimit() const noexcept = 0;

  /**
   * @brief Returns the upper extended limit temperature in °C.
   * 
   * The extended limit will equal the non-extended one, if the temperature range is not extendable.
   * 
   * @return upper extended limit temperature in °C.
   */
  virtual float getTemperatureExtendedUpperLimit() const noexcept = 0;

  /**
   * @brief Returns whether the temperature range is currently extended.
   * 
   * The return value depends on whether the temperature range can actually be extended and whether temperature
   * range extension is enabled.
   * 
   * @return true, if the temperature range is currently extended. False, otherwise.
   * 
   * @see OperationMode::isTemperatureRangeExtendable(),
   *      IRImager::isTemperatureRangeExtensionEnabled()
   */
  virtual bool isTemperatureRangeExtended() const noexcept = 0;

  /**
   * @brief Returns whether the temperature range can be extended.
   * 
   * @note Not all temperature ranges can be extended.
   * 
   * @return true, if the temperature range can be extended. False, otherwise.
   */
  virtual bool isTemperatureRangeExtendable() const noexcept = 0;

  /**
   * @brief Returns whether the temperatures were measured with high precision.
   * 
   * The return value depends on whether the temperature range actually feature high precision measurements
   * and whether high precision is enabled.
   * 
   * @return true if the temperatures were measured with high precision. False if the standard precision was
   *         used.
   * 
   * @see OperationMode::isTemperatureHighPrecisionAvailable(),
   *      IRImager::isTemperatureHighPrecisionEnabled()
   */
  virtual bool isTemperatureHighPrecision() const noexcept = 0;

  /**
   * @brief Returns whether measurements with high precision are available for the temperature range.
   * 
   * @note Not all temperature ranges on all devices feature high precision temperature measurements.
   * 
   * @return true, if measurements with high precision are available for the temperature range. False,
   *         otherwise.
   */
  virtual bool isTemperatureHighPrecisionAvailable() const noexcept = 0;


  // Video format
  /**
   * @brief Returns the width of the frame in pixels.
   * 
   * @return width of the frame in pixels.
   */
  virtual int getFrameWidth() const noexcept = 0;

  /**
   * @brief Returns the height of the frame in pixels.
   * 
   * @return height of the frame in pixels.
   */
  virtual int getFrameHeight() const noexcept = 0;

  /**
   * @brief Returns the framerate in Hz (not sub-sampled).
   * 
   * @return framerate in Hz (not sub-sampled).
   */
  virtual int getFramerate() const noexcept = 0;
  
  
  /**
   * @brief Returns a string representation of the operation mode.
   * 
   * @return string representation of the operation mode.
   */
  virtual std::string toString() const noexcept = 0;
};

} // namespace optris