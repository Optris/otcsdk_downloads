// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   RadiationParameters.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the individual radiation parameters.
 * 
 * @date 2025-07-22
 *
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"


namespace optris
{

/// Represents the different sources of radiation parameters.
enum class RadiationParameterSource
{
  Sdk, ///< The radiation parameter are/can be set via the SDK.
  Pif, ///< The radiation parameter is set by the processing interface (PIF).
};


/// Holds the radiation parameters for a frame or a measurement field.
class RadiationParameters
{
public:
  /// Constructor.
  OTC_SDK_API RadiationParameters() noexcept;

  /// Validates and rectifies the radiation parameters.
  OTC_SDK_API void validate();

  /**
   * @brief Returns a string representation of the radiation parameters. 
   * 
   * @return string representation of the radiation parameters. 
   */
  OTC_SDK_API std::string toString() const noexcept;


  /**
   * @brief Emissivity.
   * 
   * Its value will be limited to [0.1, 1.1].
   */
  float emissivity;

  /**
   * @brief Transmissivity.
   * 
   * Its value will be limited to [0.1, 1.1].
   */
  float transmissivity;

  /**
   * @brief Ambient temperature in °C.
   * 
   * For an automated estimation of this temperature see estimateAmbientTemperature.
   *
   * @see estimateAmbientTemperature
   */
  float ambientTemperature;

  /**
   * @brief Estimate the ambient temperature.
   *
   * @attention This flag will have no effect if a source other than the SDK is used to determine the
   *            ambient temperature value (for example a process interface).
   *
   * If set to true
   * - the ambient temperature will be estimated from internal temperature probe readings
   * - the ambient temperature estimate will be updated, if the probe readings change significantly.
   * - the value of ambientTemperature will be ignored. 
   *
   * If set to false
   * - the value of ambientTemperature will be applied.
   * - the value of ambientTemperature will not be updated.
   */
  bool estimateAmbientTemperature;
};


// Utility functions
/**
 * @brief Returns a string representation of the given radiation parameter source.
 * 
 * @note Use `radiationParameterSourceToString()` in Python instead.
 * 
 * @param[in] source for which a string representation is desired.
 * 
 * @return string representation of the given radiation parameter source.
 */
OTC_SDK_API std::string toString(RadiationParameterSource source) noexcept;

/**
 * @brief Ouput stream operator for radiation parameters.
 * 
 * @param[in] out       stream to ouput to.
 * @param[in] radiation parameters to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const RadiationParameters& radiation) noexcept;

/**
 * @brief Ouput stream operator for radiation parameter sources.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] source to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, RadiationParameterSource source) noexcept;

} // namespace optris