// Copyright (c) 2008-2025 Optris GmbH & Co. KG

/**
 * @file   IRImagerFactory.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a factory that instantiates IRImager implementations.
 * 
 * @date 2024-06-11
 */

#pragma once

#include <memory>
#include <string>
#include <unordered_map>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/IRImagerCreator.h"


namespace optris
{

/**
 * @brief Factory instantiating IRImager implementations.
 * 
 * The factory is implemented based on the Singleton design pattern. As a consequence, you have to use
 * the IRImagerFactory::getInstance() method to interact with it.
 */
class IRImagerFactory
{
public:
  /**
   * @brief Returns an instance of the IRImagerFactory.
   * 
   * Only one instance per program is available.
   * 
   * @return IRImagerFactory instance.
   */
  OTC_SDK_API static IRImagerFactory& getInstance();

  /**
   * @brief Creates an instance of an IRImager implementation.
   * 
   * @param[in] name of the implementation to instantiate. The SDK supports the following options:
   *                 - `native` - IRImager implementation that supports native USB and Ethernet access to Optris Imagers. 
   *                 (case insensitive)
   * 
   * @return shared pointer to created IRImager instance.
   * 
   * @throw SDKException if the instantiation fails or an implementation with the given name is not
   *                     available.
   */
  OTC_SDK_API std::shared_ptr<IRImager> create(const std::string& name) noexcept(false);


  /**
   * @brief Registers an creator for an IRImager implementation with the given name.
   *
   * Existing creators with the same name will be overriden.
   *
   * @param[in] name    of the IRImager implementation.
   * @param[in] creator instantiating the IRImager implementation.
   */
  OTC_SDK_API void registerCreator(const std::string& name, std::shared_ptr<IRImagerCreator> creator);


private:
  /// Constructor.
  IRImagerFactory() noexcept;


  /// Stores the different creators associated with the names of the instances they create.
  std::unordered_map<std::string, std::shared_ptr<IRImagerCreator>> _creators;
};

} // namespace optris