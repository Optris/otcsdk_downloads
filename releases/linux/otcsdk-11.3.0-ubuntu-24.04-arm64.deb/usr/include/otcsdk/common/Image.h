// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Image.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that encapsulates false color images.
 * 
 * @date 2025-01-21
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/Pixel.h"
#include "otcsdk/common/ImageInfo.h"


namespace optris
{

/**
 * @brief Encapsulates false color images with 8-bit color depth.
 * 
 * The individual pixel values, like red, green or blue, are stored in a one-dimensional array. 
 * 
 * Depending on the width alignment additional bytes may be added at the end of each row to ensure 
 * that its size in bytes respects this alignment. The setter and getter functions as well as the 
 * iterators will skip this padding.
 * 
 * The origin of coordinates is located in the upper left corner with the x-axis pointing right and
 * the y-axis pointing down.
 */
class Image
{
public:
  /**
   * @brief Constructor.
   * 
   * @param[in] colorFormat    defines the sequence in which the pixel values are stored internally.
   * @param[in] widthAlignment defines the alignment of the row size in bytes. If, e.g., it is set to
   *                           four bytes, the row size will potentially be padded at the end so that
   *                           it is a multiple of four.
   */
  OTC_SDK_API Image(ColorFormat colorFormat, WidthAlignment widthAlignment) noexcept;


  /**
   * @brief Returns the pixel at the given index.
   * 
   * @param[in] index of the desired pixel.
   * 
   * @return the pixel at the given index.
   * 
   * @throw SDKException if the index is out of bounds.
   */
  OTC_SDK_API Pixel getPixel(int index) const;

  /**
   * @brief Returns the pixel at the given coordinates.
   * 
   * @param[in] x coordinate.
   * @param[in] y coordinate.
   * 
   * @return the pixel at the given coordinates.
   * 
   * @throw SDKException if the coordinates are out of bounds.
   */
  OTC_SDK_API Pixel getPixel(int x, int y) const;

  /**
   * @brief Sets the pixel at the given index.
   * 
   * @param[in] index of the pixel to set.
   * @param[in] pixel to set.
   * 
   * @throw SDKException if the index is out of bounds.
   */
  OTC_SDK_API void setPixel(int index, const Pixel& pixel);

  /**
   * @brief Sets the pixel at the given coordinates.
   * 
   * @param[in] x     coordinate.
   * @param[in] y     coordinate.
   * @param[in] pixel to set.
   * 
   * @throw SDKException if the coordinates are out of bounds.
   */
  OTC_SDK_API void setPixel(int x, int y, const Pixel& pixel);

  /**
   * @brief Returns the width of the image in pixels.
   * 
   * @return image width in pixels.
   */
  OTC_SDK_API int getWidth() const noexcept;

  /**
   * @brief Returns the stride of the image in bytes.
   * 
   * The stride is the image width in bytes including potential padding.
   * 
   * @return stride of the image in bytes.
   */
  OTC_SDK_API int getStride() const noexcept;

  /**
   * @brief Returns the height of the image in pixels.
   * 
   * @return image height in pixels.
   */
  OTC_SDK_API int getHeight() const noexcept;

  /**
   * @brief Returns the size of the image as total number of pixels.
   * 
   * @return size of the image as total number of pixels.
   */
  OTC_SDK_API int getSize() const noexcept;

  /**
   * @brief Returns the size of the internal storage in bytes.
   * 
   * This includes potential width padding.
   * 
   * @return size of the internal storage in bytes.
   */
  OTC_SDK_API int getSizeInBytes() const noexcept;

  /**
   * @brief Returns whether the image is empty.
   * 
   * @return true if the image is empty. False otherwise.
   */
  OTC_SDK_API bool isEmpty() const noexcept;

  /// Clears the image.
  OTC_SDK_API void clear();

  /**
   * @brief Resizes the image to the given dimensions.
   * 
   * @param[in] width  in pixels.
   * @param[in] height in pixels.
   */
  OTC_SDK_API void resize(int width, int height);

  /**
   * @brief Returns the color format.
   * 
   * @return color format.
   */
  OTC_SDK_API ColorFormat getColorFormat() const noexcept;

  /**
   * @brief Returns the width alignment.
   * 
   * @return width alignment.
   */
  OTC_SDK_API WidthAlignment getWidthAlignment() const noexcept;

  /**
   * @brief Copies the internally stored pixel values to the given array.
   * 
   * This includes potential width padding.
   * 
   * @warning No range checks are performed. The correct size of the destination array
   *          can be acquired with the getSizeInBytes() function.
   * 
   * @param[out] destination array to copy the data to.
   * @param[in]  size        in bytes. The specified size is limited to [0, frame size in bytes].
   * 
   * @see getSizeInBytes()
   */
  OTC_SDK_API void copyDataTo(unsigned char* destination, int size) const noexcept;

  /**
   * @brief Returns a pointer to the first element of the internal array.
   * 
   * The size of the array can be acquired via the getSizeInBytes() function.
   * 
   * @return pointer to the first element of the internal array.
   * 
   * @see getSizeInBytes()
   */
  OTC_SDK_API const unsigned char* getData() const noexcept;

  /**
   * @brief Returns a pointer to the first element of the internal array.
   *
   * The size of the array can be acquired via the getSizeInBytes() function.
   *
   * @return pointer to the first element of the internal array.
   *
   * @see getSizeInBytes()
   */
  OTC_SDK_API unsigned char* getData() noexcept;


private:
  ImageInfo _info;

  std::vector<unsigned char> _pixelValues;
};


// Inline implementations
inline int Image::getWidth() const noexcept
{
  return _info.getWidth();
}

inline int Image::getStride() const noexcept
{
  return _info.getStride();
}

inline int Image::getHeight() const noexcept
{
  return _info.getHeight();
}

inline int Image::getSize() const noexcept
{
  return _info.getSize();
}

inline int Image::getSizeInBytes() const noexcept
{
  return static_cast<unsigned int>(_pixelValues.size());
}

inline bool Image::isEmpty() const noexcept
{
  return _pixelValues.empty();
}

inline ColorFormat Image::getColorFormat() const noexcept
{
  return _info.getColorFormat();
}

inline WidthAlignment Image::getWidthAlignment() const noexcept
{
  return _info.getWidthAlignment();
}

inline const unsigned char* Image::getData() const noexcept
{
  return _pixelValues.data();
}

inline unsigned char* Image::getData() noexcept
{
  return _pixelValues.data();
}

} // namespace optris