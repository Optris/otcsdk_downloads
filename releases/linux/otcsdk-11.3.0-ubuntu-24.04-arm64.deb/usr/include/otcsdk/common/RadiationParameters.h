// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   RadiationParameters.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the individual radiation parameters.
 * 
 * @date 2025-07-22
 *
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/TemperaturePrecision.h"


namespace optris
{

/// Represents the different sources of radiation parameters.
enum class RadiationParameterSource
{
  Sdk, ///< The radiation parameter are/can be set via the SDK.
  Pif, ///< The radiation parameter is set by the processing interface (PIF).
};


/// Holds the radiation parameters for a frame or a measurement field.
struct RadiationParameters
{
  /**
   * @brief Emissivity.
   * 
   * Its value will be limited to [0.01, 1.1].
   */
  float emissivity = 1.F;

  /**
   * @brief Transmissivity.
   * 
   * Its value will be limited to [0.01, 1.1].
   */
  float transmissivity = 1.F;

  /**
   * @brief Ambient temperature in °C.
   * 
   * For an automated estimation of this temperature see estimateAmbientTemperature.
   *
   * @see estimateAmbientTemperature
   */
  float ambientTemperature = INVALID_TEMPERATURE;

  /**
   * @brief Estimate the ambient temperature.
   *
   * @attention This flag will have no effect if a source other than the SDK is used to determine the
   *            ambient temperature value (for example a process interface).
   *
   * If set to true
   * - the ambient temperature will be estimated from internal temperature probe readings
   * - the ambient temperature estimate will be updated, if the probe readings change significantly.
   * - the value of ambientTemperature will be ignored. 
   *
   * If set to false
   * - the value of ambientTemperature will be applied.
   * - the value of ambientTemperature will not be updated.
   */
  bool estimateAmbientTemperature = true;


  /**
   * @brief Validates the radiation parameters.
   *
   * Clamps emissivity and transmissivity values to [0.01, 1.1]. If ambientTemperature is less than
   * or equal to INVALID_TEMPERATURE, estimateAmbientTemperature will be set to true.
   *
   * @param[in, out] radiation parameters to validate.
   */
  OTC_SDK_API static void validate(RadiationParameters& radiation) noexcept;

  /**
   * @brief Validates emissivity and transmissivity parameter values.
   *
   * Clamps the parameter value to [0.01, 1.1].
   *
   * @param[in, out] parameter to validate.
   */
  OTC_SDK_API static void validate(float& parameter) noexcept;
};


// Utility functions
/**
 * @brief Checks if two radiation parameter sets are equal.
 * 
 * @param[in] lhs first radiation parameter set to compare.
 * @param[in] rhs second radiation parameter set to compare.
 *
 * @return true, if the radiation parameter sets are equal.False otherwise.
 */
bool operator==(const RadiationParameters& lhs, const RadiationParameters& rhs) noexcept;

/**
 * @brief Checks if two radiation parameter sets are unequal.
 * 
 * @param[in] lhs first radiation parameter set to compare.
 * @param[in] rhs second radiation parameter set to compare.
 *
 * @return true, if the radiation parameter sets are unequal.False otherwise.
 */
bool operator!=(const RadiationParameters& lhs, const RadiationParameters& rhs) noexcept;

/**
 * @brief Returns a string representation of the given radiation parameter source.
 * 
 * @note Use `radiationParameterSourceToString()` in Python instead.
 * 
 * @param[in] source for which a string representation is desired.
 * 
 * @return string representation of the given radiation parameter source.
 */
OTC_SDK_API std::string toString(RadiationParameterSource source) noexcept;

/**
 * @brief Ouput stream operator for radiation parameters.
 * 
 * @param[in] out       stream to ouput to.
 * @param[in] radiation parameters to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const RadiationParameters& radiation) noexcept;

/**
 * @brief Ouput stream operator for radiation parameter sources.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] source to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, RadiationParameterSource source) noexcept;

} // namespace optris