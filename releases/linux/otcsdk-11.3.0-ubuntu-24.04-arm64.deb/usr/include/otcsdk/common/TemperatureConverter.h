// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   TemperatureConverter.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that converts between temperatures in the internal SDK format and
 *         in °C.
 * 
 * @date 2025-02-14
 */

#pragma once

#include "otcsdk/Api.h"
#include "otcsdk/common/TemperaturePrecision.h"


namespace optris 
{

/// Converts temperatures in °C to and from their internal SDK representation.
class TemperatureConverter
{
public:
  /// Constructor.
  OTC_SDK_API TemperatureConverter() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] precision of the temperature.
   */
  OTC_SDK_API TemperatureConverter(TemperaturePrecision precision) noexcept;


  /**
   * @brief Set the temperature precision.
   * 
   * @param[in] precision to set.
   */
  OTC_SDK_API void setPrecision(TemperaturePrecision precision) noexcept;

  /**
   * @brief Returns the temperature precision.
   * 
   * @return temperature precision. 
   */
  TemperaturePrecision getPrecision() const noexcept;

  /**
   * @brief Converts an internal value to a temperature in °C.
   *
   * @param[in] value internal value to convert.
   *
   * @return temperature in °C.
   */
  float toTemperature(unsigned short value) const noexcept;

  /**
   * @brief Converts a sub-integer internal value to a temperature in °C.
   *
   * For callers that hold scaling-range state at sub-integer precision
   * (see ImageBuilder's hysteresis filter and the Sigma scaling modes).
   *
   * @param[in] value sub-integer internal value to convert.
   *
   * @return temperature in °C.
   */
  float toTemperature(float value) const noexcept;

  /**
   * @brief Converts a temperature in °C to an internal value.
   * 
   * @param[in] temperature in °C to convert.
   *
   * @return internal value.
   */
  unsigned short toValue(float temperature) const noexcept;

  /**
   * @brief Checks if the given temperature in °C is valid.
   * 
   * @param[in] temperature in °C to check.
   *
   * @return true if the temperature is valid. False otherwise.
   */
  bool isTemperatureValid(float temperature) noexcept;

  /**
   * @brief Checks if an internal value is valid.
   * 
   * @param[in] value to check.
   * 
   * @return true if the value is valid. False otherwise.
   */
  bool isValueValid(unsigned short value) noexcept;

  /**
   * @brief Returns the value signifying an invalid temperature.
   * 
   * @return value signifying an invalid temperature.
   */
  float getInvalidTemperature() const noexcept;

  /**
   * @brief Returns the value signifying an invalid internal value.
   * 
   * @return value signifying an invalid internal value.
   */
  unsigned short getInvalidValue() const noexcept;


private:
  TemperaturePrecision _precision;

  float _factor;
  float _offset;

  unsigned short _invalidValue;
};


// Inline implementations
inline TemperaturePrecision TemperatureConverter::getPrecision() const noexcept
{
  return _precision;
}

inline float TemperatureConverter::toTemperature(unsigned short value) const noexcept
{
  return (value == _invalidValue) ? INVALID_TEMPERATURE : static_cast<float>(value) / _factor + _offset;
}

inline float TemperatureConverter::toTemperature(float value) const noexcept
{
  // Compare against the float-widened invalid sentinel rather than
  // truncating to unsigned short, otherwise valid sub-integer values
  // in [0, 1) would be wrongly flagged as invalid.
  return (value == static_cast<float>(_invalidValue)) ? INVALID_TEMPERATURE : value / _factor + _offset;
}

inline unsigned short TemperatureConverter::toValue(float temperature) const noexcept
{
  return (temperature <= INVALID_TEMPERATURE) ? _invalidValue : static_cast<unsigned short>((temperature - _offset) * _factor);
}

inline bool TemperatureConverter::isTemperatureValid(float temperature) noexcept
{
  return temperature > INVALID_TEMPERATURE;
}

inline bool TemperatureConverter::isValueValid(unsigned short value) noexcept
{
  return value != _invalidValue;
}

inline float TemperatureConverter::getInvalidTemperature() const noexcept
{
  return INVALID_TEMPERATURE;
}

inline unsigned short TemperatureConverter::getInvalidValue() const noexcept
{
  return _invalidValue;
}

} // namespace optris