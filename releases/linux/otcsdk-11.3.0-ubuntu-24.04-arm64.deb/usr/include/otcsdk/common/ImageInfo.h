// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ImageInfo.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding detail information about the properties of a false color
 *         image.
 * 
 * @date 2025-01-21
 */

#pragma once

#include "otcsdk/Api.h"


namespace optris
{

/**
 * @brief Represents the different available color formats.
 * 
 * The format defines the storage __sequence__ of the pixel color values. Therefore, the color value of the first letter will come
 * first in the image pixel value array.
 * 
 * Some systems refer to the __significance__ of the color values as color format. Here the color value of the first letter is the most
 * significant byte. On big-endian machines this byte comes first. On little-endian machines it will come last.
 * 
 * @image html faulty_color_format.jpg "False color image with Iron color palette: Left correct color format, right wrong color format."
 */
enum class ColorFormat
{
  RGB,  ///< Pixel colors values are stored in the sequence: (red, green, blue).
  BGR,  ///< Pixel colors values are stored in the sequence: (blue, green, red).
};

/**
 * @brief Represents the different available width alignments.
 * 
 * Depending on the chosen alignment additional bytes will be added to the end of each row in an image so that its size in bytes adheres
 * to that alignment. This enables some frame works like OpenGL to read the image data in bigger chunks than one byte at a time which 
 * can result in significant performance benefits.
 * 
 * @image html faulty_width_alignment.jpg "Example false color image with faulty width alignment."
 */
enum class WidthAlignment
{
  OneByte    = 1,  ///< The row size is aligned to one byte.
  TwoBytes   = 2,  ///< The row size is aligned to two bytes.
  FourBytes  = 4,  ///< The row size is aligned to four bytes.
  EightBytes = 8,  ///< The row size is aligned to eight bytes.
};


/// Encapsulates all relevant information about a false color image.
class ImageInfo
{
public:
  /**
   * @brief Constructor.
   * 
   * @param[in] colorFormat    of the image.
   * @param[in] widthAlignment of the image.
   */
  OTC_SDK_API ImageInfo(ColorFormat colorFormat, WidthAlignment widthAlignment) noexcept;


  /**
   * @brief Returns the color format of the image.
   * 
   * @return color format of the image.
   */
  ColorFormat getColorFormat() const noexcept;

  /**
   * @brief Returns the number of color channels.
   * 
   * @return number of color channels.
   */
  int getChannels() const noexcept;

  /**
   * @brief Returns the offset of the red color byte.
   * 
   * @return offset of the red color byte.
   */
  int getOffsetRed() const noexcept;

  /**
   * @brief Returns the offset of the green color byte.
   * 
   * @return offset of the green color byte.
   */
  int getOffsetGreen() const noexcept;

  /**
   * @brief Returns the offset of the blue color byte.
   * 
   * @return offset of the blue color byte.
   */
  int getOffsetBlue() const noexcept;


  /**
   * @brief Resizes the image to the given dimension.
   * 
   * @return resulting image size in bytes.
   */
  OTC_SDK_API int resize(int width, int height);

  /**
   * @brief Returns the image width in pixels.
   * 
   * @return image width in pixels.
   */
  int getWidth() const noexcept;

  /**
   * @brief Returns the image stride in bytes.
   * 
   * The stride is the image width in bytes including potential padding.
   * 
   * @return image stride in bytes.
   */
  int getStride() const noexcept;

  /**
   * @brief Returns the image height in pixels.
   * 
   * @return image height in pixels.
   */
  int getHeight() const noexcept;

  /**
   * @brief Returns the image size in pixels.
   * 
   * @return image size in pixels.
   */
  int getSize() const noexcept;


  /**
   * @brief Returns the width alignment of the image.
   * 
   * @return width alignment of the image.
   */
  WidthAlignment getWidthAlignment() const noexcept;

  /**
   * @brief Returns width padding in bytes.
   * 
   * @return width padding in bytes.
   */
  int getWidthPaddingInBytes() const noexcept;


private:
  ColorFormat _colorFormat;

  int _channels;

  int _offsetRed;
  int _offsetBlue;

  int _width;
  int _stride;
  int _height;
  int _size;

  int _widthAlignment;
  int _widthPaddingInBytes;
};


// Inline implementations
inline ColorFormat ImageInfo::getColorFormat() const noexcept
{
  return _colorFormat;
}

inline int ImageInfo::getChannels() const noexcept
{
  return _channels;
}

inline int ImageInfo::getOffsetRed() const noexcept
{
  return _offsetRed;
}

inline int ImageInfo::getOffsetGreen() const noexcept
{
  return 1;
}

inline int ImageInfo::getOffsetBlue() const noexcept
{
  return _offsetBlue;
}

inline int ImageInfo::getWidth() const noexcept
{
  return _width;
}

inline int ImageInfo::getStride() const noexcept
{
  return _stride;
}

inline int ImageInfo::getHeight() const noexcept
{
  return _height;
}

inline int ImageInfo::getSize() const noexcept
{
    return _size;
}

inline WidthAlignment ImageInfo::getWidthAlignment() const noexcept
{
  return static_cast<WidthAlignment>(_widthAlignment);
}

inline int ImageInfo::getWidthPaddingInBytes() const noexcept
{
  return _widthPaddingInBytes;
}

} // namespace optris
