// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Version.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating version information.
 * 
 * @date 2025-12-15
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"


namespace optris 
{

/// Represent a version with major, minor and patch version numbers.
class Version
{
public:
  /// Constructor.
  OTC_SDK_API Version() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] major version number.
   * @param[in] minor version number.
   * @param[in] patch version number.
   */
  OTC_SDK_API Version(int major, int minor, int patch) noexcept;

  /**
   * @brief Returns the major version number.
   * 
   * @return major version number.
   */
  int getMajor() const noexcept;

  /**
   * @brief Returns the minor version number.
   * 
   * @return minor version number.
   */
  int getMinor() const noexcept;

  /**
   * @brief Returns the patch version number.
   * 
   * @return patch version number.
   */
  int getPatch() const noexcept;


  /**
   * @brief Returns a string representation of the version.
   * 
   * @return string representation of the version.
   */
  OTC_SDK_API std::string toString() const noexcept;


  /**
   * @brief Returns whether the stored version is valid.
   * 
   * The version is considered invalid, if all version numbers are zero.
   *
   * @return true, if the version is valid. False otherwise.
   */
  OTC_SDK_API bool isValid() const noexcept;

  /**
   * @brief Returns whether the stored version is valid.
   * 
   * The version is considered invalid, if all version numbers are zero.
   *
   * @return true, if ther version is valid. False otherwise.
   */
  OTC_SDK_API operator bool() const noexcept;


  /**
   * @brief Compares the provided version with the stored one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return 0  if both versions are equal.
   *         -1 if the stored version is less than the provided one.
   *         +1 if the stored version is greater than the provide one. 
   */
  OTC_SDK_API int compare(const Version& rhs) const noexcept;

  /**
   * @brief Compares the provided version numbers with the stored ones.
   * 
   * @param[in] major version number to compare with.
   * @param[in] minor version number to compare with.
   * @param[in] patch version number to compare with.
   *
   * @return 0  if both versions are equal.
   *         -1 if the stored version is less than the provided one.
   *         +1 if the stored version is greater than the provide one. 
   */
  OTC_SDK_API int compare(int major, int minor, int patch) const noexcept;


  /**
   * @brief Return whether the provided version equals the stored one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the versions are equal. False, otherwise.
   */
  bool operator==(const Version& rhs) const noexcept;

  /**
   * @brief Return whether the provided version is not equal to the stored one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the versions are not equal. False, otherwise.
   */
  bool operator!=(const Version& rhs) const noexcept;

  /**
   * @brief Return whether the stored version is lower than the provided one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the stored version is lower than the provided one. False otherwise.
   */
  bool operator<(const Version& rhs) const noexcept;

  /**
   * @brief Return whether the stored version is lower than or equal to the provided one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the stored version is lower than or equal to the provided one. False otherwise.
   */
  bool operator<=(const Version& rhs) const noexcept;

  /**
   * @brief Return whether the stored version is higher than to the provided one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the stored version is higher than the provided one. False otherwise.
   */
  bool operator>(const Version& rhs) const noexcept;

  /**
   * @brief Return whether the stored version is higher than or equal to the provided one.
   * 
   * @param[in] rhs version to compare with.
   *
   * @return true, if the stored version is higher than or equal to the provided one. False otherwise.
   */
  bool operator>=(const Version& rhs) const noexcept;


private:
  int _major;
  int _minor;
  int _patch;
};


// Inline implementations
inline int Version::getMajor() const noexcept
{
  return _major;
}

inline int Version::getMinor() const noexcept
{
  return _minor;
}

inline int Version::getPatch() const noexcept
{
  return _patch;
}

inline bool Version::operator==(const Version& rhs) const noexcept
{
  return compare(rhs) == 0;
}

inline bool Version::operator!=(const Version& rhs) const noexcept
{
  return compare(rhs) != 0;
}

inline bool Version::operator<(const Version& rhs) const noexcept
{
  return compare(rhs) < 0;
}

inline bool Version::operator<=(const Version& rhs) const noexcept
{
  return compare(rhs) <= 0;
}

inline bool Version::operator>(const Version& rhs) const noexcept
{
  return compare(rhs) > 0;
}

inline bool Version::operator>=(const Version& rhs) const noexcept
{
  return compare(rhs) >= 0;
}


// Utility functions
/**
 * @brief Ouput stream operator for Version objects.
 * 
 * @param[in] out     stream to ouput to.
 * @param[in] version to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const Version& version);

} // namespace optris