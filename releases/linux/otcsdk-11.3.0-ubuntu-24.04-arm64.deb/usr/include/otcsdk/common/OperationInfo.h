// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   OperationInfo.h
 * @author 2025 Optris GmbH Co. KG
 * @brief  Contains a class that holds debug and performance information about an operation module within the processing pipeline.
 * 
 * @date 2025-01-02
 * 
 */

#pragma once

#include <string>
#include <climits>

namespace optris 
{

/// Encapsulates information about an operation module within the processing pipeline.
class OperationInfo
{
public:
  /// Constructor.
  OperationInfo() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] index          unique index of the module.
   * @param[in] previousIndex  unique index of the module that precedes this module in the processing
   *                           pipeline. 
   * @param[in] name           of the module.
   * @param[in] processingTime average processing time in ms.
   * @param[in] pixelValue     processed internal thermal value of a given pixel.
   */
  OperationInfo(int         index, 
                int         previousIndex, 
                std::string name,
                float       processingTime,
                short       pixelValue) noexcept;

  /**
   * @brief Returns the unique index of the module.
   * 
   * @return unique index of the operation module or -1 if an index is not available.
   */
  int getIndex() const noexcept;

  /**
   * @brief Returns the unique index of the module that precedes this module in the processing pipeline.
   * 
   * @return unique index of the module that precedes this module in the processing pipeline or -1 if
   *         an index is not available.
   */
  int getPreviousIndex() const noexcept;

  /**
   * @brief Returns the name of the module.
   * 
   * @return name of the module or an empty string if a name is not available.
   */
  const std::string& getName() const noexcept;

  /**
   * @brief Returns the average processing time in ms of the module.
   * 
   * @return processing time in ms of the module.
   */
  float getProcessingTime() const noexcept;

  /**
   * @brief Returns the processed internal thermal value of a given pixel.
   * 
   * @return processed internal thermal value of a given pixel or minimal short value if no value is
   *         available.
   */
  short getPixelValue() const noexcept;


private:
  int _index;
  int _previousIndex;

  std::string _name;

  float _processingTime;

  short _pixelValue;
};


// Inline implementations
inline OperationInfo::OperationInfo() noexcept
  : _index{-1}
  , _previousIndex{-1}
  , _processingTime{0.0F}
  , _pixelValue{SHRT_MIN}
{}

inline OperationInfo::OperationInfo(int         index, 
                                    int         previousIndex, 
                                    std::string name,
                                    float       processingTime,
                                    short       pixelValue) noexcept
  : _index{index}
  , _previousIndex{previousIndex}
  , _name{std::move(name)}
  , _processingTime{processingTime}
  , _pixelValue{pixelValue}
{}

inline int OperationInfo::getIndex() const noexcept
{
  return _index;
}

inline int OperationInfo::getPreviousIndex() const noexcept
{
  return _previousIndex;
}

inline const std::string& OperationInfo::getName() const noexcept
{
  return _name;
}

inline float OperationInfo::getProcessingTime() const noexcept
{
  return _processingTime;
}

inline short OperationInfo::getPixelValue() const noexcept
{
  return _pixelValue;
}

} // namespace optris