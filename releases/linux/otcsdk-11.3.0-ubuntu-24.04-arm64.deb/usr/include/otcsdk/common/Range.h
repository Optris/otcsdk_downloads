// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Range.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class for generic ranges.
 * 
 * @date 2026-02-03
 */

#pragma once

#include <ostream>

#include "otcsdk/Exceptions.h"


namespace optris 
{

/**
 * @brief Generic range structure.
 * 
 * @tparam T type of the range components.
 */
template<typename T>
struct Range
{
  /// Type of the range components.
  using ComponentType = T;

  /// Minimum value of the range.
  T min;
  /// Maximum value of the range.
  T max;


  /**
   * @brief Validates the range.
   *
   * @param[in] range range to validate.
   *
   * @throws SDKException if the range minimum is greater than the maximum.
   */
  static void validate(const Range<T>& range);
};

/// Alias for a range with float components.
using RangeF = Range<float>;
/// Alias for a range with integer components.
using RangeI = Range<int>;


// Inline implementations
template<typename T>
inline void Range<T>::validate(const Range<T>& range)
{
  if (range.min > range.max)
  {
    throw SDKException{"Invalid range: minimum value is greater than maximum value."};
  }
}

// Utility functions
/**
 * @brief Checks if two ranges are equal.
 * 
 * @param[in] lhs first range to compare.
 * @param[in] rhs second range to compare.
 *
 * @return true, if the ranges are equal.False otherwise.
 */
template<typename T>
inline bool operator==(const Range<T>& lhs, const Range<T>& rhs) noexcept
{
  return lhs.min == rhs.min && lhs.max == rhs.max;
}

/**
 * @brief Checks if two ranges are unequal.
 * 
 * @param[in] lhs first range to compare.
 * @param[in] rhs second range to compare.
 *
 * @return true, if the ranges are unequal.False otherwise.
 */
template<typename T>
inline bool operator!=(const Range<T>& lhs, const Range<T>& rhs) noexcept
{
  return lhs.min != rhs.min || lhs.max != rhs.max;
}

/**
 * @brief Checks if a value is within a given range.
 * 
 * @param[in] value value to check.
 * @param[in] range range to check against.
 *
 * @return true, if the value is within the range. False otherwise.
 */
template<typename T>
inline bool isIn(const T& value, const Range<T>& range) noexcept
{
  return value >= range.min && value <= range.max;
}

/**
 * @brief Ouput stream operator for ranges.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] range  range to output.
 *
 * @return used output stream. 
 */
template<typename T>
std::ostream& operator<<(std::ostream& out, const Range<T>& range) noexcept
{
  return (out << "[" << range.min << ", " << range.max << "]");
}

} // namespace optris