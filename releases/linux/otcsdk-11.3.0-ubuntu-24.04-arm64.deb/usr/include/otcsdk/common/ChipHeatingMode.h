// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ChipHeatingMode.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an enum for the available chip heating modes.
 * 
 * @date 2025-02-17
 *
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"


namespace optris 
{

/// Represents the available chip heating modes.
enum class ChipHeatingMode
{
  Floating, ///< The sensor chip will not be heated.
  Auto,     ///< The sensor chip will be heated to the temperature specified in the calibrations.
  Fixed,    ///< The sensor chip will be heated to a configurable fixed temperature.
};


// Utility functions
/**
 * @brief Returns a string representation of the given chip heating mode.
 * 
 * @note Use `chipHeatingModeToString()` in Python instead.
 * 
 * @param[in] mode for which a string representation is desired.
 * 
 * @return string representation of the given chip heating mode.
 */
OTC_SDK_API std::string toString(ChipHeatingMode mode) noexcept;

/**
 * @brief Ouput stream operator for chip heating mode.
 * 
 * @param[in] out  stream to ouput to.
 * @param[in] mode to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, ChipHeatingMode mode) noexcept;

} // namespace optris