// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ConnectionState.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an enum representing the current state of the connection.
 * 
 * @date 2026-04-14
 *
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"


namespace optris 
{

/// Represents the current connection state.
enum class ConnectionState
{
  Disconnecting,            /// The device connection is being closed.
  Disconnected,             /// The device connection is closed.
  Connecting,               /// The device connection is being established.
  CaliAccessInternet,       /// The Sdk is asking for permission to access the internet to download missing calibration files.
  CaliInternetDownload,     /// The Sdk is trying to download missing calibration files from the internet.
  CaliDeviceDownload,       /// The Sdk is trying to download missing calibration files from the device.
  CaliCopy,                 /// The Sdk is trying to copy missing calibration files from the filesystem.
  CaliCopySourceDirectory,  /// The directory specified via Sdk::setCalibrationFileSourceDirectory() did not contain everything. Provide another source directory.
  CaliAcquired,             /// All missing calibration files have been successfully acquired.
  CaliMissing,              /// Missing calibration files could not be acquired. Thermal data will be invalid.
  Failed,                   /// The connection attempt failed.
  Connected,                /// The device connection is established.
  Lost,                     /// The device connection is lost.
  Timeout                   /// The device connection timed out, e.g. due to a network issue.
};

// Utility functions
/**
 * @brief Returns a string representation of the given connection state.
 * 
 * @note Use `connectionStateToString()` in Python instead.
 * 
 * @param[in] state for which a string representation is desired.
 * 
 * @return string representation of the given connection state.
 */
OTC_SDK_API std::string toString(ConnectionState state) noexcept;

/**
 * @brief Ouput stream operator for connection state.
 * 
 * @param[in] out   stream to ouput to.
 * @param[in] state to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, ConnectionState state) noexcept;

} // namespace optris