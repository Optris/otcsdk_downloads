// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Pixel.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating a pixel with three color channels and 8 bits of color depth.
 * 
 * @date 2025-01-21
 */

#pragma once

#include <string>
#include <ostream>


namespace optris
{

/// Represents a pixel with three color channels and 8 bits of color depth.
class Pixel
{
public:
  /// Constructor.
  Pixel() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] red   color value in [0, 255].
   * @param[in] green color value in [0, 255].
   * @param[in] blue  color value in [0, 255].
   */
  Pixel(unsigned char red, unsigned char green, unsigned char blue) noexcept;


  /**
   * @brief Returns the red color value.
   * 
   * @return red color value in [0, 255].
   */
   unsigned char getRed() const noexcept;

  /**
   * @brief Returns the green color value.
   * 
   * @return green color value in [0, 255].
   */
   unsigned char getGreen() const noexcept;

  /**
   * @brief Returns the blue color value.
   * 
   * @return blue color value in [0, 255].
   */
   unsigned char getBlue() const noexcept;


  /// Equal operator.
  bool operator==(const Pixel& rhs) const noexcept;
  /// Unequal operator.
  bool operator!=(const Pixel& rhs) const noexcept;


  /**
   * @brief Returns a string representation of the pixel (red, green, blue).
   * 
   * @return string representation of the pixel.
   */
  std::string toString() const noexcept;


private:
  unsigned char _red;
  unsigned char _green;
  unsigned char _blue;
};


// Utility functions
/**
 * @brief Output stream operator for pixels.
 * 
 * @param[in] out   stream to output to.
 * @param[in] pixel to output.
 * 
 * @return used output operator.
 */
std::ostream& operator<<(std::ostream& out, const Pixel& pixel) noexcept;


// Inline implementations
inline Pixel::Pixel() noexcept
  : _red{0U}
  , _green{0U}
  , _blue{0U}
{ }

inline Pixel::Pixel(unsigned char red, unsigned char green, unsigned char blue) noexcept
  : _red{red}
  , _green{green}
  , _blue{blue}
{ }

inline unsigned char Pixel::getRed() const noexcept
{
  return _red;
}

inline unsigned char Pixel::getGreen() const noexcept
{
  return _green;
}

inline unsigned char Pixel::getBlue() const noexcept
{ 
  return _blue;
}

inline bool Pixel::operator==(const Pixel& rhs) const noexcept
{
  return _red   == rhs._red   && 
         _green == rhs._green &&
         _blue  == rhs._blue;
}

inline bool Pixel::operator!=(const Pixel& rhs) const noexcept
{
  return !operator==(rhs);
}

inline std::string Pixel::toString() const noexcept
{
  return "(" + std::to_string(_red) + ", " + std::to_string(_green) + ", " + std::to_string(_blue) + ")";
}

inline std::ostream& operator<<(std::ostream& out, const Pixel& pixel) noexcept
{
  out << pixel.toString();

  return out;
}

} // namespace optris