// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ProcessingOutputConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a struct specifying which outputs should be computed and provided 
 *         by the SDK.
 * 
 * @date 2026-03-13 
 */

#pragma once

namespace optris 
{

/// Specifies which outputs should be computed and provided by the SDK.
struct ProcessingOutputConfig
{
  /**
   * @brief Specifies whether raw unprocessed frames are provided via the IRImager::onRawFrame callback.
   * 
   * If false, the callback IRImager::onRawFrame will not be triggered.
   */
  bool rawFrames = false;

  /**
   * @brief Specifies whether thermal frames are provided via the IRImager::onFrame callback.
   * 
   * If false, the thermal frame in the FrameEvent will be empty.
   */
  bool thermalFrames = true;

  /**
   * @brief Specifies whether measurement field should be processed.
   * 
   * If false:
   * - The map of field statuses in the FrameEvent provided via the IRImager::onFrame callback will be empty.
   * - Measurement fields will not be visible in the processed thermal frame.
   * - Entities processing measurement fields stats, like alarms or PIF output channels, will not be updated and
   *   thus retain their last state.
   */
  bool fields = true;
};

} // namespace optris