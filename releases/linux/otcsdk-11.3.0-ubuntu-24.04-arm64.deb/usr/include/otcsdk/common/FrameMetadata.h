// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FrameMetadata.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the metadata associated with each frame.
 * 
 * @date 2025-01-02
 */

#pragma once

#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/FlagState.h"
#include "otcsdk/common/RadiationParameters.h"


namespace optris 
{
// Forward declaration
struct FrameMetadata2;


/**
 * @brief Encapsulates the metadata of frames provided by the devices.
 * 
 * This metadata is passed alongside the frame data from the devices via the streaming interface (e.g. USB, Ethernet).
 */
class FrameMetadata
{
public:
  /// Constructor.
  OTC_SDK_API FrameMetadata() noexcept;

  
  /**
   * @brief Sets the metadata from the raw metadata provided by the processing pipeline.
   */
  OTC_SDK_API void setFrom(const FrameMetadata2& raw) noexcept;
  

  /**
   * @brief Indicates whether the provided thermal data is reliable.
   * 
   * During the initial startup calibration the provided thermal data is not reliable. This is
   * equivalent to the shutter flag being in the Initializing state
   * 
   * @return true if the provided thermal data is reliable. False otherwise.
   */
  bool isThermalDataReliable() const noexcept;


  /**
   * @brief Returns a consecutive number for each received frame.
   * 
   * @return consecutive number for each received frame.
   */
  unsigned int getCounter() const noexcept;

  /**
   * @brief Returns the frame number received from the device.
   * 
   * @note This counter may overflow.
   * 
   * @return frame number received from the device.
   */
  unsigned int getCounterHardware() const noexcept;


  /**
   * @brief Returns the frame timestamp in UNITS (10000000 units per second).
   * 
   * @return frame timestamp in UNITS (10000000 units per second).
   */
  long long getTimestamp() const noexcept;

  /**
   * @brief Returns the media timestamp.
   * 
   * @return media timestamp.
   */
  long long getTimestampMedia() const noexcept;


  /**
   * @brief Returns the state of the shutter flag at frame capturing time.
   * 
   * @return state of the shutter flag at frame capturing time.
   */
  FlagState getFlagState() const noexcept;

  /**
   * @brief Sets the state of the shutter flag.
   * 
   * @param[in] flagState to set.
   */
  void setFlagState(FlagState flagState) noexcept;


  /**
   * @brief Returns the shutter flag temperature in °C at frame capturing time.
   * 
   * @return shutter flag temperature in °C at frame capturing time.
   */
  float getTemperatureFlag() const noexcept;

  /**
   * @brief Returns the housing temperature in °C at frame capturing time.
   * 
   * @return housing temperature in °C at frame capturing time.
   */
  float getTemperatureBox() const noexcept;

  /**
   * @brief Returns the sensor chip temperature in °C at frame capturing time.
   * 
   * @return sensor chip temperature in °C at frame capturing time.
   */
  float getTemperatureChip() const noexcept;

  /**
   * @brief Returns the source of the standard emissivity value.
   * 
   * @return source of the standard emissivity value.
   */
  RadiationParameterSource getEmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the standard transmissivity value.
   * 
   * @return source of the standard transmissivity value. 
   */
  RadiationParameterSource getTransmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the standard ambient temperature value.
   * 
   * @return source of the standard ambient temperature value.
   */
  RadiationParameterSource getAmbientTemperatureSource() const noexcept;

  /**
   * @brief Returns the standard radiation parameters.
   *
   * The standard radiation parameters are used to process the thermal frame and all measurement fields that
   * do not specify a custom emissivity. Measurement fields with a custom emissivity, however, will still utilize
   * the transmissivity and ambient temperature from the standard radiation parameters.
   *
   * @attention The standard radiation parameters may be modified via the process interface (PIF) and through
   *            automated ambient temperature estimations. This method return the parameters set in the configuration
   *            or via IRImager::setRadiationParameters().
   *
   *            To get the set/configured parameters see IRImager::getRadiationParameters().
   *
   * @return standard radiation parameters.
   */
  RadiationParameters getRadiationParameters() const noexcept;


  /**
   * @brief Sets the standard radiation parameters used to process the
   *        frame. Intended for code paths that reconstruct a
   *        FrameMetadata from an external source (ZMQ wire, recorded
   *        frames, tests) where the SDK's internal processing pipeline
   *        isn't the producer of this metadata.
   *
   * @param[in] radiation the radiation parameters to store.
   */
  OTC_SDK_API void setRadiationParameters(
      const RadiationParameters& radiation) noexcept;


  /**
   * @brief Returns the analog input value on the given PIF channel.
   *
   * @warning The input values returned from channels on PIF devices that are just configurable but not
   *          actually connected to the camera (actualDeviceCount <= deviceIndex < configurableDeviceCount) 
   *          are invalid!
   * 
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * 
   * @return analog input value on the given PIF channel.
   * 
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API float getPifAiValue(int deviceIndex, int pinIndex) const;

  /**
   * @brief Returns the digital input value on the given PIF channel.
   * 
   * @warning The input values returned from channels on PIF devices that are just configurable but not
   *          actually connected to the camera (actualDeviceCount <= deviceIndex < configurableDeviceCount) 
   *          are invalid!
   *
   * @param[in] deviceIndex of the PIF device.
   * @param[in] pinIndex    of the pin on the specified PIF device.
   * 
   * @return digital input value on the given PIF channel.
   * 
   * @throw SDKException if either the device or pin index is out of range.
   */
  OTC_SDK_API bool getPifDiValue(int deviceIndex, int pinIndex) const;

  /**
   * @brief Returns the count of actually connected PIF devices.
   * 
   * @return count of actually connected PIF devices.
   */
  int getPifActualDeviceCount() const noexcept;

  /**
   * @brief Returns the count of configurable PIF devices.
   * 
   * @return count of configurable PIF devices.
   */
  int getPifConfigurableDeviceCount() const noexcept;

  /**
   * @brief Returns the count of analog input channels per PIF device.
   * 
   * @return count of analog input channels per PIF device.
   */
  int getPifAiCountPerDevice() const noexcept;

  /**
   * @brief Returns the count of digital input channels per PIF device.
   * 
   * @return count of digital input channels per PIF device.
   */
  int getPifDiCountPerDevice() const noexcept;


private:
  /// Consecutively numbered for each received frame.
  unsigned int _counter;
  /// Hardware counter received from device, multiply with value returned by IRImager::getAvgTimePerFrame() to get a hardware timestamp.
  unsigned int _counterHardware;

  /// Time stamp in UNITS (10000000 units per second). 
  long long _timestamp;
  /// Time stamp media.
  long long _timestampMedia;

  /// State of shutter flag at capturing time.
  FlagState _flagState;

  /// Shutter flag temperature.
  float _temperatureFlag;
  /// Temperature inside camera housing.
  float _temperatureBox;
  /// Chip temperature.
  float _temperatureChip;

  /// Radiation parameter that were used to process the frame.
  RadiationParameters _radiation;
  /// Source of the emissivity value.
  RadiationParameterSource _emissivitySource;
  /// Source of the ambient temperature value.
  RadiationParameterSource _ambientTemperatureSource;

  /// Count of actually connected PIF devices.
  int _pifActualDeviceCount;
  /// Count of configurable PIF devices.
  int _pifConfigurableDeviceCount;

  /// Count of PIF analog input channel per device.
  int _pifAiCountPerDevice;
  /// List of the current input values of the PIF analog input channels.
  std::vector<float> _pifAiValues;

  /// Count of PIF digital input channels per device.
  int _pifDiCountPerDevice;
  /// List of the current input values of the PIF digital input channels.
  std::vector<bool> _pifDiValues;
};


// Inline implementations
inline bool FrameMetadata::isThermalDataReliable() const noexcept
{
  return (_flagState != FlagState::Initializing);
}

inline unsigned int FrameMetadata::getCounter() const noexcept
{
  return _counter;
}

inline unsigned int FrameMetadata::getCounterHardware() const noexcept
{
  return _counterHardware;
}

inline long long FrameMetadata::getTimestamp() const noexcept
{
  return _timestamp;
}

inline long long FrameMetadata::getTimestampMedia() const noexcept
{
  return _timestampMedia;
}

inline FlagState FrameMetadata::getFlagState() const noexcept
{
  return _flagState;
}

inline void FrameMetadata::setFlagState(FlagState flagState) noexcept
{
  _flagState = flagState;
}

inline float FrameMetadata::getTemperatureFlag() const noexcept
{
  return _temperatureFlag;
}

inline float FrameMetadata::getTemperatureBox() const noexcept
{
  return _temperatureBox;
}

inline float FrameMetadata::getTemperatureChip() const noexcept
{
  return _temperatureChip;
}

inline RadiationParameters FrameMetadata::getRadiationParameters() const noexcept
{
  return _radiation;
}

inline void FrameMetadata::setRadiationParameters(
    const RadiationParameters& radiation) noexcept
{
  _radiation = radiation;
}

inline RadiationParameterSource FrameMetadata::getEmissivitySource() const noexcept
{
  return _emissivitySource;
}

inline RadiationParameterSource FrameMetadata::getTransmissivitySource() const noexcept
{
  return RadiationParameterSource::Sdk;
}

inline RadiationParameterSource FrameMetadata::getAmbientTemperatureSource() const noexcept
{
  return _ambientTemperatureSource;
}

inline int FrameMetadata::getPifActualDeviceCount() const noexcept
{
  return _pifActualDeviceCount;
}

inline int FrameMetadata::getPifConfigurableDeviceCount() const noexcept
{
  return _pifConfigurableDeviceCount;
}

inline int FrameMetadata::getPifAiCountPerDevice() const noexcept
{
  return _pifAiCountPerDevice;
}

inline int FrameMetadata::getPifDiCountPerDevice() const noexcept
{
  return _pifDiCountPerDevice;
}

} // namespace optris