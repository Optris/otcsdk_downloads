// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Vector.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class for a generic 2D vector.
 * 
 * @date 2026-02-03
 */

#pragma once

#include <ostream>


namespace optris 
{

/**
 * @brief Generic 2D vector structure.
 * 
 * @tparam T type of the vector components.
 */
template<typename T>
struct Vector2
{
  /// Type of the vector components.
  using ComponentType = T;

  /// x-component of the vector.
  T x;
  /// y-component of the vector.
  T y;
};


/// Alias for a 2D vector with float components.
using Vector2f = Vector2<float>;
/// Alias for a 2D vector with integer components.
using Vector2i = Vector2<int>;


// Utility functions
/**
 * @brief Checks if two vectors are equal.
 * 
 * @param[in] lhs first vector to compare.
 * @param[in] rhs second vector set to compare.
 *
 * @return true, if the vectors are equal.False otherwise.
 */
template<typename T>
inline bool operator==(const Vector2<T>& lhs, const Vector2<T>& rhs) noexcept
{
  return lhs.x == rhs.x && lhs.y == rhs.y;
}

/**
 * @brief Checks if two vectors are unequal.
 * 
 * @param[in] lhs first vector to compare.
 * @param[in] rhs second vector set to compare.
 *
 * @return true, if the vectors are unequal.False otherwise.
 */
template<typename T>
inline bool operator!=(const Vector2<T>& lhs, const Vector2<T>& rhs) noexcept
{
  return lhs.x != rhs.x || lhs.y != rhs.y;
}

/**
 * @brief Adds two vectors together.
 * 
 * @param[in] lhs first vector to add.
 * @param[in] rhs second vector to add.
 *
 * @return resulting vector of the addition.
 */
template<typename T>
inline Vector2<T> operator+(const Vector2<T>& lhs, const Vector2<T>& rhs) noexcept
{
  return {lhs.x + rhs.x, lhs.y + rhs.y};
}

/**
 * @brief Subtracts two vectors.
 * 
 * @param[in] lhs first vector to subtract.
 * @param[in] rhs second vector to subtract.
 *
 * @return resulting vector of the subtraction.
 */
template<typename T>
inline Vector2<T> operator-(const Vector2<T>& lhs, const Vector2<T>& rhs) noexcept
{
  return {lhs.x - rhs.x, lhs.y - rhs.y};
}

/**
 * @brief Ouput stream operator for vectors.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] vector to output.
 *
 * @return used output stream. 
 */
template<typename T>
std::ostream& operator<<(std::ostream& out, const Vector2<T>& vector) noexcept
{
  return (out << "(" << vector.x << ", " << vector.y << ")");
}

} // namespace optris