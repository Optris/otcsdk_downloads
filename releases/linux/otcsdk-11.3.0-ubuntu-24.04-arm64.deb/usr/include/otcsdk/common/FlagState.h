// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FlagState.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an enum representing the different states of the shutter flag.
 * 
 * @date 2025-01-02
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"


namespace optris 
{

/**
 * @brief Represents the different states of the shutter flag.
 * 
 * A flag cycle is defined by the transition through the following states:
 * 
 *  Open - Closing - Closed - Opening - Open
 * 
 * During the automated startup calibration after a successful device connection the flag
 * state will be Initializing indicating the thermal frame data is not yet reliable.
 */
enum class FlagState 
{ 
  Open,          ///< Flag is open.
  Closed,        ///< Flag is closed.
  Opening,       ///< Flag is opening.
  Closing,       ///< Flag is closing.
  Error,         ///< Flag is in an error state.
  Initializing,  ///< Flag state is beeing initialized/calibrated.
};


// Utility functions
/**
 * @brief Returns a string representation of the given flag state.
 * 
 * @note Use `flagStateToString()` in Python instead.
 * 
 * @param[in] flagState for which a string representation is desired.
 * 
 * @return string representation of the given flag state.
 */
OTC_SDK_API std::string toString(FlagState flagState) noexcept;

/**
 * @brief Ouput stream operator for flag states.
 * 
 * @param[in] out   stream to ouput to.
 * @param[in] state to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, FlagState state) noexcept;

} // namespace optris
