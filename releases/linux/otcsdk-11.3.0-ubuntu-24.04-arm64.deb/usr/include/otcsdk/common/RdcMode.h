// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   RdcMode.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains enum and utility functions for (R)adial (D)istortion (C)orrection modes.
 *
 * @date 2026-02-20
 *
 */

#pragma once

#include <string>
#include <ostream>

#include "otcsdk/Api.h"


namespace optris
{

/// Represents the different modes for radial distortion correction.
enum class RdcMode
{
  Off,     ///< Deactivated.
  Normal,  ///< Normal mode.
  Wide,    ///< Wide mode.
  Unknown, ///< Unknown mode. Used for error handling.
};


// Utility functions
/**
 * @brief Returns a string representation of the given radial distortion correction mode.
 * 
 * @note Use `rdcModeToString()` in Python instead.
 * 
 * @param[in] mode for which a string representation is desired.
 * 
 * @return string representation of the given radial distortion correction mode.
 */
OTC_SDK_API std::string toString(RdcMode mode) noexcept;

/**
 * @brief Ouput stream operator for radial distortion correction modes.
 * 
 * @param[in] out  stream to ouput to.
 * @param[in] mode to output.
 * 
 * @return the output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, RdcMode mode) noexcept;

} // namespace optris