// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   DeviceInfo.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating important information about devices.
 * 
 * @date 2025-02-11
 */

#pragma once

#include <string>
#include <tuple>

#include "otcsdk/Api.h"
#include "otcsdk/common/DeviceType.h"
#include "otcsdk/communication/net/MacAddress.h"
#include "otcsdk/communication/net/IpAddress.h"
#include "otcsdk/communication/net/Port.h"


namespace optris
{

/**
 * @brief Holds important information about a device.
 * 
 * Instances of this class are provided by the EnumerationManager and can be used to establish an connection
 * through an IRImager implementation.
 */
class DeviceInfo
{
public:
  /// Constructor.
  OTC_SDK_API DeviceInfo() noexcept;


  /**
   * @brief Determines the device type based on the provided hardware and firmware revisions.
   * 
   * @return determined device type.
   */
  OTC_SDK_API static DeviceType determineDeviceType(unsigned short hardwareRevision, unsigned short firmwareRevision) noexcept;


  /**
   * @brief Sets the serial number of the device.
   * 
   * @param[in] serialNumber to set.
   */
  OTC_SDK_API void setSerialNumber(unsigned long serialNumber) noexcept;

  /**
   * @brief Returns the serial number of the device.
   * 
   * @return serial number of the device.
   */
  OTC_SDK_API unsigned long getSerialNumber() const noexcept;

  /**
   * @brief Sets the connection interface of the device.
   * 
   * This can, for example, be USB or Ethernet.
   * 
   * @param[in] connectionInterface to set.
   */
  OTC_SDK_API void setConnectionInterface(const std::string& connectionInterface) noexcept;

  /**
   * @brief Returns the connection interface of the device.
   * 
   * This can, for example, be USB or Ethernet.
   * 
   * @return connection interface of the device.
   */
  OTC_SDK_API const std::string& getConnectionInterface() const noexcept;

  /**
   * @brief Sets the address of the local connection interface through which the camera is connected.
   * 
   * This refers to the address of the local connection interface, e.g. the usb endpoint or address or IP address of the network interface.
   * 
   * @param[in] address to set.
   */
  OTC_SDK_API void setConnectionInterfaceAddress(const std::string& address) noexcept;

  /**
   * @brief Returns the address of the local connection interface through which the camera is connected.
   * 
   * This refers to the address of the local connection interface, e.g. the usb endpoint or address or IP address of the network interface.
   * 
   * @return Address of the connection interface.
   */
  OTC_SDK_API const std::string& getConnectionInterfaceAddress() const noexcept;

  /**
   * @brief Sets the IP address.
   * 
   * For Ethernet connections this refers to the IP address of the device.
   * 
   * @param[in] ipAddress address to set.
   */
  OTC_SDK_API void setIpAddress(const IpAddress& ipAddress) noexcept;

  /**
   * @brief Returns the IP address.
   * 
   * For Ethernet connections this refers to the IP address of the device.
   * 
   * @return IP address.
   */
  OTC_SDK_API const IpAddress& getIpAddress() const noexcept;

  /**
   * @brief Sets the IP address of the streaming target.
   * 
   * For Ethernet connections this refers to the IP address of the streaming target machine.
   * 
   * @param[in] ipAddress address to set.
   */
  OTC_SDK_API void setTargetIpAddress(const IpAddress& ipAddress) noexcept;

  /**
   * @brief Returns the IP address of the streaming target.
   * 
   * For Ethernet connections this refers to the IP address of the streaming target machine.
   * 
   * @return IP address.
   */
  OTC_SDK_API const IpAddress& getTargetIpAddress() const noexcept;

  /**
   * @brief Sets the port.
   * 
   * For Ethernet connections this refers to the port the device will send its data to.
   * 
   * @param[in] port to set.
   */
  OTC_SDK_API void setPort(const Port& port) noexcept;

  /**
   * @brief Returns the port.
   * 
   * For Ethernet connections this refers to the port the device will send its data to.
   * 
   * @return port.
   */
  OTC_SDK_API const Port& getPort() const noexcept;

  /**
   * @brief Return the device type.
   * 
   * @return device type.
   */
  OTC_SDK_API DeviceType getDeviceType() const noexcept;

  /**
   * @brief Sets the hardware and firmware revisions.
   * 
   * @param[in] hardware revision to set.
   * @param[in] firmware revision to set.
   */
  OTC_SDK_API void setRevisions(unsigned short hardware, unsigned short firmware) noexcept;

  /**
   * @brief Returns the hardware revision.
   * 
   * @return hardware revision.
   */
  OTC_SDK_API unsigned short getHardwareRevision() const noexcept;

    /**
   * @brief Returns the firmware revision.
   * 
   * @return firmware revision.
   */
  OTC_SDK_API unsigned short getFirmwareRevision() const noexcept;

  /**
   * @brief Sets the device busy state.
   * 
   * @param[in] busy true if device is busy. False otherwise.
   */
  OTC_SDK_API void setBusy(bool busy) noexcept;

  /**
   * @brief Returns whether the device is busy.
   * 
   * A device is busy when it is already used by the SDK or the PixConnect.
   * 
   * @return true if device is busy. False otherwise.
   */
  OTC_SDK_API bool isBusy() const noexcept;

  /**
   * @brief Sets the MAC address.
   * 
   * @param[in] mac connection state.
   */
  OTC_SDK_API void setMacAddress(const MacAddress& mac) noexcept;

  /**
   * @brief Returns the MAC address.
   * 
   * @return MAC address.
   */
  OTC_SDK_API const MacAddress& getMacAddress() const noexcept;


  /// Equals operator.
  bool operator==(const DeviceInfo& rhs) const noexcept;
  /// Unequals operator.
  bool operator!=(const DeviceInfo& rhs) const noexcept;
  /// Less than operator.
  bool operator<(const DeviceInfo& rhs) const noexcept;


private:
  DeviceType  _deviceType;  
  std::string _connectionInterface;
  std::string _connectionInterfaceAddress;


  MacAddress _deviceMacAddress;
  IpAddress  _deviceIpAddress;
  IpAddress  _targetIpAddress;
  Port       _targetPort;
  
  unsigned long  _serialNumber;
  unsigned short _hardwareRevision;
  unsigned short _firmwareRevision;
  bool           _busy;
};


// Inline implementations
inline void DeviceInfo::setSerialNumber(unsigned long serialNumber) noexcept
{
  _serialNumber = serialNumber;
}

inline unsigned long DeviceInfo::getSerialNumber() const noexcept
{
  return _serialNumber;
}

inline const std::string& DeviceInfo::getConnectionInterface() const noexcept
{
  return _connectionInterface;
}

inline void DeviceInfo::setConnectionInterfaceAddress(const std::string& address) noexcept
{
  _connectionInterfaceAddress = address;
}

inline const std::string& DeviceInfo::getConnectionInterfaceAddress() const noexcept
{
  return _connectionInterfaceAddress;
}

inline void DeviceInfo::setIpAddress(const IpAddress& ipAddress) noexcept
{
  _deviceIpAddress = ipAddress;
}

inline const IpAddress& DeviceInfo::getIpAddress() const noexcept
{
  return _deviceIpAddress;
}

inline void DeviceInfo::setTargetIpAddress(const IpAddress& ipAddress) noexcept
{
  _targetIpAddress = ipAddress;
}

inline const IpAddress& DeviceInfo::getTargetIpAddress() const noexcept
{
  return _targetIpAddress;
}

inline void DeviceInfo::setPort(const Port& port) noexcept
{
  _targetPort = port;
}

inline const Port& DeviceInfo::getPort() const noexcept
{
  return _targetPort;
}

inline DeviceType DeviceInfo::getDeviceType() const noexcept
{
  return _deviceType;
}

inline unsigned short DeviceInfo::getHardwareRevision() const noexcept
{
  return _hardwareRevision;
}

inline unsigned short DeviceInfo::getFirmwareRevision() const noexcept
{
  return _firmwareRevision;
}

inline void DeviceInfo::setBusy(bool busy) noexcept
{
  _busy = busy;
}

inline bool DeviceInfo::isBusy() const noexcept
{
  return _busy;
}

inline void DeviceInfo::setMacAddress(const MacAddress& macAddress) noexcept
{
  _deviceMacAddress = macAddress;
}

inline const MacAddress& DeviceInfo::getMacAddress() const noexcept
{
  return _deviceMacAddress;
}

inline bool DeviceInfo::operator==(const DeviceInfo& rhs) const noexcept
{
  return (_deviceType                 == rhs._deviceType                 &&
          _connectionInterface        == rhs._connectionInterface        &&
          _connectionInterfaceAddress == rhs._connectionInterfaceAddress &&
          _deviceMacAddress           == rhs._deviceMacAddress           &&
          _deviceIpAddress            == rhs._deviceIpAddress            &&
          _targetIpAddress            == rhs._targetIpAddress            &&
          _targetPort                 == rhs._targetPort                 &&
          _serialNumber               == rhs._serialNumber               &&
          _hardwareRevision           == rhs._hardwareRevision           &&
          _firmwareRevision           == rhs._firmwareRevision           &&
          _busy                       == rhs._busy);
}

inline bool DeviceInfo::operator!=(const DeviceInfo& rhs) const noexcept
{
  return !operator==(rhs);
}

inline bool DeviceInfo::operator<(const DeviceInfo& rhs) const noexcept
{
  return std::tie(_serialNumber, _connectionInterface) < std::tie(rhs._serialNumber, rhs._connectionInterface);
}

} // namespace optris