// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Slope.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the parameters for a linear transformation.
 * 
 * @date 2026-07-01
 */

#pragma once

#include <ostream>


namespace optris
{

/**
 * @brief Encapsulates the parameters of a linear transformation.
 * 
 * y(x) = gain * x + offset
 */
struct Slope
{
  /// Gain of the linear transformation.
  float gain = 1.F;
  /// Offset of the linear transformation.
  float offset = 0.F;
};


// Utility functions
/**
 * @brief Output stream operator for Slope.
 * 
 * @param[in] out   stream to use.
 * @param[in] slope to output. 
 *
 * @return used output stream. 
 */
inline std::ostream& operator<<(std::ostream& out, const Slope& slope) noexcept
{
  return (out << "gain: " << slope.gain << ", offset: " << slope.offset);
}

} // namespace optris