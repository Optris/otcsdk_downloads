// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   IRImagerClient.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the base class for all clients observing an IRImager.
 * 
 * @date 2024-12-10
 */

#pragma once

#include "otcsdk/events/AlarmEvent.h"
#include "otcsdk/events/CompositeAlarmEvent.h"
#include "otcsdk/events/ConnectionEvent.h"
#include "otcsdk/events/FrameEvent.h"
#include "otcsdk/events/OperationInfoEvent.h"
#include "otcsdk/events/RawFrameEvent.h"
#include "otcsdk/events/UncommittedValueEvent.h"
#include "otcsdk/events/VideoFormatEvent.h"


namespace optris
{

/**
 * @brief Base class for clients observing an IRImager.
 * 
 * The architecture is following the Observer design pattern. To receive data like thermal frames from your device
 * derive your own class from it and implement the callback methods. After creating an instance of you need to
 * register it with an IRImager object by calling its IRImager::addClient() method.
 */
class IRImagerClient
{
public:
  /// Constructor.
  IRImagerClient() = default;

  /// No copy constructor.
  IRImagerClient(const IRImagerClient&) = default;
  /// No copy assignment.
  IRImagerClient& operator=(const IRImagerClient&) = default;

  /// Move constructor.
  IRImagerClient(IRImagerClient&&) = default;
  /// Move assignment.
  IRImagerClient& operator=(IRImagerClient&&) = default;

  /// Destructor.
  virtual ~IRImagerClient() = default;


  /**
   * @brief Called when the connection state has changed.
   *
   * The ConnectionState also models the process of acquiring missing calibration files.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy (C++) or use the clone() method (all other languages).
   * 
   * This callback is triggered by a dedicated thread that does not block the processing loop. Slow processing in this callback
   * will, however, block subsequent callbacks.
   *
   * @param[in] evt event containing the updated connection state.
   */
  virtual void onConnection(ConnectionEvent& evt) noexcept
  { }

  /**
   * @brief Triggered when the processing of a frame is complete.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy (C++) or use the clone() method (all other languages).
   *
   * The SDK has an internal pool of buffers that it uses to store the processing results. The buffers are resused for 
   * subsequent frames. Since this callback is now triggered by a dedicated thread it will no longer block the processing loop.
   * But slow processing in this callback can clog the internal buffer pool and will cause the SDK to drop old processing results.
   *
   * The maximum possible frequency of this callback is determined by two configuration parameters:
   * - The set frame rate of the device. This is the upper limit for the callback frequency.
   * - The set subsampled frame rate that internally limits the device frame rate.
   *
   * Depending on the set ProcessingOutputConfig the provided event may contain an empty thermal frame or no measurement field data.
   * 
   * This callback will also be triggered during the initial startup calibration phase following a successful device connection.
   * During this time the thermal data is unreliable. You can detect this phase by checking whether the flag state stored in the
   * meta data is set to Initializing.
   * 
   * @param[in] evt event containing metadata, thermal frame data and measurement field data.
   *
   * @see FrameEvent
   */
  virtual void onFrame(const FrameEvent& evt) noexcept 
  { }

  /**
   * @brief Triggered when a new raw frames is available.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy (C++) or use the clone() method (all other languages).
   * 
   * The SDK has an internal pool of buffers that it uses to store the processing results. The buffers are resused for 
   * subsequent frames. Since this callback is now triggered by a dedicated thread it will no longer block the processing loop.
   * But slow processing in this callback can clog the internal buffer pool and will cause the SDK to drop old processing results.
   *
   * The maximum possible frequency of this callback is determined by the set frame rate of the device. It is unaffected by the set
   * subsampled frame rate.
   *
   * The callback will not be triggered if ProcessingOutputConfig::rawFrames is set to false.
   *
   * @param[in] evt event containing metadata and raw frame data.
   *
   * @see RawFrameEvent
   */
  virtual void onRawFrame(const RawFrameEvent& evt) noexcept 
  { }

  /**
   * @brief Called when the video format changed.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy (C++) or use the clone() method (all other languages).
   *
   * This callback is triggered by a dedicated thread that does not block the processing loop. Slow processing in this callback
   * will, however, block subsequent callbacks.
   * 
   * @param[in] evt event containing the updated video format information.
   *
   * @see VideoFormatEvent
   */
  virtual void onVideoFormatChanged(const VideoFormatEvent& evt) noexcept
  { }

  /**
   * @brief Called when the state of the composite alarm changes.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy with a simple assignment (C++) or the clone() method (all other languages).
   *
   * The callback will not be triggered, if none of the active alarm channels is configured to be part of the composite alarm.
   *
   * This callback is triggered by a dedicated thread that does not block the processing loop. Slow processing in this callback
   * will, however, block subsequent callbacks.
   *
   * @param[in] evt event containing the composite alarm information.
   *
   * @see CompositeAlarmEvent
   */
  virtual void onCompositeAlarm(const CompositeAlarmEvent& evt) noexcept
  { }

  /**
   * @brief Called when the state of an alarm channel changes.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy with a simple assignment (C++) or the clone() method (all other languages).
   *
   * This callback is triggered by a dedicated thread that does not block the processing loop. Slow processing in this callback
   * will, however, block subsequent callbacks.
   *
   * @param[in] evt event containing the alarm information.
   *
   * @see AlarmEvent
   */
  virtual void onAlarm(const AlarmEvent& evt) noexcept
  { }

  /**
   * @brief Called when an updated uncommitted value is available.
   * 
   * The callback is only triggered when the corresponding PIF analog input signal has changed.
   *
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy with a simple assignment (C++) or the clone() method (all other languages).
   * 
   * This callback is triggered by a dedicated thread that does not block the processing loop. Slow processing in this callback
   * will, however, block subsequent callbacks.
   * 
   * @param[in] evt event containing the updated uncommitted value.
   *
   * @see UncommittedValueEvent
   */
  virtual void onPifUncommittedValue(const UncommittedValueEvent& evt) noexcept
  { }

  /**
   * @brief Called when a new set of operation module tracing information is available.
   * 
   * @attention The memory referenced by the provided event is only valid during the callback. If you wish to use it outside
   *            of the callback make an explict copy with a simple assignment (C++) or the clone() method (all other languages).
   * 
   * The SDK has an internal pool of buffers that it uses to store the processing results. The buffers are resused for 
   * subsequent frames. Since this callback is now triggered by a dedicated thread it will no longer block the processing loop.
   * But slow processing in this callback can clog the internal buffer pool and will cause the SDK to drop old processing results.
   *
   * The maximum possible frequency of this callback is determined by the interval time provided when configuring the operation info
   * tracing via IRImager::configureOperationInfo(). If the interval is set to 0, this callback will not be triggered at all.
   * 
   * @param[out] evt event containing the updated operation mode tracing information.
   *
   * @see OperationInfoEvent, IRImager::configureOperationInfo()
   */
  virtual void onOperationInfo(const OperationInfoEvent& evt) noexcept
  { }
};

} // namespace optris