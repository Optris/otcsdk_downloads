// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Exceptions.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the exceptions raised by the SDK.
 * 
 * @date 2024-12-12
 */

#pragma once

#include <exception>
#include <string>
#include <utility>


namespace optris 
{

/// Exception raised by the SDK.
class SDKException : public std::exception
{
public:
  /// Constructor.
  SDKException() noexcept = default;

  /**
   * @brief Constructor.
   * 
   * @param[in] message error message.
   */
  explicit SDKException(std::string message) noexcept;


  /**
   * @brief Returns the error message.
   * 
   * @return error message.
   */
  const char* what() const noexcept override;


private:
  /// Error message.
  std::string _message;
};


// Inline implementations
inline SDKException::SDKException(std::string message) noexcept
  : _message{std::move(message)}
{ }

inline const char* SDKException::what() const noexcept
{
  return _message.c_str();
}

} // namespace optris
