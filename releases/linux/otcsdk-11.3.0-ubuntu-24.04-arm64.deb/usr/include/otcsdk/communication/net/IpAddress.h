// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   IpAddress.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding IP v4 address.
 * 
 * @date 2024-12-20
 */

#pragma once

#include <array>
#include <ostream>
#include <cstdint>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"


namespace optris 
{

/**
 * @brief Encapsulates an IP v4 address.
 *
 * IP address are stored in an array in the following oder:
 *
 * a.b.c.d => [0: a, 1: b, 2: c, 3: d]
 */ 
class IpAddress
{
public:
  /**
   * @brief Constructor.
   *
   * All IP address bytes are set to 0.
   */
  OTC_SDK_API IpAddress() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] address as an unsigned 32 bit integer in network byte order.
   */
  OTC_SDK_API IpAddress(std::uint32_t address) noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] address string in dot notation (a.b.c.d).
   * 
   * @throw SDKException if address string is invalid.
   */
  OTC_SDK_API IpAddress(const std::string& address);

  /**
   * @brief Constructor.
   *
   * @param[in] a byte from an a.b.c.d IP address.
   * @param[in] b byte from an a.b.c.d IP address.
   * @param[in] c byte from an a.b.c.d IP address.
   * @param[in] d byte from an a.b.c.d IP address.
   */
  OTC_SDK_API IpAddress(std::uint8_t a, std::uint8_t b, std::uint8_t c, std::uint8_t d) noexcept;


  /// Resets all the bytes of the IP address to 0 (0.0.0.0).
  OTC_SDK_API void reset();

  /**
   * @brief Sets the address from an unsigned 32 bit integer in network byte order.
   *
   * @note The network byte order is big-endian while many architectures like x64 or arm64 are little-endian.
   *
   * @param[in] address as an unsigned 32 bit integer with the bytes in network order.
   */
  OTC_SDK_API void setFromUInt32(std::uint32_t address) noexcept;

  /**
   * @brief Returns the address as an unsigned 32 bit integer in network byte order.
   * 
   * @note The network byte order is big-endian while many architectures like x64 or arm64 are little-endian.
   *
   * @return address as an unsigned 32 bit integer in network byte order.
   */
  OTC_SDK_API std::uint32_t toUInt32() const noexcept;

  /**
   * @brief Sets the address from a string in dot notation (a.b.c.d).
   * 
   * @param[in] address in dot notation.
   * 
   * @throw SDKException if the address string is invalid.
   */
  OTC_SDK_API void setFromString(const std::string& address);

  /**
   * @brief Sets the address from a string in classless inter-domain routing (CIDR) notation (a.b.c.d/cidr).
   * 
   * @param[in] address in CIDR notation.
   *
   * @return CIDR part of the address representing the bit count of the network portion of the address.
   *
   * @throw SDKException if the address string is invalid. 
   */
  OTC_SDK_API int setFromCidrString(const std::string& address);

  /**
   * @brief Returns the address as a string in dot notation (a.b.c.d).
   * 
   * @return the address as a string in dot notation.
   */
  OTC_SDK_API std::string toString() const noexcept;

  /**
   * @brief Returns the address as a string in classless inter-domain routing (CIDR) notation (a.b.c.d/cidr).
   * 
   * @param[in] cidr part of the address representing the bit count of the network portion of the address.
   *
   * @return the address as a string in classless inter-domain routing (CIDR) notation. 
   */
  OTC_SDK_API std::string toCidrString(int cidr) const noexcept;

  /**
   * @brief Sets the value of the byte with the given index.
   * 
   * @param[in] index of the byte to set.
   * @param[in] value to set.
   * 
   * @throw SDKException if index is out of range.
   */
  OTC_SDK_API void setByte(int index, std::uint8_t value);

  /**
   * @brief Returns the value of the byte with the given index.
   * 
   * @param[in] index of the desired byte.
   * 
   * @return value of the byte with the given index.
   * 
   * @throw SDKException if the index is out of range.
   */
  OTC_SDK_API std::uint8_t getByte(int index) const;

  /**
   * @brief Returns the network portion of the IP address according to the given subnet mask.
   * 
   * @param[in] subnetMask to apply to the IP address.
   * 
   * @return network portion of the IP address.
   */
  OTC_SDK_API IpAddress getNetworkPortion(const IpAddress& subnetMask) const noexcept;

  /**
   * @brief Returns the network portion of the IP address according to the given CIDR bit count
   * 
   * @param[in] cidr part of the address representing the bit count of the network portion of the address.
   * 
   * @return network portion of the IP address.
   *
   * @throw SDKException if the value of cidr is not in [0, 32].
   */
  OTC_SDK_API IpAddress getNetworkPortion(int cidr) const;

  /**
   * @brief Returns the host portion of the IP address according to the given subnet mask.
   * 
   * @param[in] subnetMask to apply to the IP address.
   * 
   * @return host portion of the IP address.
   */
  OTC_SDK_API IpAddress getHostPortion(const IpAddress& subnetMask) const noexcept;

  /**
   * @brief Returns the host portion of the IP address according to the given CIDR bit count.
   * 
   * @param[in] cidr part of the address representing the bit count of the network portion of the address.
   * 
   * @return host portion of the IP address.
   *
   * @throw SDKException if the value of cidr is not in [0, 32].
   */
  OTC_SDK_API IpAddress getHostPortion(int cidr) const;

  /**
   * @brief Returns the broadcast address for this IP address with the given subnet mask.
   * 
   * @param[in] subnetMask to apply to the IP address.
   * 
   * @return broadcast address for this IP address with the given subnet mask.
   */
  OTC_SDK_API IpAddress getBroadcastAddress(const IpAddress& subnetMask) const noexcept;

  /**
   * @brief Returns the broadcast address for this IP address with the given CIDR bit count.
   * 
   * @param[in] cidr part of the address representing the bit count of the network portion of the address.
   * 
   * @return broadcast address for this IP address with the given CIDR bit count.
   *
   * @throw SDKException if the value of cidr is not in [0, 32].
   */
  OTC_SDK_API IpAddress getBroadcastAddress(int cidr) const;


  /**
   * @brief Returns whether this IP address equals the provided one.
   * 
   * @param[in] rhs IP address to compare this one to.
   *
   * @return true, if this IP address equals the provided one.
   */
  bool operator==(const IpAddress& rhs) const noexcept;

  /**
   * @brief Returns whether this IP address equals the provided one.
   * 
   * @param[in] rhs IP address as unsigned 32 bit integer in network byte order to compare this one to.
   *
   * @return true, if this IP address equals the provided one.
   */
  bool operator==(std::uint32_t rhs) const noexcept;

  /**
   * @brief Returns whether this IP address is different from the provided one.
   * 
   * @param[in] rhs IP address to compare this one to.
   *
   * @return true, if this IP address is different from the provided one. False otherwise.
   */
  bool operator!=(const IpAddress& rhs) const noexcept;

  /**
   * @brief Returns whether this IP address has a smaller unsigned 32 bit integer representation than the
   *        provided one.
   * 
   * @param[in] rhs IP address to compare this one to.
   *
   * @return true, if this IP address has a smaller unsigned 32 bit integer representation than the provided
   *         one. False otherwise.
   */
  bool operator<(const IpAddress& rhs) const noexcept;


private:
  /// Holds the address bytes.
  std::array<std::uint8_t, 4> _bytes;


  /**
   * @brief Converts the CIDR bit count into the corresponding subnet mask and returns it as 32 bit integer in network byte order. 
   * 
   * @param[in] cidr representing the bit count of the network portion of the address.
   *
   * @return corresponding subnet mask and returns it as 32 bit integer in network byte order.
   *
   * @throw SDKException if the value of cidr is not in [0, 32].
   */
  static std::uint32_t cidrToUInt32(int cidr);
};


// Utility functions
/**
 * @brief Output stream operator for IP addresses.
 * 
 * @param[in] out     stream to write the address to.
 * @param[in] address to output.
 *
 * @return used output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const IpAddress& address);


// Inline implementations
inline bool IpAddress::operator==(const IpAddress& rhs) const noexcept
{
  return _bytes == rhs._bytes;
}

inline bool IpAddress::operator==(std::uint32_t rhs) const noexcept
{
  return toUInt32() == rhs;
}

inline bool IpAddress::operator!=(const IpAddress& rhs) const noexcept
{
  return !(_bytes == rhs._bytes);
}

inline bool IpAddress::operator<(const IpAddress& rhs) const noexcept
{
  return toUInt32() < rhs.toUInt32();
}

} // namespace optris