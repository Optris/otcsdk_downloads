// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   MeasurementField.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an interface representing a measurement field.
 * 
 * @date 2026-03-30
 */

#pragma once

#include <cstdint>
#include <memory>

#include "otcsdk/fields/MeasurementFieldConfig.h"


namespace optris
{

/// Measurement field or region of interest (ROI) within the thermal frame.
class MeasurementField
{
public:
  /// Shared pointer type for measurement fields.
  using ConstShared = std::shared_ptr<const MeasurementField>;


  /// Constructor.
  MeasurementField() = default;

  /// No copy constructor.
  MeasurementField(MeasurementField&) = delete;
  /// No copy assignment operator.
  MeasurementField& operator=(MeasurementField&) = delete;

  /// No move constructor.
  MeasurementField(MeasurementField&&) = delete;
  /// No move assignment operator.
  MeasurementField& operator=(MeasurementField&&) = delete;

  /// Destructor.
  virtual ~MeasurementField() = default;
              

  /**
   * @brief Returns the unique ID of the measurement field.
   * 
   * @return unique ID of the measurement field.
   */
  virtual std::int32_t getId() const noexcept = 0;

  /**
   * @brief Returns the index of the measurement field.
   *
   * The index determines the order in which measurement fields are rendered on
   * top of each other. Fields with a higher index are rendered on top of fields 
   * with a lower index. The thermal frame will always be in the background.
   *
   * @return index of the measurement field. 
   */
  virtual std::uint32_t getIndex() const noexcept = 0;

  /**
   * @brief Returns the name of the measurement field.
   * 
   * @return name of the measurement field.
   */
  virtual const std::string& getName() const noexcept = 0;

  /**
   * @brief Returns the configuration of the measurement field.
   * 
   * @return configuration of the measurement field.
   */
  virtual const MeasurementFieldConfig& getConfig() const noexcept = 0;
};

} // namespace optris
