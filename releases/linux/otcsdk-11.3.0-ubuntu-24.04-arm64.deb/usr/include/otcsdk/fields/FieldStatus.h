// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FieldStatus.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that encapsulates status of a processed measurement field.
 * 
 * @date 2026-03-09
 */

#pragma once

#include <cstdint>
#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/fields/FieldProperties.h"


namespace optris
{

// Forward declaration
struct ProcessingParams;


/// Encapsulates the status of a processed measurement field.
class FieldStatus
{
public:
  /// Constructor.
  OTC_SDK_API FieldStatus() noexcept;


  /**
   * @brief Returns the field name.
   *
   * @return field name.
   */
  const std::string& getName() const noexcept;

  /**
   * @brief Returns the unique field ID.
   * 
   * @return unique field ID.
   */
  std::int32_t getId() const noexcept;

  /**
   * @brief Returns the field index.
   *
   * @return field index.
   */
  std::uint32_t getIndex() const noexcept;

  /**
   * @brief Returns the results of the statistical analysis of the measurement field.
   *
   * @return field statistics.
   */
  const FieldStats& getStats() const noexcept;

  /**
   * @brief Returns the radiation parameters used to process the measurement field.
   *
   * @return radiation parameters used to process the measurement field.
   */
  const RadiationParameters& getRadiation() const noexcept;

  /**
   * @brief Returns the source of the emissivity value used to process the measurement field.
   *
   * @return source of the emissivity value.
   */
  RadiationParameterSource getEmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the transmissivity value used to process the measurement field.
   *
   * @return source of the transmissivity value.
   */
  RadiationParameterSource getTransmissivitySource() const noexcept;

  /**
   * @brief Returns the source of the ambient temperature value used to process the measurement field.
   *
   * @return source of the ambient temperature value.
   */
  RadiationParameterSource getAmbientTemperatureSource() const noexcept;


  /**
   * @brief Sets the field status.
   *
   * @param[in] id     measurement field ID.
   * @param[in] stats  results of the statistical analysis of the measurement field.
   * @param[in] params processing parameters.
   */
  OTC_SDK_API void update(std::int32_t id, const FieldStats& stats, const ProcessingParams& params) noexcept;


private:
  std::string   _name;
  std::uint32_t _index;
  std::int32_t  _id;

  FieldStats _stats;

  RadiationParameters      _radiation;
  RadiationParameterSource _ambientTemperatureSource;
};


// Utility function
/**
 * @brief Output stream operator for measurement field status.
 * 
 * @param[in] out    stream to use.
 * @param[in] status to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const FieldStatus& status);


// Inline implementations
inline const std::string& FieldStatus::getName() const noexcept
{
  return _name;
}

inline std::int32_t FieldStatus::getId() const noexcept
{
  return _id;
}

inline std::uint32_t FieldStatus::getIndex() const noexcept
{
  return _index;
}

inline const FieldStats& FieldStatus::getStats() const noexcept
{
  return _stats;
}

inline const RadiationParameters& FieldStatus::getRadiation() const noexcept
{
  return _radiation;
}

inline RadiationParameterSource FieldStatus::getEmissivitySource() const noexcept
{
  return RadiationParameterSource::Sdk;
}

inline RadiationParameterSource FieldStatus::getTransmissivitySource() const noexcept
{
  return RadiationParameterSource::Sdk; 
}

inline RadiationParameterSource FieldStatus::getAmbientTemperatureSource() const noexcept
{
  return _ambientTemperatureSource;
}

} // namespace optris