// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   MeasurementFieldConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the configuration of a measurement field.
 * 
 * @date 2025-07-23
 */

#pragma once

#include <string>
#include <ostream>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/common/Vector.h"
#include "otcsdk/fields/FieldProperties.h"


namespace optris
{

/// Encapsulates the configuration of a field shape.
struct FieldShapeConfig
{
  /// Type of the field shape.
  FieldShape type = FieldShape::Rectangle;

  /**
   * @brief Center point for rectangular and elliptical fields or the origin of 
   *        of the vertex coordinates for polygonal and spline based fields.
   */
  Vector2f position  = {0.F, 0.F};

  /// Dimension for rectangular and elliptical fields. Ignored for polygonal and spline based fields.
  Vector2f dimension = {0.F, 0.F};

  /**
   * @brief Vertices for polygonal and spline based fields. Ignored for rectangular and elliptical fields.
   * 
   * The vertices need to be defined relative to the point of origin specified by position.
   */
  std::vector<Vector2f> vertices;

  /**
   * @brief Specifies whether the provided position, dimension and vertices are pixel coordinates
   *        or are normalized to the range [0, 1] relative to the current frame dimensions.
   *
   * Only one format for position, dimension and vertices can be used. There is no mixing and matching.
   */
  bool normalized = false;


  /**
   * @brief Validates the field shape configuration.
   * 
   * @param[in, out] config to validate.
   * 
   * @throws SDKException if the configuration is invalid.
   */
  OTC_SDK_API static void validate(FieldShapeConfig& config);
};


/// Encapsulates the configuration of a measurement field.
struct MeasurementFieldConfig
{
  /// Measurement field name.
  std::string name;

  /// Defines the shape of the measurement field.
  FieldShapeConfig shape;

  /**
   * @brief Field-specific emissivity value in [0.01, 1.1].
   *
   * The field customEmissivity needs to be set to true for the specified value to be applied.
   */
  float emissivity = 1.F;

  /// Indicates whether a custom emissivity should be used.
  bool customEmissivity = false;


  /**
   * @brief Validates the measurement field configuration.
   * 
   * @param[in] config to validate.
   * 
   * @throws SDKException if the configuration is invalid.
   */
  OTC_SDK_API static void validate(MeasurementFieldConfig& config);
};


// Utility functions
/**
 * @brief Ouput stream operator for field shape configurations.
 * 
 * @param[in] out              stream to ouput to.
 * @param[in] fieldShapeConfig to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const FieldShapeConfig& fieldShapeConfig) noexcept;

/**
 * @brief Ouput stream operator for measurement field configurations.
 * 
 * @param[in] out    stream to ouput to.
 * @param[in] config to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const MeasurementFieldConfig& config) noexcept;

} // namespace optris