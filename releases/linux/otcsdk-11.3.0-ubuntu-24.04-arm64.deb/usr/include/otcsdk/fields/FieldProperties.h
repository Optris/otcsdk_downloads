// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FieldProperties.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains various enums and structs representing the properties of fields.
 * 
 * @date 2025-07-23
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"


namespace optris
{

/// Represents the different available field shapes.
enum class FieldShape
{
  Rectangle, ///< Rectangular field.
  Ellipse,   ///< Elliptical field.
  Polygon,   ///< Polygonal field defined by a set of vertices.
  Splines,   ///< Spline based field defined by a set of vertices.
};

/// Represents the different field statistics that can be used by other components (PIF, alarms).
enum class FieldStat
{
  Minimum, ///< Minimum field temperature.
  Maximum, ///< Maximum field temperature.
  Mean,    ///< Mean field temperature.
  Median,  ///< Median field temperature.
};

/// Encapsulates the results of the statistical analysis of a measurement field.
struct FieldStats
{
  /// Minimum temperature in °C.
  float min = 0.F;
  /// Maximum temperature in °C.
  float max = 0.F;
  /// Mean temperature in °C.
  float mean = 0.F;
  /// Sample deviation of the temperatures in °C.
  float sampleDeviation = 0.F;
  /// Median temperature in °C.
  float median = 0.F;
  /// Number of evaluated valid pixels in the field.
  std::size_t n = 0;
};


// Utility functions
/**
 * @brief Returns the value of the given field statistic.
 * 
 * @param[in] stats field statistics.
 * @param[in] stat  to retrieve from the field statistics.
 * 
 * @return value of the given field statistic.
 */
OTC_SDK_API float getFieldStat(const FieldStats& stats, FieldStat stat) noexcept;

/**
 * @brief Returns a string representation of the given field shape.
 * 
 * @note Use `fieldShapeToString()` in Python instead.
 * 
 * @param[in] shape for which a string representation is desired.
 * 
 * @return string representation of the given field shape.
 */
OTC_SDK_API std::string toString(FieldShape shape) noexcept;

/**
 * @brief Returns a string representation of the given field statistic.
 * 
 * @note Use `fieldStatToString()` in Python instead.
 * 
 * @param[in] stat for which a string representation is desired.
 * 
 * @return string representation of the given field statistic.
 */
 OTC_SDK_API std::string toString(FieldStat stat) noexcept;

/**
 * @brief Ouput stream operator for field shapes.
 * 
 * @param[in] out   stream to ouput to.
 * @param[in] shape to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, FieldShape shape) noexcept;

/**
 * @brief Ouput stream operator for field statistics.
 * 
 * @param[in] out  stream to ouput to.
 * @param[in] stat to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, FieldStat stat) noexcept;

/**
 * @brief Ouput stream operator for field stats.
 * 
 * @param[in] out   stream to ouput to.
 * @param[in] stats to output.
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const FieldStats& stats) noexcept;

} // namespace optris