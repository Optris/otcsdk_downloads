// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Sdk.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a static class that allows for the basic configuration of the SDK and for retrieving basic information
 *         about the SDK.
 * 
 * @date 2025-04-22
 */

#pragma once

#include <array>
#include <cstdint>
#include <string>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/common/VersionInfo.h"


/// Main SDK namespace.
namespace optris
{

/// Represents the different logging verbosity levels.
enum class Verbosity 
{ 
  Off     = 1,  ///< Off.
  Error   = 2,  ///< Error.
  Warning = 3,  ///< Warning.
  Info    = 4,  ///< Info.
  Debug   = 5,  ///< Debug.
};

/// Represents the different sources from which the calibration files can be acquired.
enum class CalibrationFileSource
{
  Device,      ///< The calibration files are fetched from the on-board memory of the device. Not supported by all devices. 
  Filesystem,  ///< The calibration files are copied from a local filesystem directory.
  Internet,    ///< The calibration files are downloaded from Optris servers. Requires internet access.
  Empty,       ///< No calibration source wanted.
};


/// Static class granting access to SDK wide configuration and utility functions.
class Sdk
{
public:
  /// No constructor.
  Sdk() = delete;


  /**
   * @brief Initializes the SDK.
   *
   * It sets the verbosity levels of the internal logger of the SDK, starts the EnumerationManager in a dedicated thread
   * to monitor the availability of devices, and loads color palettes from the SDK, working, and user palette directories.
   *
   * @param[in] logScreen           defines the minimum verbosity level of log messages displayed on the standard output and error.
   * @param[in] logFile             defines the minimum verbosity level of log messages out to the logfile.
   * @param[in] logFilenamePrefix   for the log file `<logFilenamePrefix>_<YYYY_MM_DDThh-mm-ss>.log`. If empty, it defaults to "OtcSDK".
   * @param[in] customDataDirectory for the SDK to use. An empty string will have no effect. The SDK requires read and write access
   *                                to this directory. For detail on how specify it see Sdk::setCustomDataDirectory().
   */
  OTC_SDK_API static void init(Verbosity logScreen, 
                               Verbosity logFile, 
                               std::string logFilenamePrefix   = "", 
                               std::string customDataDirectory = "");

  /**
   * @brief Configures the SDK internal logger.
   * 
   * If you change the logFilenamePrefix from the one used in Sdk::init() or in a previous call to Sdk::configure(), the current
   * log file will be closed and new one will be created.
   *
   * @param[in] logScreen         defines the minimum verbosity level of log messages displayed on the standard output and error.
   * @param[in] logFile           defines the minimum verbosity level of log messages out to the logfile.
   * @param[in] logFilenamePrefix for the log file `<logFilenamePrefix>_<YYYY_MM_DDThh-mm-ss>.log`. If empty, it defaults to "OtcSDK".
   */
  OTC_SDK_API static void configureLogger(Verbosity logScreen, Verbosity logFile, std::string logFilenamePrefix = "");


  /**
   * @brief Callback function type for receiving SDK log messages.
   *
   * @param verbosityLevel 0=Error, 1=Warning, 2=Info, 3=Debug, 4=Trace.
   * @param message        the log message text.
   */
  using LogCallback = void(OTC_SDK_C_CALL*)(int verbosityLevel, const char* message);

  /**
   * @brief Sets a callback that receives SDK log messages.
   *
   * @param[in] callback  function pointer to invoke on each log message, or nullptr to remove.
   * @param[in] exclusive when true, disables file and screen output while the callback is active.
   */
  OTC_SDK_API static void setLogCallback(LogCallback callback, bool exclusive = false);


  /**
   * @brief Sets a custom data directory for the SDK to use.
   *
   * @attention A custom data directory can only be set when there are no active device connections. 
   *
   * If the given directory does not exist, the SDK will try to create it (recursively).
   *
   * When specifying the directory path the following symbols/variables are supported:
   * - `~`, `%%USERPROFILE%` refer to `~/` on __Linux__ and `<User Home>/` on __Windows__.
   * - `%%APPDATA%` refers to `~/.config/` on __Linux__ and `<User AppData>/Roaming/` on __Windows__.
   *
   * Relative paths are not supported. You can either use `/` as system independet directory separator or utilize
   * system dependent ones like `/` for __Linux__ and `\` on __Windows__.
   *
   * @param[in] customDataDirectory for the SDK to use. An empty string will have no effect. The SDK requires
   *                                read and write permission to this directory.
   * 
   * @throw SDKException if
   *        - there is an active device connection.
   *        - the given path is not a directory.
   *        - the SDK can not access the directory
   *        - the SDK failed to create the directory.
   */
  OTC_SDK_API static void setCustomDataDirectory(const std::string& customDataDirectory);

  /**
   * @brief Clears a previously set custom data directory for the SDK.
   *
   * Once cleared the SDK reverts to the default user data directory:
   * - __Linux__ `~/.config/optris/`
   * - __Windows__ `<User AppData>/Roaming/Imager/`
   *
   * @throw SDKException if there is an active device connection or if the default user data directory path
   *        could not be determined.
   */
  OTC_SDK_API static void clearCustomDataDirectory();

  /**
   * @brief Sets the priority of the calibration file sources.
   * 
   * The priority of the sources needs to be set prior to connecting to a device. If you want to use less than three potential calibration
   * file source, set the one you do not require to Empty. The different sources have individual requirements for them to work:
   * 
   * - Device. Not all types of Optris cameras have their calibration files stored on-device. 
   * - Filesystem. The source directory should be accessible and the SDK should have the rights to copy the calibration files from
   *   it to their target destination. The source directory needs to be specified via the Sdk::setCalibrationFileSourceDirectory()
   *   method.
   * - Internet. Access to the internet is required.
   * 
   * @note The SDK does not yet feature the ability to download the calibration from the device.
   * 
   * @param[in] first  source with the highest priority.
   * @param[in] second source with a medium priority.
   * @param[in] third  source with the lowest priority.
   * 
   * @return true, if priority was successfully set. False, otherwise.
   */
  OTC_SDK_API static bool setCalibrationFileSources(CalibrationFileSource first, CalibrationFileSource second, CalibrationFileSource third);

  /**
   * @brief Sets the source directory from which calibration files can be copied.
   * 
   * When specifying the directory path the following symbols/variables are supported:
   * - `~`, `%%USERPROFILE%` refer to `~/` on __Linux__ and `<User Home>/` on __Windows__.
   * - `%%APPDATA%` refers to `~/.config/` on __Linux__ and `<User AppData>/Roaming/` on __Windows__.
   *
   * Relative paths are not supported. You can either use `/` as system independet directory separator or utilize
   * system dependent ones like `/` for __Linux__ and `\` on __Windows__.
   * 
   * @param[in] sourceDirectory from which calibration files can be copied. An empty string will have no effect.
   * 
   * @throw SDKException if the given path does not exist or is not a directory.
   */
  OTC_SDK_API static void setCalibrationFileSourceDirectory(const std::string& sourceDirectory);

  /**
   * @brief Clears a previously set source directory for calibration files.
   *
   * When cleared, the SDK will skip the CalibrationFileSource::Filesystem option when acquiring calibration files.
   */
  OTC_SDK_API static void clearCalibrationFileSourceDirectory();

  /**
   * @brief Returns an object holding version and build information about the SDK.
   *
   * @return object holding version and build information about the SDK.
   */
  OTC_SDK_API static VersionInfo getVersionInfo();


  /**
   * @brief Loads palettes from the SDK and user palette directories.
   *
   * Scans the SDK data directory first, then the user data directory so that
   * user-supplied palettes with the same name override the built-in ones.
   * Missing directories are silently skipped.
   *
   * This method is idempotent — calling it more than once reloads all palettes
   * from disk, replacing any previously registered entries.
   */
  OTC_SDK_API static void loadPalettes();

  /**
   * @brief Loads palettes from a custom directory.
   *
   * Adds or overwrites palette entries in the registry without clearing
   * previously loaded palettes.
   *
   * When specifying the directory path the following symbols/variables are supported:
   * - `~`, `%%USERPROFILE%` refer to `~/` on __Linux__ and `<User Home>/` on __Windows__.
   * - `%%APPDATA%` refers to `~/.config/` on __Linux__ and `<User AppData>/Roaming/` on __Windows__.
   *
   * Relative paths are not supported. You can either use `/` as system independet directory separator or utilize
   * system dependent ones like `/` for __Linux__ and `\` on __Windows__.
   *
   * @param[in] directory path to scan for `.csv` palette files.
   *
   * @throw SDKException if @p directory does not exist or is not a directory.
   */
  OTC_SDK_API static void loadPalettes(const std::string& directory);

  /**
   * @brief Returns the names of all currently loaded palettes in sorted order.
   *
   * @return sorted list of palette name strings.
   */
  OTC_SDK_API static std::vector<std::string> getPaletteNames();

  /**
   * @brief Returns the 240 RGB color entries of the named palette.
   *
   * Each entry is an array of three bytes: `{ R, G, B }`.
   *
   * @param[in] name palette name (case-sensitive).
   *
   * @return vector of 240 RGB triples.
   *
   * @throw SDKException if the palette is not found.
   */
  OTC_SDK_API static std::vector<std::array<uint8_t, 3>> getPaletteColors(const std::string& name);

  /**
   * @brief Registers a palette at runtime without persisting it to disk.
   *
   * An existing palette with the same name is overwritten.
   *
   * @param[in] name   unique palette name.
   * @param[in] colors exactly 240 RGB triples `{ R, G, B }`.
   *
   * @throw SDKException if @p colors does not contain exactly 240 entries.
   */
  OTC_SDK_API static void registerPalette(const std::string&                          name,
                                          const std::vector<std::array<uint8_t, 3>>& colors);

  /**
   * @brief Saves a registered palette as a CSV file in the user palette directory.
   *
   * The output filename is `<name>.csv`. The user palette directory is created
   * automatically if it does not exist.
   *
   * @param[in] name palette name to save (case-sensitive).
   *
   * @throw SDKException if the palette is not found or the file cannot be written.
   */
  OTC_SDK_API static void savePalette(const std::string& name);
};

} // namespace optris