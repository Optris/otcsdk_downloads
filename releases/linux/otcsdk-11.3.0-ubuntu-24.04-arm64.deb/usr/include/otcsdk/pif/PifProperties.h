// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   PifProperties.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains enums defining various properties of process interfaces.
 * 
 * @date 2025-06-13
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"


namespace optris
{

// Device
/// Represents the supported PIF device types.
enum class PifDeviceType
{
  Automatic,         ///< Use the PIF type reported by the camera firmware.
  None,              ///< No PIF.
  Standard,          ///< Standard PIF.
  IndustrialMV,      ///< Industrial PIF with voltage based analog outputs.
  IndustrialMA,      ///< Industrial PIF with current based analog outputs.
  Internal,          ///< Internal PIF.
  Stackable,         ///< Stackable PIF.
  TemperatureProbe,  ///< Instead of a PIF an external temperature probe is used.
  Proprietary,       ///< The pins of the PIF connector on the camera are used directly.
};


// Modes
/// Represents the available modes for PIF analog input channels.
enum class PifAiMode
{
  Off,                 ///< Off.
  FlagControl,         ///< The shutter flag is controlled by the input voltage.
  Emissivity,          ///< Emissivity for the thermal frame is derived from the input voltage.
  AmbientTemperature,  ///< Ambient temperature for the thermal frame is derived from the input voltage.
  UncommittedValue,    ///< The input voltage value is transformed and provided to IRImagerClients via a callback.
};

/// Represents the available modes for PIF digital input channels.
enum class PifDiMode
{
  Off,          ///< Off.
  FlagControl,  ///< The flag is controlled by the input signal.
};

/// Represents the available modes for PIF analog output channels.
enum class PifAoMode
{
  Off,                    ///< Off.
  FlagStatus,             ///< The status of the shutter flag is output.
  FrameSync,              ///< Every time a new frame is capture a pulse is output.
  FailSafe,               ///< A heart beat signal is provided that indicates whether the camera and SDK are working correctly.
  ExternalCommunication,  ///< The output value can be controlled by clients of the SDK.
  MeasurementField,       ///< The set data point of a measurement field is output.
  InternalTemperature,    ///< The internal camera temperature is output.
  Alarm,                  ///< The status of a configured alarm channels are output.
};

/// Represents the available modes for PIF digital output channels.
enum class PifDoMode
{
  Off,                    ///< Off.
  FlagStatus,             ///< The status of the shutter flag is output.
  FrameSync,              ///< Every time a new frame is capture a high pulse is output.
  FailSafe,               ///< A heart beat signal is provided that indicates whether the camera and SDK are working correctly.
  ExternalCommunication,  ///< The output value can be controlled by clients of the SDK.
  Alarm,                  ///< The status of a configured alarm channels are output.
};

/// Represents the available modes for PIF fail safe channels.
enum class PifFsMode
{
  Off,  ///< Off.
  On,   ///< On.
};

/// Represents the available output modes for PIF analog output channels.
enum class PifAoOutputMode
{
  _0_20mA,  ///< 0 mA - 20 mA
  _4_20mA,  ///< 4 mA - 20 mA
  _0_10V,   ///< 0 V - 10 V
};

/// Holds the indices that identify the physical pin on a PIF device for a PIF channel.
struct PifIndex
{
  /// Index of the PIF device. For devices with only one PIF this is 0.
  int device = 0;
  /// Index of the pin on the PIF device.
  int pin    = 0;


  /**
   * @brief Validates the given PIF index.
   * 
   * @param[in] index PIF index to validate.
   *
   * @throw SDKException if the index is invalid.
   */
  OTC_SDK_API static void validate(const PifIndex& index);
};


// Utility functions
/**
 * @brief Returns the lower limit of the specified PIF analog output mode as a number value.
 * 
 * @param[in] outputMode for which the lower limit is desired.
 *
 * @return lower limit of the specified PIF analog output mode as a number value. 
 */
OTC_SDK_API float lowerLimit(PifAoOutputMode outputMode) noexcept;

/**
 * @brief Returns the upper limit of the specified PIF analog output mode as a number value.
 * 
 * @param[in] outputMode for which the upper limit is desired.
 *
 * @return upper limit of the specified PIF analog output mode as a number value. 
 */
OTC_SDK_API float upperLimit(PifAoOutputMode outputMode) noexcept;

/**
 * @brief Clamps the given value to the limits of the specified PIF analog output mode.
 * 
 * @param[in] value      to clamp.
 * @param[in] outputMode to which the provided value should be clamped.
 *
 * @return the given value to the limits of the specified PIF analog output mode. 
 */
OTC_SDK_API float clampValue(float value, PifAoOutputMode outputMode) noexcept;

/**
 * @brief Equality operator for PIF indices.
 * 
 * @param[in] lhs left-hand side index.
 * @param[in] rhs right-hand side index.
 *
 * @return true if the indices are equal, false otherwise.
 */
inline bool operator==(const PifIndex& lhs, const PifIndex& rhs) noexcept
{
  return lhs.device == rhs.device && lhs.pin == rhs.pin;
}

/**
 * @brief Inequality operator for PIF indices.
 * 
 * @param[in] lhs left-hand side index.
 * @param[in] rhs right-hand side index.
 *
 * @return true if the indices are unequal, false otherwise.
 */
inline bool operator!=(const PifIndex& lhs, const PifIndex& rhs) noexcept
{
  return lhs.device != rhs.device || lhs.pin != rhs.pin;
}

/**
 * @brief Returns a string representation of the given PIF index.
 *
 * @note Use `pifIndexToString()` in Python instead.
 * 
 * @param[in] index for which a string representation is desired.
 * 
 * @return string representation of the given PIF index.
 */
OTC_SDK_API std::string toString(const PifIndex& index) noexcept;

/**
 * @brief Returns a string representation of the given PIF device type.
 * 
 * @note Use `pifDeviceTypeToString()` in Python instead.
 * 
 * @param[in] type for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF device type.
 */
OTC_SDK_API std::string toString(PifDeviceType type) noexcept;

/**
 * @brief Returns a string representation of the given PIF analog input mode.
 * 
 * @note Use `pifAiModeToString()` in Python instead.
 * 
 * @param[in] analogInputMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF analog input mode.
 */
OTC_SDK_API std::string toString(PifAiMode analogInputMode) noexcept;

/**
 * @brief Returns a string representation of the given PIF digital input mode.
 * 
 * @note Use `pifDiModeToString()` in Python instead.
 * 
 * @param[in] digitalInputMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF digital input mode.
 */
OTC_SDK_API std::string toString(PifDiMode digitalInputMode) noexcept;

/**
 * @brief Returns a string representation of the given PIF analog output mode.
 * 
 * @note Use `pifAoModeToString()` in Python instead.
 * 
 * @param[in] analogOutputMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF analog output mode.
 */
OTC_SDK_API std::string toString(PifAoMode analogOutputMode) noexcept;

/**
 * @brief Returns a string representation of the given PIF digital output mode.
 * 
 * @note Use `pifDoModeToString()` in Python instead.
 * 
 * @param[in] digitalOutputMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF digital output mode.
 */
OTC_SDK_API std::string toString(PifDoMode digitalOutputMode) noexcept;

/**
 * @brief Returns a string representation of the given PIF fail safe mode.
 * 
 * @note Use `pifFsModeToString()` in Python instead.
 * 
 * @param[in] failSafeMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF fail safe mode.
 */
OTC_SDK_API std::string toString(PifFsMode failSafeMode) noexcept;

/**
 * @brief Returns a string representation of the given PIF analog output mode.
 * 
 * @note Use `pifAoOutputModeToString()` in Python instead.
 * 
 * @param[in] outputMode for which a string representation is desired.
 * 
 * @return string respresentation of the given PIF analog output mode.
 */
OTC_SDK_API std::string toString(PifAoOutputMode outputMode) noexcept;

/**
 * @brief Output stream operator for PIF device types.
 * 
 * @param[in] out        stream to use.
 * @param[in] deviceType to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifDeviceType deviceType) noexcept;

/**
 * @brief Output stream operator for PIF analog input modes.
 * 
 * @param[in] out             stream to use.
 * @param[in] analogInputMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifAiMode analogInputMode) noexcept;

/**
 * @brief Output stream operator for PIF digital input modes.
 * 
 * @param[in] out              stream to use.
 * @param[in] digitalInputMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifDiMode digitalInputMode) noexcept;

/**
 * @brief Output stream operator for PIF analog output modes.
 * 
 * @param[in] out              stream to use.
 * @param[in] analogOutputMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifAoMode analogOutputMode) noexcept;

/**
 * @brief Output stream operator for PIF digital output modes.
 * 
 * @param[in] out               stream to use.
 * @param[in] digitalOutputMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifDoMode digitalOutputMode) noexcept;

/**
 * @brief Output stream operator for PIF fail safe modes.
 * 
 * @param[in] out          stream to use.
 * @param[in] failSafeMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifFsMode failSafeMode) noexcept;

/**
 * @brief Output stream operator for PIF analog output mode.
 * 
 * @param[in] out        stream to use.
 * @param[in] outputMode to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifAoOutputMode outputMode) noexcept;

/**
 * @brief Output stream operator for PIF indices.
 * 
 * @param[in] out   stream to use.
 * @param[in] index to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, PifIndex index) noexcept;

} // namespace optris