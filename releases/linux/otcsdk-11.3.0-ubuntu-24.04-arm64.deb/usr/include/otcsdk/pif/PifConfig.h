// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   PifConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the configuration for the process interface.
 * 
 * @date 2025-06-23
 */

#pragma once

#include <ostream>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/pif/PifChannelConfigs.h"


namespace optris
{

/**
 * @brief Holds the configuration of the processing interface.
 * 
 * This can be single PIF or a set of stackable PIFs.
 */
struct PifConfig
{
  /**
   * @brief Specifies the desired PIF device type.
   * 
   * For more details please refer either to documentation of the [Process Interface (PIF)](#pif) chapter.
   */
  PifDeviceType deviceType = PifDeviceType::Automatic;

  /**
   * @brief Specifies how many stackable PIFs should be configurable through the SDK.
   * 
   * - This setting is only relevant for stackable PIFs. In all other cases the count can be derived from the device type.
   * - The number of actually connected stackable PIFs can be lower but the SDK will never report more connected stackable
   *   PIFs than specified by this count.
   * 
   * For more details please refer either to documentation of the [Process Interface (PIF)](#pif) chapter.
   */
  int deviceCount = 1;

  /**
   * @brief Configurations for the analog input channels in no specific order.
   * 
   * - All available channels that have no configuration are set to mode `off`. 
   * - If multiple configurations for the same channel exist, only the one that was added first will be applied.
   */
  std::vector<PifAiConfig>  analogInputs;

  /**
   * @brief Configurations for the digital input channels in no specific order.
   * 
   * - All available channels that have no configuration are set to mode `off`. 
   * - If multiple configurations for the same channel exist, only the one that was added first will be applied.
   */
  std::vector<PifDiConfig> digitalInputs;

  /**
   * @brief Configurations for the analog output channels in no specific order.
   * 
   * - All available channels that have no configuration are set to mode `off`. 
   * - If multiple configurations for the same channel exist, only the one that was added first will be applied.
   */
  std::vector<PifAoConfig>  analogOutputs;

    /**
   * @brief Configurations for the digital output channels in no specific order.
   * 
   * - All available channels that have no configuration are set to mode `off`. 
   * - If multiple configurations for the same channel exist, only the one that was added first will be applied.
   */
  std::vector<PifDoConfig> digitalOutputs;

  /**
   * @brief Configuration for the fail safe channel.
   * 
   * The configuration will only be applied, if a fail safe channel exists.
   */
  PifFsConfig failSafe;
};


// Utility functions
/**
 * @brief Output stream operator for the PifConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifConfig& config) noexcept;

} // namespace optris