// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   PifChannelConfigs.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains classes holding the configuration parameter for the different process interface channels.
 * 
 * @date 2025-06-23
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/common/Slope.h"
#include "otcsdk/pif/PifProperties.h"
#include "otcsdk/fields/FieldProperties.h"
#include "otcsdk/fields/MeasurementField.h"


namespace optris
{

/**
 * @brief Encapsulates the configuration for a PIF analog input channel.
 * 
 * For a detailed overview of all available modes and parameters please refer to the corresponding section in the documentation
 * of the [configuration file](#important-files-configuration-process-interface-analog-inputs).
 */
struct PifAiConfig
{
  /// Identifies the channel by the indices of its pin and the PIF device on which it is located.
  PifIndex index = {0, 0};
  

  /// Mode to be applied to the channel.
  PifAiMode mode = PifAiMode::Off;

  /// Defines how input voltages are converted into the desired target values.
  Slope slope = {1.F, 0.F};

  /// Trigger threshold for the input voltage.
  float triggerThreshold = 0.F;
  /// Indicates whether the trigger will be pulled if the input voltage is below or above the threshold.
  bool  triggerLowActive = true;

  /// Name of the uncommitted value.
  std::string uncommittedValueName;
  /// Unit of the uncommitted value.
  std::string uncommittedValueUnit;


  /**
   * @brief Creates a configuration for the mode PifAiMode::Off.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifAiMode::Off.
   */
  OTC_SDK_API static PifAiConfig createOff(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAiMode::AmbientTemperature.
   * 
   * The input voltage U_in is converted to the ambient temperature t_ambient as follows:
   *
   * `t_ambient = (U_in - offset) / gain`
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] gain        for converting the input voltage into the ambient temperature.
   * @param[in] offset      for converting the input voltage into the ambient temperature.
   *
   * @return configuration for the mode PifAiMode::AmbientTemperature.
   */
  OTC_SDK_API static PifAiConfig createAmbientTemperature(int deviceIndex, int pinIndex, float gain, float offset) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAiMode::Emissivity.
   * 
   * The input voltage U_in is converted to the emissivity e as follows:
   *
   * `e = (U_in - offset) / gain`
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] gain        for converting the input voltage into the emissivity.
   * @param[in] offset      for converting the input voltage into the emissivity.
   *
   * @return configuration for the mode PifAiMode::Emissivity.
   */
  OTC_SDK_API static PifAiConfig createEmissivity(int deviceIndex, int pinIndex, float gain, float offset) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAiMode::FlagControl.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] threshold   voltage level.
   * @param[in] openIfLow   if true, the shutter flag will be opened, if the input voltage is lower than the threshold. 
   *
   * @return configuration for the mode PifAiMode::FlagControl.
   */
  OTC_SDK_API static PifAiConfig createFlagControl(int deviceIndex, int pinIndex, float threshold, bool openIfLow) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAiMode::UncommittedValue.
   * 
   * The input voltage U_in is converted to the uncommitted value x as follows:
   *
   * `x = (U_in - offset) / gain`
   *
   * When ever U_in changes the SDK will trigger the callback IRImagerClient::onPifUncommittedValue().
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] name        of the uncommitted value.
   * @param[in] unit        of the uncommitted value.
   * @param[in] gain        for converting the input voltage into the emissivity.
   * @param[in] offset      for converting the input voltage into the emissivity.
   *
   * @return configuration for the mode PifAiMode::UncommittedValue.
   */
  OTC_SDK_API static PifAiConfig createUncommittedValue(int deviceIndex, int pinIndex, const std::string& name, const std::string& unit, float gain, float offset) noexcept;
};


/**
 * @brief Encapsulates the configuration for a PIF digital input channel.
 * 
 * For a detailed overview of all available modes and parameters please refer to the corresponding section in the documentation
 * of the [configuration file](#important-files-configuration-process-interface-digital-inputs).
 */
struct PifDiConfig
{
  /// Identifies the channel by the indices of its pin and the PIF device on which it is located.
  PifIndex index = {0, 0};


  /// Mode to be applied to the channel.
  PifDiMode mode = PifDiMode::Off;

  /// Indicates whether the trigger will be pulled if the input signal is low.
  bool triggerLowActive = true;


  /**
   * @brief Creates a configuration for the mode PifDiMode::Off.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifDiMode::Off.
   */
  OTC_SDK_API static PifDiConfig createOff(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Create a configuration for the mode PifDiMode::FlagControl.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] openIfLow   if true, the shutter flag will be opend, if the input signal is low.
   *
   * @return configuration for the mode PifDiMode::FlagControl. 
   */
  OTC_SDK_API static PifDiConfig createFlagControl(int deviceIndex, int pinIndex, bool openIfLow) noexcept;
};


/**
 * @brief Encapsulates the configuration for a PIF analog output channel.
 * 
 * For a detailed overview of all available modes and parameters please refer to the corresponding section in the documentation
 * of the [configuration file](#important-files-configuration-process-interface-analog-outputs).
 */
struct PifAoConfig
{
  /// Identifies the channel by the indices of its pin and the PIF device on which it is located.
  PifIndex index = {0, 0};


  /// Mode to be applied to the channel.
  PifAoMode mode = PifAoMode::Off;
  /// Output mode to be applied to the channel.
  PifAoOutputMode outputMode = PifAoOutputMode::_0_10V;

  /// Defines how data points are converted into output values.
  Slope slope = {1.F, 0.F};

  /// Identifies the measurement field by its index.
  int fieldIndex = 0;
  /// Determines which field statistic should be output.
  FieldStat fieldStat = FieldStat::Mean;

  /// Output value for an active event/state.
  float outputActive = 10.0F;
  /// Output value for an intermediate event/state.
  float outputIntermediate = 10.0F;
  /// Output value for an inactive event/state.
  float outputInactive = 0.0F;


  /**
   * @brief Creates a configuration for the mode PifAoMode::Off.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifAoMode::Off.
   */
  OTC_SDK_API static PifAoConfig createOff(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::Alarm.
   * 
   * The values for active and clear are automatically clipped to the specified output mode limits.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] active      value to output if the alarm is active.
   * @param[in] clear       value to output if the alarm is clear.
   *
   * @return configuration for the mode PifAoMode::Alarm. 
   */
  OTC_SDK_API static PifAoConfig createAlarm(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, float active, float clear) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::ExternalCommunication.
   * 
   * When set to external communication the output value of the channel can be set with ProcessInterface::setAoValue().
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   *
   * @return configuration for the mode PifAoMode::ExternalCommunication. 
   */
  OTC_SDK_API static PifAoConfig createExternalCommunication(int deviceIndex, int pinIndex, PifAoOutputMode outputMode) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::FlagStatus.
   * 
   * The values for open, moving and closed are automatically clipped to the specified output mode limits.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] open        value to output if the shutter flag is open.
   * @param[in] moving      value to output if the shutter flag is moving.
   * @param[in] closed      value to output if the shutter flag is closed.
   *
   * @return configuration for the mode PifAoMode::FlagStatus. 
   */
  OTC_SDK_API static PifAoConfig createFlagStatus(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, float open, float moving, float closed) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::FrameSync.
   * 
   * The value for pulse will automatically be clipped to the specified output mode limits.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] pulse       height of the generated pulse indicating an newly captured frame.
   *
   * @return configuration for the mode PifAoMode::FrameSync. 
   */
  OTC_SDK_API static PifAoConfig createFrameSync(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, float pulse) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::InternalTemperature.
   * 
   * The internal temperature t_internal is converted into an output value X_out as follows:
   *
   * `X_out = gain * t_internal + offset`
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] gain        for converting the internal temperature into an output value.
   * @param[in] offset      for converting the internal temperature into an output value.
   *
   * @return configuration for the mode PifAoMode::InternalTemperature. 
   */
  OTC_SDK_API static PifAoConfig createInternalTemperature(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, float gain, float offset) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::MeasurementField.
   * 
   * The data point of the measurement field that will be output is given by the value of the MeasurementFieldConfig::mode
   * and can be accessed through MeasurementField::getDataPoint(). Its value x_field is converted into an output value X_out
   * as follows:
   *
   * `X_out = gain * x_field + offset`
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] field       shared pointer to the measurement field. If nullptr is passed, the field index will be set to 0.
   * @param[in] fieldStat   determining which field statistic should be output.
   * @param[in] gain        for converting the measurement field data point into an output value.
   * @param[in] offset      for converting the measurement field data point into an output value.
   *
   * @return configuration for the mode PifAoMode::MeasurementField. 
   */
  OTC_SDK_API static PifAoConfig createMeasurementField(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, const MeasurementField::ConstShared& field, FieldStat fieldStat, float gain, float offset) noexcept;

  /**
   * @brief Creates a configuration for the mode PifAoMode::FailSafe.
   *
   * Refer to the [Fail Safe](#fail-safe) chapter for more details. 
   *
   * The value for pulse will automatically be clipped to the specified output mode limits.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] outputMode  to apply.
   * @param[in] pulse       height of the output heart beat signal.
   *
   * @return configuration for the mode PifAoMode::FailSafe. 
   */
  OTC_SDK_API static PifAoConfig createFailSafe(int deviceIndex, int pinIndex, PifAoOutputMode outputMode, float pulse) noexcept;
};


/**
 * @brief Encapsulates the configuration for a PIF digital output channel.
 * 
 * For a detailed overview of all available modes and parameters please refer to the corresponding section in the documentation
 * of the [configuration file](#important-files-configuration-process-interface-digital-outputs).
 */
struct PifDoConfig
{
  /// Identifies the channel by the indices of its pin and the PIF device on which it is located.
  PifIndex index = {0, 0};


  /// Mode to be applied to the channel.
  PifDoMode mode = PifDoMode::Off;

  /// Indicates if the output is low active.
  bool outputLowActive = true;


  /**
   * @brief Creates a configuration for the mode PifDoMode::Off.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifDoMode::Off.
   */
  OTC_SDK_API static PifDoConfig createOff(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Creates a configuration for the mode PifDoMode::Alarm.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] lowIfActive if true, a low signal will be output, if the alarm is active.
   *
   * @return configuration for the mode PifDoMode::Alarm. 
   */
  OTC_SDK_API static PifDoConfig createAlarm(int deviceIndex, int pinIndex, bool lowIfActive) noexcept;

  /**
   * @brief Creates a configuration for the mode PifDoMode::FlagStatus.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] lowIfOpen   if true, a low signal will be output, if the flag is open.
   *
   * @return configuration for the mode PifDoMode::FlagStatus. 
   */
  OTC_SDK_API static PifDoConfig createFlagStatus(int deviceIndex, int pinIndex, bool lowIfOpen) noexcept;

  /**
   * @brief Create a configuration for the mode PifDoMode::FrameSync.
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifDoMode::FrameSync. 
   */
  OTC_SDK_API static PifDoConfig createFrameSync(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Creates a configuration for the mode PifDoMode::ExternalCommunication.
   * 
   * When set to external communication the output value of the channel can be set with ProcessInterface::setDoValue().
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifDoMode::ExternalCommunication. 
   */
  OTC_SDK_API static PifDoConfig createExternalCommunication(int deviceIndex, int pinIndex) noexcept;

  /**
   * @brief Creates a configuration for the mode PifDoMode::FailSafe.
   * 
   * Refer to the [Fail Safe](#fail-safe) chapter for more details. 
   *
   * @attention This mode is __unique__ and can only be applied once for __all__ channels.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return configuration for the mode PifDoMode::FailSafe. 
   */
  OTC_SDK_API static PifDoConfig createFailSafe(int deviceIndex, int pinIndex) noexcept;
};


/**
 * @brief Encapsulates the configuration for a PIF fail safe channel.
 * 
 * For a detailed overview of all available modes and parameters please refer to the corresponding section in the documentation
 * of the [configuration file](#important-files-configuration-process-interface-fail-safe).
 */
struct PifFsConfig
{
  /// Mode to be applied to the channel.
  PifFsMode mode = PifFsMode::Off;


  /**
   * @brief Creates a configuration for the PifFsMode::Off.
   * 
   * @return configuration for the PifFsMode::Off.
   */
  OTC_SDK_API static PifFsConfig createOff() noexcept;

  /**
   * @brief Creates a configuration for the PifFsMode::On.
   * 
   * @return configuration for the PifFsMode::On.
   */
  OTC_SDK_API static PifFsConfig createOn() noexcept;
};


// Utility functions
/**
 * @brief Output stream operator for PifAiConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifAiConfig& config) noexcept;

/**
 * @brief Output stream operator for PifDiConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifDiConfig& config) noexcept;

/**
 * @brief Output stream operator for PifAoConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifAoConfig& config) noexcept;

/**
 * @brief Output stream operator for PifDoConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifDoConfig& config) noexcept;

/**
 * @brief Output stream operator for PifFsConfig.
 * 
 * @param[in] out    stream to use.
 * @param[in] config to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const PifFsConfig& config) noexcept;

} // namespace optris