// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   UncommittedValueStatus.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the status of an uncommitted value.
 * 
 * @date 2026-04-10
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/pif/PifProperties.h"


namespace optris 
{

/// Holds the status of an uncommitted value derived from a PIF analog input.
class UncommittedValueStatus
{
public:
  /// Constructor.
  OTC_SDK_API UncommittedValueStatus() noexcept;


  /**
   * @brief Returns the index of the PIF analog input that generated the uncommitted value.
   *
   * @return the index of the PIF analog input that generated the uncommitted value.
   */
  const PifIndex& getPifIndex() const noexcept;

  /**
   * @brief Returns the name of the uncommitted value.
   *
   * @return the name of the uncommitted value.
   */
  const std::string& getName() const noexcept;

  /**
   * @brief Returns the unit of the uncommitted value.
   *
   * @return the unit of the uncommitted value.
   */
  const std::string& getUnit() const noexcept;

  /**
   * @brief Returns the uncommitted value.
   *
   * @return the uncommitted value.
   */
  float getValue() const noexcept;


  /**
   * @brief Updates the uncommitted value status.
   *
   * @param[in] pifIndex the index of the PIF analog input that generates the uncommitted value.
   * @param[in] name     of the uncommitted value.
   * @param[in] unit     of the uncommitted value.
   * @param[in] value    of the uncommitted value.
   */
  OTC_SDK_API void update(const PifIndex&    pifIndex, 
                          const std::string& name, 
                          const std::string& unit, 
                          float              value) noexcept;


private:
  /// Index of the PIF analog input that generates the uncommitted value. 
  PifIndex _index;

  /// Name of the uncommitted value.
  std::string _name;

  /// Unit of the uncommitted value.
  std::string _unit;
  
  /// The uncommitted value.
  float _value;
};


// Utility functions
/**
 * @brief Output stream operator for uncommitted value status.
 * 
 * @param[in] out    stream to use.
 * @param[in] status to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const UncommittedValueStatus& status);


// Inline implementations
inline const PifIndex& UncommittedValueStatus::getPifIndex() const noexcept
{
  return _index;
}

inline const std::string& UncommittedValueStatus::getName() const noexcept
{
  return _name;
}

inline const std::string& UncommittedValueStatus::getUnit() const noexcept
{
  return _unit;
}

inline float UncommittedValueStatus::getValue() const noexcept
{
  return _value;
}

}  // namespace optris