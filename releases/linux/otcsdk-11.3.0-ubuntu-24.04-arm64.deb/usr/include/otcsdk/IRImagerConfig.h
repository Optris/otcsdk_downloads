// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   IRImagerConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the SDK settings found in the configuration file.
 * 
 * @date 2024-12-09
 */

#pragma once

#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/Exceptions.h"
#include "otcsdk/alarms/AlarmsConfig.h"
#include "otcsdk/common/ChipHeatingMode.h"
#include "otcsdk/common/ProcessingOutputConfig.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/common/RdcMode.h"
#include "otcsdk/communication/net/IpAddress.h"
#include "otcsdk/fields/MeasurementFieldConfig.h"
#include "otcsdk/pif/PifConfig.h"


namespace optris
{

/// Holds the SDK settings found in the configuration file.
struct IRImagerConfig
{
  /// Current version of the configuration file.
  static constexpr int CURRENT_VERSION = 3;

  
  // General
  /// Version of the configuration file.
  int version = CURRENT_VERSION;
  /// Serial number of the device.
  unsigned long serialNumber = 0;


  /**
   * @brief Interface used to connect to the device (USB, Ethernet).
   * 
   * Case insensitive.
   */
  std::string connectionInterface = "usb";
  /// IP address of the device.
  IpAddress ipAddress = IpAddress{192, 168, 0, 101};
  /// Local UDP port to which the device sends data to.
  unsigned short port = 50101;
  /**
   * @brief Flag indicating whether to only process UDP packages from the IP address specified by the
   *        ipAddress member variable.
   * 
   * Set to true to activate this check or set to false to deactivate it.
   */
  bool checkIp = true;
  /**
   * @brief Specifies the time in seconds that has to elapse without no new frame received until an 
   *        connection timeout occurs.
   * 
   * If connection timeout is detected the IRImager instance will call the IRImagerClient::onConnectionTimeout()
   * callback. 
   */
  int connectionTimeout = 10;


  /**
   * @brief Specifies the number of buffers that the subsystems receiving the raw frame data should use
   *        (DirectShow, V4L2, etc.).
   * 
   * This setting has no influence on the size of the buffers. Their size is determined by the used video
   * format.
   */
  unsigned short bufferQueueSize = 5;

  /// Specifies which outputs should be computed and provided by the SDK.
  ProcessingOutputConfig processingOutputs;

  
  /**
   * @brief Sets the maximum number of processing results that are pooled for reuse to avoid unnecessary 
   *        allocations. 
   *
   * The processing pipeline reuses the same objects to store its results. This setting specifies the maximum 
   * number of these objects that are can exist at the same time. If the client callbacks handling the processing
   * results are too slow, the SDK will start to override already existing results. This effectively results in
   * frame drops.
   *
   * Buffers are only added as needed.
   *
   * If set to 0, the maximum pool size will be set to 1.
   */
  unsigned int processingMaxResultPoolSize = 10;

  /**
   * @brief Width in pixels of the output frame.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int width = 0;
  /**
   * @brief Height in pixels of the output frame.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int height = 0;
  /**
   * @brief Output framerate in Hz.
   * 
   * If width, height and framerate are all set to 0 the SDK will use the first available video format.
   */
  int framerate = 0;

  /**
   * @brief Subsampled output framerate.
   * 
   * The SDK internally reduces the output framerate to this value. This setting has no effect on the device
   * itself, meaning the device will always send frames at the rate specified by the framerate member variable.
   * 
   * Set to a value in [0, framerate] to achieve subsampling or set to a value to less than 0 to deactivate this
   * feature.
   */
  float subsampledFramerate = -1.F;


  /**
   * @brief Field of view of the optics in degree.
   * 
   * If the field of view is set to 0 and the opticsText is empty the SDK will use the first available optics.
   */
  int fieldOfView = 0;
  /**
   * @brief Optional text further specifying the used optics.
   * 
   * If the field of view is set to 0 and the opticsText is empty the SDK will use the first available optics.
   */
  std::string opticsText;

  /**
   * @brief Use Size of Source Correction if available in calibration data.
   * 
   * If true, Size of Source Correction will automatically be used if available in calibration data.
   */
  bool enableSoSCorrection = true;

  /**
   * @brief Mode of radial distortion correction (RDC).
   * 
   * The following modes are available:
   *  - Off   : Radial distortion correction will be deactivated.
   *  - Normal: Radial distortion correction will be done in normal mode.
   *  - Wide  : Radial distortion correction will be done in wide mode.
   *
   * This has only an impact if the required parameters are provided by the calibration.
   */
  RdcMode rdcMode = RdcMode::Normal;

  /**
   * @brief Lower limit of the desired temperature range in °C.
   * 
   * Always use the temperatures for the not extended range.
   * 
   * If the minimum and maximum temperature are set to 0 the SDK will use the first available temperature range.
   */
  int minTemperature = 0;
  /**
   * @brief Upper limit of the desired temperature range in °C.
   * 
   * Always use the temperatures for the not extended range.
   * 
   * If the minimum and maximum temperature are set to 0 the SDK will use the first available temperature range.
   */
  int maxTemperature = 0;

  /**
   * @brief Extends the chosen temperature range if possible.
   * 
   * When extending the temperature range you do not need to change the values for minTemperature and maxTemperature.
   * The range is always specified by the non extended temperatures.
   * 
   * @warning Extended temperature ranges are intended to help you align the field of view of your camera. The precision
   *          of the temperature measurements in this mode may not be within the specification.
   */
  bool enableExtendedTemperatureRange = false;
  /**
   * @brief Use high precision temperatures if available.
   * 
   * If true, high precision temperatures will automatically be used if the device and the chosen temperature range
   * supports them.
   */
  bool enableHighPrecisionTemperature = true;

  /**
   * @brief Enable the automatic triggering of flag cycles.
   * 
   * Optris thermal cameras feature an internal shutter flag. It need to be closed periodically for the SDK to compensate
   * for drifting temperature measurements.
   * 
   * If set to true, flag cycles will be automatically triggered when one of the temperatures measured by internal probes
   * changes by more than 0.1 °C. 
   */
  bool autoFlag = true;
  /// Minimum time in seconds that has to pass before a new flag cycle can be triggered.
  float minInterval = 12.F;
  /// Maximum time in seconds that can pass before a new flag cycle is forced.
  float maxInterval = 0.F;
  

  /// Specified how and if the sensor chip is beeing heated.
  ChipHeatingMode chipHeatingMode = ChipHeatingMode::Floating;
  /// Temperature in °C for the fixed chipHeatingMode. The provided value is clamped to [20, 55] °C.
  float chipHeatingTemperature = 40.F;


  /**
   * @brief Position of the focus motor in % ([0, 100]).
   * 
   * Should be in [0., 100.]. Set to a value less than 0 for the SDK to ignore this setting.
   */
  float focusMotorPosition = -1.F;

  /**
   * @brief Radiation parameters for the overall thermal frame.
   * 
   * For the radiation parameters of measurement fields see the MeasurementFieldConfig class.
   */
  RadiationParameters radiation;


  /**
   * @brief Activate multithreading for postprocessing.
   * 
   * @warning Experimental setting.
   */
  bool enableMultiThreading = false;


  /**
   * @brief Indicates whether a flag timeout that caused the failure of a flag cycle should trigger the fail safe.
   * 
   * A flag timeout occurs when the shutter flag does not reach its expected state within a given time frame. If this happens, the current
   * flag cycle will be considered to have failed.
   */
  bool failSafeFlagTimeouts = true;

  /**
   * @brief Specifies the number of failed flag cycles to be tolerated before fail safe is triggered due to flag timeouts.
   * 
   * @see IRImagerConfig::failSafeTriggerOnFlagTimeout
   */
  int failSafeFlagTimeoutsMaxCycleFailures = 0;

  /**
   * @brief Indicates whether a failure of the processing chain to reach all of its endpoints (thermal frame and measurement fields) within a given 
   *        time frame should trigger the fail safe.
   * 
   * If set to false, the fail safe will still be triggered when the processing chain itself crashes or gets stuck.
   */
  bool failSafeProcessingChainTimeouts = true;


  /// Alarms configuration.
  AlarmsConfig alarms;


  /// Measurement field configuration.
  std::vector<MeasurementFieldConfig> measurementFields;

  
  /// Processing interface configuration.
  PifConfig processInterface;


  /**
   * @brief Validates the configuration settings.
   * 
   * If a faulty setting can be replaced by a valid default this method will do so automatically and
   * print a log warning message. If no valid default is available a SDKException is throws instead.
   *
   * @param[in,out] config to validate.
   * 
   * @throw SDKException if configuration contains uncorrectable invalid settings.
   */
  OTC_SDK_API static void validate(IRImagerConfig& config);
};


// Utility
/**
 * @brief Output stream operator for the IRImagerConfig.
 * 
 * @param[out] out    stream to output to.
 * @param[in]  config to output.
 *
 * @return used output stream.
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const IRImagerConfig& config);

} // namespace optris
