// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   VideoFormatEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining a video format event.
 * 
 * @date 2026-03-27
 */

#pragma once


namespace optris 
{

/// Event containing information about the current video format.
struct VideoFormatEvent
{
  /// Frame width in pixels.
  int width = 0; 
  /// Frame height in pixels.
  int height = 0; 

  /// Framerate from the device in Hz (not sub-sampled).
  float framerate = 0.F;

  /// Specifies the size of the data point for an individual pixel in bits.
  int bitsPerPixel = 16;
};

} // namespace optris