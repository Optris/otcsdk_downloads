// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ConnectionEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing a connection event.
 * 
 * @date 2026-03-09
 *
 */

#pragma once

#include <string>

#include "otcsdk/common/ConnectionState.h"


namespace optris 
{

/// Represents a connection event.
struct ConnectionEvent
{
  /// Current connection state.
  ConnectionState state;

  /// Message.
  std::string msg;

  /**
   * @brief Indicates whether the SDK has permission to access the internet.
   *
   * This field has to be set by the client in response to a ConnectionState::CaliAccessInternet state to allow the 
   * SDK to access the internet to download missing calibration files.
   */
  bool accessInternet = true;

  /**
   * @brief Specifies the source directory for calibration files.
   *
   * This field has to be set by the client in response to a ConnectionState::CaliCopySourceDirectory state to specify 
   * another source directory from which the SDK should attempt to copy missing calibration files. Leave empty if no 
   * other source directory should be probed.
   */
  std::string sourceDirectory;
};

} // namespace optris