// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   OperationInfoEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining an operation info event.
 * 
 * @date 2026-03-27
 */

#pragma once

#include <vector>

#include "otcsdk/common/OperationInfo.h"


namespace optris 
{

/// Event containing trace information about the operation modules of the processing pipeline.
struct OperationInfoEvent
{
  /// Trace information about the operation modules of the processing pipeline.
  std::vector<OperationInfo> infos;
};

} // namespace optris