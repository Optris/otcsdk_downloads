// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   RawFrameEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing a raw frame event.
 * 
 * @date 2026-03-09
 *
 */

#pragma once

#include "otcsdk/common/Frame.h"
#include "otcsdk/common/FrameMetadata.h"


namespace optris
{

/// Event containing the raw unprocessed frame data and metadata.
struct RawFrameEvent
{ 
  /// Metadata.
  FrameMetadata meta;

  /// Raw frame data.
  Frame rawFrame;
};

} // namespace optris