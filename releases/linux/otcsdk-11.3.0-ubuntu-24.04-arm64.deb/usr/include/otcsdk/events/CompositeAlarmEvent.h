// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   CompositeAlarmEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining the composite alarm event.
 * 
 * @date 2026-03-27
 */

#pragma once

#include "otcsdk/alarms/CompositeAlarmStatus.h"


namespace optris 
{

/// Event containing the status of the composite alarm.
struct CompositeAlarmEvent
{
  /// Current status of the composite alarm.
  CompositeAlarmStatus status;
};

} // namespace optris