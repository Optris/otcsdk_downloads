// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FrameEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class representing a frame event.
 * 
 * @date 2026-03-09
 *
 */

#pragma once

#include <cstdint>
#include <unordered_map>

#include "otcsdk/common/ThermalFrame.h"
#include "otcsdk/common/FrameMetadata.h"
#include "otcsdk/fields/FieldStatus.h"


namespace optris
{

/// Event containing the results of the successful processing of a frame.
struct FrameEvent
{
  /**
   * @brief Metadata of the frame.
   * 
   * Is always provided.
   */
  FrameMetadata meta;

  /**
   * @brief Thermal frame.
   * 
   * The frame will be empty, if ProcessingOutputConfig::thermalFrames is set to false.
   *
   * @see ProcessingOutputConfig
   */
  ThermalFrame thermalFrame;

  /**
   * @brief The results of the measurement field processing.
   *
   * A status can be accessed via the measurement field ID.
   *
   * The map will be empty, if ProcessingOutputConfig::fields is set to false.
   *
   * @see ProcessingOutputConfig
   */
  std::unordered_map<std::int32_t, FieldStatus> fields;
};

} // namespace optris