// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   UncommittedValueEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining an uncommitted value event.
 * 
 * @date 2026-03-27
 */

#pragma once

#include "otcsdk/pif/UncommittedValueStatus.h"


namespace optris 
{

/// Event containing the uncommitted value generated from a PIF analog input.
struct UncommittedValueEvent
{
  /// Status of the uncommitted value generated from a PIF analog input.
  UncommittedValueStatus status;
};

} // namespace optris