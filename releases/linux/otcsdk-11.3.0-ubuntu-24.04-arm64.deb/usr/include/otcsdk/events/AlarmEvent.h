// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   AlarmEvent.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining an alarm event.
 * 
 * @date 2026-03-27
 */

#pragma once

#include "otcsdk/alarms/AlarmChannelStatus.h"


namespace optris 
{

/// Event containing the status of an alarm channel.
struct AlarmEvent
{
  /// Status of the alarm channel that triggered the event.
  AlarmChannelStatus status;
};

} // namespace optris