// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   FramerateCounter.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class for measuring frame rates.
 * 
 * @date 2024-12-19
 */

#pragma once

#include <memory>

#include "otcsdk/Api.h"


namespace optris
{

// Forward declarations
class Timer;
struct LinkedElement;


/**
 * @brief Measures frame rates.
 * 
 * Internally a linked list is used to average the time measurements. This list always has an even number of elements
 * to avoid aliasing effects.
 */
class FramerateCounter
{
public:
  /// Default interval in milliseconds.
  static constexpr double DEFAULT_INTERVAL = 1000.;
  /// Default smoothing size.
  static constexpr unsigned int DEFAULT_SMOOTH_SIZE = 30;


  /**
   * @brief Constructor.
   *
   * @param[in] interval   time interval in milliseconds. Can be used to check the elapsed time between two subsequent
   *                       calls of the trigger() method.
   * @param[in] smoothSize half the amount of data points used to calculate the frames per seconds. The resulting amount
   *                       is rounded up to an even number.
   */
  OTC_SDK_API FramerateCounter(double interval = DEFAULT_INTERVAL, unsigned int smoothSize = DEFAULT_SMOOTH_SIZE);

  /// No copy constructor.
  FramerateCounter(const FramerateCounter&) = delete;
  /// No copy assignment.
  FramerateCounter& operator=(const FramerateCounter&) = delete;

  /// No move constructor.
  FramerateCounter(FramerateCounter&&) = delete;
  /// No move assignment.
  FramerateCounter& operator=(FramerateCounter&&) = delete;

  /// Destructor.
  OTC_SDK_API ~FramerateCounter();


  /**
   * @brief Takes a new time measurement and updates the frames per seconds.
   *
   * @return true if more time has elapsed since the last call of this method than specified by the interval parameter
   *         of the constructor. False otherwise.
   */
  OTC_SDK_API bool trigger();

  /**
   * @brief Returns the current frames per seconds.
   *
   * @return current frames per seconds.
   */
  double getFps() const noexcept;


private:
  std::unique_ptr<Timer> _tElapsed;
  std::unique_ptr<Timer> _tPrint;

  double _fps;
  double _interval;

  struct LinkedElement* _oldest;
  struct LinkedElement* _newest;
};


// Inline implementation
inline double FramerateCounter::getFps() const noexcept
{
  return _fps;
}

} // namespace optris
