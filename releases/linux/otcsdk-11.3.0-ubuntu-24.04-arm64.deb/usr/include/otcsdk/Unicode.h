// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   Unicode.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains defines handling unicode characters.
 * 
 * @date 2024-12-04
 */

#pragma once

#include <string>


#ifdef _WIN32
  #ifndef OTC_SDK_USE_WSTRING
    /// Indicates that wide characters are used.
    #define OTC_SDK_USE_WSTRING
  #endif

  #define __STDC_WANT_LIB_EXT1__
  #define _CRT_STDIO_ISO_WIDE_SPECIFIERS
#endif


#ifdef OTC_SDK_USE_WSTRING
  /// Character type to use (system depended).
  using Tchar   = wchar_t;
  /// String type to use (system depended).
  using TString = std::wstring;

  /// Creates string literals compatible with Tchar and TString.
  #define GEN_L(ARG) L##ARG
#else
  /// Character type to use (system depended).
  using Tchar   = char;
  /// String type to use (system depended).
  using TString = std::string;

  /// Creates string literals compatible with Tchar and TString.
  #define GEN_L(ARG) ARG
#endif
