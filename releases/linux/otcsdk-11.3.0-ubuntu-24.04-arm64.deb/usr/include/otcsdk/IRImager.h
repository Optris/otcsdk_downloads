// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   IRImager.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface for all classes representing Optris thermal cameras.
 * 
 * @date 2024-12-10
 */

#pragma once

#include <memory>
#include <vector>

#include "otcsdk/Exceptions.h"
#include "otcsdk/ProcessInterface.h"
#include "otcsdk/IRImagerClient.h"
#include "otcsdk/IRImagerConfig.h"
#include "otcsdk/alarms/AlarmChannel.h"
#include "otcsdk/common/DeviceType.h"
#include "otcsdk/common/DeviceInfo.h"
#include "otcsdk/common/OperationMode.h"
#include "otcsdk/common/RadiationParameters.h"
#include "otcsdk/common/TemperaturePrecision.h"
#include "otcsdk/common/RdcMode.h"
#include "otcsdk/communication/net/DeviceNetworkConfig.h"
#include "otcsdk/fields/MeasurementField.h"


namespace optris
{

/// Interface defining the API for interacting with Optris thermal cameras.
class IRImager
{
public:
  /// Constructor.
  IRImager() = default;

  /// No copy constructor.
  IRImager(const IRImager&) = delete;
  /// No copy assignment.
  IRImager& operator=(const IRImager&) = delete;

  /// No move constructor.
  IRImager(IRImager&&) = delete;
  /// No move assignment.
  IRImager& operator=(IRImager&&) = delete;

  /// Destructor.
  virtual ~IRImager() = default;


  // Device connection
  /**
   * @brief Connects to the device with the given configuration.
   *
   * @note If the serial number in IRImagerConfig is set to 0, the SDK will use the `EnumerationManager` to find a device
   *       to connect to. 
   *       Its remaining data points will be ignored and the SDK will generate a default configuration for the detected
   *       device but without saving it.
   * 
   * @param[in] config configuration.
   *
   * @throw SDKException if connecting fails.
   */
  virtual void connect(IRImagerConfig config) = 0;

  /**
   * @brief Connects to the device with the given device information.
   * 
   * @note If the serial number is set to 0, the SDK will use the `EnumerationManager` to find a device to connect to.
   * 
   * @param[in] deviceInfo device information.
   * 
   * @throw SDKException if connecting fails.
   */
  virtual void connect(const DeviceInfo& deviceInfo) = 0;

  /**
   * @brief Connects to the device with the given serial number.
   *
   * @note If the serial number is set to 0, the SDK will use the `EnumerationManager` to find a device to connect to.
   * 
   * @param[in] serialNumber of the device.
   * 
   * @throw SDKException if connecting fails.
   */
  virtual void connect(unsigned long serialNumber) = 0;
  
  /// Disconnects from the current device.
  virtual void disconnect() noexcept = 0;

  /**
   * @brief Returns whether a connection is established.
   * 
   * @return true if a connection is established. False otherwise.
   */
  virtual bool isConnected() const noexcept = 0;


  // Client/Observer management
  /**
   * @brief Adds an observer/client that will be updated when new data arrives.
   *
   * @param[in] client callback client.
   *
   * @return true, if the client was added. False otherwise.
   */
  virtual bool addClient(IRImagerClient* client) noexcept = 0;

  /**
   * @brief Removes the given observer/client.
   * 
   * @param[in] client to remove.
   * 
   * @return true, if the client was removed. False otherwise.
   */
  virtual bool removeClient(IRImagerClient* client) noexcept = 0;


  // Processing controls
  /**
   * @brief Runs the processing loop continuously.
   * 
   * Blocks until stopRunning() or disconnect() is called from another thread or until the IRImager
   * instance is destroyed.
   *
   * @note After invoking run() it can take a very brief amount of time until isRunning() changes to true.
   *
   * @return true, if the processing loop ran successfully. False, if the processing loop is already
   *         running (e.g. in another thread) or if not connected.
   * 
   * @see stopRunning(), disconnect(), isRunning()
   */
  virtual bool run() = 0;

  /**
   * @brief Runs the processing loop continuously in a dedicated thread.
   * 
   * Runs until stopRunning() or disconnect() is called from another thread or until the IRImager
   * instance is destroyed.
   * 
   * @note All callback methods of a registered client now are called from this processing thread.
   * 
   * @return true, if the thread started within five seconds. False, if the thread did not start in time
   *         or if the processing loop is already running or if not connected.
   * 
   * @see stopRunning(), disconnect(), isRunning()
   */
  virtual bool runAsync() = 0;

  /// Stops the continuously running processing loop.
  virtual void stopRunning() = 0;

  /**
   * @brief Returns whether the processing loop is currently running.
   * 
   * @return true if the processing loop is running. False otherwise.
   */
  virtual bool isRunning() const noexcept = 0;

  /**
   * @brief Skips an active startup (re)calibration that is performed every time the processing loop is run.
   *
   * Will have not effect if a startup (re)calibration is not active.
   *
   * @attention Skipping the startup calibration may lead to inaccurate temperature measurements and 
   *            should only be used for testing and debugging purposes.
   *
   * @return true if a startup (re)calibration was skipped. False otherwise.
   */
  virtual bool skipStartupCalibration() noexcept = 0;

  /**
   * @brief Sets which outputs should be computed and provided by the SDK.
   *
   * @param[in] outputs configuration specifying which outputs should be computed and provided.
   *
   * @throws SDKException if not connected.
   */
  virtual void setProcessingOutputs(const ProcessingOutputConfig& outputs) = 0;

  /**
   * @brief Returns which outputs are currently configured to be computed and provided by the SDK.
   *
   * @return configuration specifying which outputs are currently configured to be computed and provided by the 
   *         SDK or a default configuration if not connected.
   */
  virtual ProcessingOutputConfig getProcessingOutputs() const noexcept = 0;

  /**
   * @brief Sets the maximum number of processing results that are pooled for reuse to avoid unnecessary 
   *        allocations.
   *
   * Buffers for processing results are added as needed but will not exceed the specified maximum pool size.
   * An insufficient pool size may lead to overriding of already existing results or to waits that will slow
   * down processing. Keep your callback implementations concise and fast to avoid such situation.
   *
   * @param[in] maxPoolSize maximum number of processing results that are pooled for reuse. If set to 0, the
   *                        pool size will be set to 1.
   *
   * @throw SDKException if not connected.
   */
  virtual void setProcessingMaxResultPoolSize(unsigned int maxPoolSize) = 0;

  /**
   * @brief Returns the maximum number of processing results that are pooled for reuse to avoid unnecessary
   *        allocations.
   *
   * This only returns the maximum pool size but not the actual number of currently pooled processing results.
   *
   * @return maximum number of processing results that are pooled for reuse.
   *
   */
  virtual unsigned int getProcessingMaxResultPoolSize() const noexcept = 0;


  // Device information
  /**
   * @brief Returns the type of device the IRImager is connected to.
   * 
   * @return type of device the IRImager is connected to or unknown if not connected.
   */
  virtual DeviceType getDeviceType() const = 0;

  /**
   * @brief Returns the serial number of the connected device.
   *
   * @return serial number of the connected device or 0 if not connected.
   */
  virtual unsigned long getSerialNumber() const = 0;

  /**
   * @brief Returns the hardware revision of the connected device.
   *
   * @return hardware revision number of the connected device or 0 if not connected.
   */
  virtual unsigned int getHardwareRevision() const = 0;

  /**
   * @brief Returns the firmware revision of the connected device.
   *
   * @return firmware revision number of the connected device or 0 if not connected.
   */
  virtual unsigned int getFirmwareRevision() const = 0;


  // Configuration
  /**
   * @brief Returns the current configuration.
   *
   * @return current configuration.
   *
   * @throw SDKException if not connected.
   */
  virtual IRImagerConfig getConfig() = 0;

  /**
   * @brief Saves the current configuration.
   *
   * The configuration is saved to the default location on the filesystem.
   *
   * @throw SDKException if not connected or if saving the configuration fails.
   */
  virtual void saveConfig() = 0;

  
  // Connection details
  /**
   * @brief Returns the name of the connection interface used to communication with the device.
   * 
   * @return name of the connection interface used to communication with the device or an empty
   *         string if not connected.
   */
  virtual std::string getConnectionInterface() const noexcept = 0;

  /**
   * @brief Returns the IP address of the connected device.
   * 
   * @note The returned value is only relevant when connected to an Ethernet device.
   *
   * @return IP address of the connected device or 192.168.0.101 if not connected. 
   */
  virtual IpAddress getIpAddress() const noexcept = 0;

  /**
   * @brief Returns the number of the port on which the device data is received.
   * 
   * @note The returned value is only relevant when connected to an Ethernet device.
   *
   * @return number of the port on which the device data is received or 50101 if not connected.
   */
  virtual Port getPort() const noexcept = 0;


  // Operation modes
  /**
   * @brief Returns the operation modes for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * The returned container is always sorted in an ascending order based on the optics, temperature range
   * and video format properties.
   *
   * With OperationMode::getIndex() you can conveniently inquire a mode for its index within the returned
   * container.
   * 
   * @return operation modes for the currently connected device.
   * 
   * @throw SDKException if not connected.
   *
   * @see OperationMode::getIndex()
   */
  virtual std::vector<OperationMode::ConstShared> getOperationModes() = 0;

  /**
   * @brief Sets the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * @param[in] mode to set active.
   *
   * @throw SDKException if not connected, if mode is not supported by device or if applying the mode fails.
   */
  virtual void setActiveOperationMode(const OperationMode::ConstShared& mode) = 0;

  /**
   * @brief Sets the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   * 
   * @note You can use "wildcards", if you do not want to specify the optics, temperature range or video format
   *       explicitly:
   *       - optics           : set opticsFieldOfView to 0 AND leave opticsText empty.
   *       - temperature range: set temperatureLowerLimit AND temperatureUpperLimit to 0.
   *       - video format     : set width, height AND framerate to 0.
   * 
   * @param[in] opticsFieldOfView      in degrees.
   * @param[in] opticsText             further specifying the optics if the field of view is not unique enough.
   * @param[in] temperatureLowerLimit  in degree Celsius (not extended).
   * @param[in] temperatureUpperLimit  in degree Celsius (not extended).
   * @param[in] width                  in pixel of the output frame.
   * @param[in] height                 in pixel of the output frame.
   * @param[in] framerate              in Hz (not sub-sampled).
   *
   * @throw SDKException SDKException if not connected, if mode is not supported by device or if applying the mode fails.
   */
  virtual void setActiveOperationMode(int                opticsFieldOfView, 
                                      const std::string& opticsText, 
                                      float              temperatureLowerLimit,
                                      float              temperatureUpperLimit, 
                                      int                width,
                                      int                height,
                                      int                framerate) = 0;

  /**
   * @brief Returns the active operation mode for the currently connected device.
   * 
   * Each operation mode holds a valid combination of optics, temperature range and video format settings
   * for the currently connected device.
   *
   * @return active operation mode for the currently connected device.
   *
   * @throw SDKException if not connected.
   */
  virtual OperationMode::ConstShared getActiveOperationMode() = 0;


  // Optics options
  /**
   * @brief Enables or disables the Size of Source Correction.
   *
   * @param[in] enable indicates whether to enable or disable the Size of Source Correction.
   *
   * @throw SDKException if not connected.
   */
  virtual void setSoSCorrectionEnabled(bool enable) = 0;

  /**
   * @brief Checks if the Size of Source Correction is enabled.
   *
   * @return true if the Size of Source Correction is enabled. False if disabled or if not connected.
   */
  virtual bool isSoSCorrectionEnabled() const noexcept = 0;

  /**
   * @brief Sets the mode of radial distortion correction (RDC).
   * 
   * @note This method is only relevant for devices and operation modes that feature a significant radial distortion and support RDC.
   *
   * @param[in] rdcMode the RDC mode to set.
   *
   * @throw SDKException if not connected or if setting the RDC mode fails.
   */
  virtual void setRdcMode(RdcMode rdcMode) = 0;

  /**
   * @brief Returns the mode of radial distortion correction (RDC).
   * 
   * @note This method is only relevant for devices and operation modes that feature a significant radial distortion and support RDC.
   *
   * @return the current RDC mode.
   *
   * @throw SDKException if not connected or if retrieving the RDC mode fails.
   */
  virtual RdcMode getRdcMode() const = 0;
  
  
  // Temperature range options
  /**
   * @brief Die-/Enables temperature range extension.
   *
   * @attention Extended temperature ranges feature poor precision and should not be used for measurements. 
   *            The main purpose of this feature is to give users an easier time to physically align the 
   *            field of view of the device when a temperature range has a high lower limit.
   * 
   * @note Not all temperature ranges can be extended.
   *
   * @param[in] enabled if true temperature range extension is enabled.
   *
   * @throws SDKException if setting enabled failed or if not connected.
   */
  virtual void setTemperatureRangeExtensionEnabled(bool enabled) = 0;
  
  /**
   * @brief Returns whether the temperature ranges are being extended.
   * 
   * @note Not all temperature ranges can be extended.
   * 
   * @return true, if the temperature ranges are being extended. False, otherwise or if not connected.
   * 
   * @see OperationMode::isTemperatureRangeExtended(),
   *      OperationMode::isTemperatureRangeExtendable()
   */
  virtual bool isTemperatureRangeExtensionEnabled() const noexcept = 0;

  /**
   * @brief Dis-/Enables high precision temperature measurements.
   * 
   * @note Not all temperature ranges on all devices feature high precision temperature measurements.
   *
   * @param[in] enabled if true high temperature measurements are enabled.
   *
   * @throws SDKException if setting enabled failed or if not connected.
   */
  virtual void setTemperatureHighPrecisionEnabled(bool enabled) = 0;

  /**
   * @brief Returns whether high precision temperature measurements are enabled.
   * 
   * @note Not all temperature ranges on all devices feature high precision temperature measurements.
   * 
   * @return true, if high precision temperature measurements are enabled. False, otherwise or if
   *         not connected.
   * 
   * @see OperationMode::isTemperatureHighPrecision(),
   *      OperationMode::isTemperatureHighPrecisionAvailable()
   */
  virtual bool isTemperatureHighPrecisionEnabled() const noexcept = 0;


  // Video format
  /**
   * @brief Returns the width in pixels of the thermal frame.
   *
   * @return width in pixels of the thermal frame, i.e. number of columns or 0 if not connected.
   */
  virtual int getWidth() const noexcept = 0;

  /**
   * @brief Returns the height in pixels of thermal frame.
   *
   * @return height in pixels of the thermal frame, i.e. number of rows or 0 if not connected.
   */
  virtual int getHeight() const noexcept = 0;

  /**
   * @brief Returns the subsampled framerate.
   * 
   * @return the subsampled framerate or a value <= 0 if not connected or if no subsampling is
   *         performed. 
   */
  virtual float getSubsampledFramerate() const noexcept = 0;

  /**
   * @brief Sets the subsampled framerate.
   *
   * @note The subsampling is performed by the SDK. The subsampled framerate has no effect on the
   *       framerate with which the devices send frame data.
   * 
   * @param[in] subsampledFramerate to set. Provide a value less or equal to 0 to deactivate 
   *                                subsampling. If the value is higher than the framerate
   *                                of the currently active operation mode, no subsampling will
   *                                occur.
   *
   * @throws SDKException if not connected.
   */
  virtual void setSubsampledFramerate(float subsampledFramerate) = 0;


  // Measurement fields
  /**
   * @brief Adds a measurement field that is processed for every new thermal frame.
   *
   * The newly added measurement field will always be drawn on top of the already existing measurement fields.
   * The thermal frame will remain in the background. IRImagerClient::onMeasurementFieldAdded() is called when
   * the field was updated with new thermal data.
   *
   * @param[in] config of the measurement field to add.
   *
   * @return smart pointer to the added measurement field.
   *
   * @throw SDKException if not connected or if the measurement field is not completely within the 
   *                     thermal frame or if adding it failed.
   */
  virtual MeasurementField::ConstShared addMeasurementField(const MeasurementFieldConfig& config) = 0;

  /**
   * @brief Removes the given measurement field.
   * 
   * The measurement field instance is only destroyed when the smart pointer field is released.
   *
   * The ID of the removed measurement field is set to the invalid value of `-1` to indicate its
   * successful removal.
   *
   * @attention Removing a measurement field can have the following consequences:
   *            - PIF analog output channels using the field turn themselves off automatically.
   *            - Alarm channel using the field turn orphaned and are subsequently removed.
   *
   * @param[in] field to remove.
   *
   * @throw SDKException if not connected or if the measurement field does not exist for this imager
   *                     instance.
   */
  virtual void removeMeasurementField(const MeasurementField::ConstShared& field) = 0;

  /**
   * @brief Returns all active measurement fields ordered by their index.
   * 
   * The measurement fields are ordered by their render tier. Fields with a higher index are drawn on top 
   * of fields with a lower index.
   *
   * @return All active measurement fields ordered by their index or an empty container if not connected.
   */
  virtual std::vector<MeasurementField::ConstShared> getMeasurementFields() const noexcept = 0;

  /**
   * @brief Returns the number of active measurement fields.
   * 
   * @return number of active measurement fields or 0 if not connected. 
   */
  virtual int getMeasurementFieldCount() const noexcept = 0;

  /**
   * @brief Updated the configuration of a measurement field.
   * 
   * @param[in] field  to update.
   * @param[in] config to update the measurement field with.
   *
   * @throw SDKException if not connected, if the measurement field does not exist for this imager or the configuration
   *                     cannot be applied.
   */
  virtual void updateMeasurementField(const MeasurementField::ConstShared& field, const MeasurementFieldConfig& config) = 0;

  /**
   * @brief Swaps the indices of two measurement fields.
   *
   * The measurement field indices determine the render tier of the measurement fields. Fields with a higher index are
   * drawn on top of fields with a lower index. The thermal frame is always in the background.
   *
   * @param[in] index1 first index to swap.
   * @param[in] index2 second index to swap.
   *
   * @throw SDKException if not connected, if the indices do not exist or if the provided indices are identical.
   */
  virtual void swapMeasurementFieldIndices(std::uint32_t index1, std::uint32_t index2) = 0;
 

  // Alarms
  /**
   * @brief Adds a new alarm channel.
   *
   * @param[in] config of the new alarm channel to add.
   *
   * @return smart pointer to the added alarm channel.
   *
   * @throw SDKException if not connected or if adding the channel failed.
   */
  virtual AlarmChannel::ConstShared addAlarmChannel(const AlarmChannelConfig& config) = 0;

  /**
   * @brief Removes the given alarm channel.
   *
   * The alarm channel instance is only destroyed when the smart pointer alarm is released.
   *
   * The ID of the removed alarm channel is set to the invalid value of `-1` to indicate its
   * successful removal.
   * 
   * @param[in] channel to remove.
   *
   * @throw SDKException if not connected or if the given alarm channel does not exist for this imager instance.
   */
  virtual void removeAlarmChannel(const AlarmChannel::ConstShared& channel) = 0;

  /**
   * @brief Returns all current alarm channels.
   *
   * They are sorted based on their IDs.
   *
   * @return all current alarm channels or an empty container if not connected.
   */
  virtual std::vector<AlarmChannel::ConstShared> getAlarmChannels() const noexcept = 0;

  /**
   * @brief Returns the status of all current alarm channels.
   *
   * They are sorted based on the ID of the corresponding alarm channel.
   *
   * @return status of all current alarm channels or an empty container if not connected.
   */
  virtual std::vector<AlarmChannelStatus> getAlarmChannelStatuses() const noexcept = 0;

  /**
   * @brief Returns the count of all current alarm channels.
   *
   * @return count of all current alarm channels.
   */
  virtual int getAlarmChannelCount() const noexcept = 0;

  /**
   * @brief Updates the configuration of an alarm channel.
   *
   * @param[in] channel to update.
   * @param[in] config  to update the alarm channel with.
   */
  virtual void updateAlarmChannel(const AlarmChannel::ConstShared& channel, const AlarmChannelConfig& config) = 0;


  // Shutter flag
  /**
   * @brief Sets the automatic triggering of flag cycles en-/disabled.
   *
   * @param[in] enable or disable automatic triggering of flag cycles.
   *
   * @throw SDKException if not connected.
   */
  virtual void setAutoFlagEnabled(bool enable) = 0;

  /**
   * @brief Returns whether flag cycles are triggered automatically.
   *
   * @return true, if flag cycles are triggered automatically. False is automatic triggering is diabled or if not connected.
   */
  virtual bool isAutoFlagEnabled() const noexcept = 0;

  /**
   * @brief Sets the minimum and maximum flag intervals in seconds.
   *
   * @param[in] minInterval minimal time in seconds that has to elapse before a new flag cycle is triggered.
   * @param[in] maxInterval maximum time in seconds that can elapse until a new flag cycle is triggered. Set to 0 to
   *                        deactivate.
   *
   * @throw SDKException if provided intervals are negative or not connected.
   */
  virtual void setFlagInterval(float minInterval, float maxInterval) = 0;

  /**
   * @brief Returns the minimum flag interval in seconds.
   * 
   * Minimum time that has to elapse before a new flag cycle is triggered.
   *
   * @return minimum flag interval in seconds or 0 if not connected.
   */
  virtual float getFlagMinInterval() const noexcept = 0;

  /**
   * @brief Returns the maximum flag interval in seconds.
   *
   * Maximum time that can elapse before a new flag cycle is triggered.
   * 
   * @return maximum flag interval in seconds or 0 if not connected.
   */
  virtual float getFlagMaxInterval() const noexcept = 0;

  /**
   * @brief Force a flag cycle manually.
   *
   * @param[in] time point of time in future in milliseconds, when the shutter flag should be closed.
   *
   * @throw SDKException if not connected.
   */
  virtual void forceFlagEvent(float time = 0.F) = 0;

  /**
   * @brief Returns whether the shutter flag is open.
   *
   * @return true if the shutter flag is open. False if the shutter flag is closed or if not
   *         connected.
   */
  virtual bool isFlagOpen() const noexcept = 0;

  /**
   * @brief Set the shutter flag forecast en-/disabled.
   *
   * @param enable of disable the shutter flag forecast.
   *
   * @throw SDKException if not connected.
   */
  virtual void setFlagForecastEnabled(bool enable) = 0;

  /**
   * @brief Returns whether the shutter flag forecast is en-/disabled.
   *
   * @return true if the shutter flag forecast is enabled. False if flag forecast is disabled or if not
   *         connected.
   */
  virtual bool isFlagForecastEnabled() const noexcept = 0;


  // Internal temperature probes
  /**
   * @brief Returns the temperature of the shutter flag in °C.
   *
   * @return temperature of the shutter flag in °C or INVALID_TEMPERATURE if not connected or
   *         35.0 °C if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureFlag() const noexcept = 0;

  /**
   * @brief Returns the temperature of the device housing in °C.
   *
   * @return temperature of the device housing in °C or INVALID_TEMPERATURE if not connected or 35.0 °C
   *         if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureBox() const noexcept = 0;

  /**
   * @brief Returns the temperature of the sensor chip.
   *
   * @return temperature of the sensor chip in °C or INVALID_TEMPERATURE if not connected or
   *         35.0 °C if connected but processing has not yet started (s. run() and runAsync()).
   */
  virtual float getTemperatureChip() const noexcept = 0;


  // Sensor chip heating
  /**
   * @brief Sets the provide mode for heating the sensor chip.
   *
   * @param[in] mode        indicating the heating mode.
   * @param[in] temperature target temperature for fixed mode in °C. Its value is automatically clamped 
   *                        to [20., 55.] °C.
   *
   * @throw SDKException if not connected.
   */
  virtual void setChipHeatingMode(ChipHeatingMode mode, float temperature = 40.F) = 0;

  /**
   * @brief Returns the current sensor chip heating mode.
   *
   * @return current sensor chip heating mode or ChipHeatingMode::Floating if not connected.
   */
  virtual ChipHeatingMode getChipHeatingMode() const noexcept = 0;

  /**
   * @brief Returns the the target temperature in °C for the sensor chip heating.
   *
   * @note The actual sensor chip temperature can be accessed with IRImager::getTemperatureChip().
   *
   * @return target temperature in °C for the sensor chip heating or INVALID_TEMPERATURE if not connected or
   *         if the heating mode is not fixed.
   */
  virtual float getChipHeatingTemperature() const noexcept = 0;


  // Radiation parameters
  /**
   * @brief Returns the source that currently defines the emissivity for the thermal frame.
   * 
   * @return source that currently defines the emissivity for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getEmissivitySource() const noexcept = 0;

  /**
   * @brief Returns the source that currently defines the transmissivity for the thermal frame.
   * 
   * @return source that currently defines the transmissivity for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getTransmissivitySource() const noexcept = 0;

  /**
   * @brief Returns the source that currently defines the ambient temperature for the thermal frame.
   * 
   * @return source that currently defines the ambient temperature for the thermal frame or
   *         RadiationParameterSource::Sdk if not connected.
   */
  virtual RadiationParameterSource getAmbientTemperatureSource() const noexcept = 0;

  /**
   * @brief Sets the radiation parameters (emissivity, transmissivity and ambient temperature).
   *
   * @param[in] radiation parameters to set.
   *
   * @throw SDKException if not connected or if parameters are invalid or if setting the parameters fails.
   */
  virtual void setRadiationParameters(const RadiationParameters& radiation) = 0;

  /**
   * @brief Returns the set/configured radiation parameters.
   *
   * @attention The radiation parameters may be modified via the process interface (PIF) and through automated
   *            ambient temperature estimations. This method return the parameters set in the configuration
   *            or vis IRImager::setRadiationParameters().
   *
   *            To get the actually applied parameters see the FrameMetadata::getRadiationParameters() for the
   *            thermal frame and the MeasurementField::getRadiationParameters() for measurement fields.
   *
   * @return the set/configured radiation parameters or their default values if not connected.
   */
  virtual RadiationParameters getRadiationParameters() const noexcept = 0;

  
  // Focus motor
  /**
   * @brief Sets the position of the focus motor.
   *
   * The position should be in [0, 100] %. If not, the position will automatically be clipped.
   *
   * @param[in] position focus motor position in %.
   *
   * @throw SDKException if not connected or if no focus motor is available.
   */
  virtual void setFocusMotorPosition(float position) = 0;

  /**
   * @brief Returns the position of the focus motor.
   *
   * @return focus motor position in % or -1.0 if not connected or if no focus motor is available.
   */
  virtual float getFocusMotorPosition() const = 0;


  // Reference temperature
  /**
   * @brief Sets a reference temperature to a known reference source inside the view of the device to improve measurement accuracy.
   *
   * @param[in] referenceTemperature real temperature of reference source.
   * @param[in] measuredTemperature  measured temperature from the device of reference source.
   * @param[in] ambientTemperature   in °C. Set it to INVALID_TEMPERATURE or less to force the SDK to estimate the
   *                                 ambient temperature based on thermal probe readings of the device.
   *
   * @throw SDKException if not connected.
   */
  virtual void setReferenceTemperature(float referenceTemperature, float measuredTemperature, float ambientTemperature = INVALID_TEMPERATURE) = 0;

  /**
   * @brief Resets a previously set reference temperature.
   * 
   * @throw SDKException if not connected.
   */
  virtual void resetReferenceTemperature() = 0;


  // Device network configuration
  /**
   * @brief Sets the network configuration of the device.
   * 
   * The SDK tries to retain an active Ethernet connection. This, however, is only possible if the following
   * settings were changed:
   *
   * - device IP address
   * - destination port
   *
   * In any other case the SDK considers the connection lost and triggers the IRImagerClient::onConnectionLost()
   * callback which a client should use to call disconnect().
   *
   * @param[in] networkConfig to set.
   * 
   * @throw SDKException if not connected of if the device does not support Ethernet or if setting the device network 
   *                     configuration failed.
   *
   * @return true, if the device connection was retained. False otherwise.
   *
   * @see IRImagerClient::onConnectionLost()
   */
  virtual bool setDeviceNetworkConfig(const DeviceNetworkConfig& networkConfig) = 0;

  /**
   * @brief Returns the network configuration of the device.
   * 
   * @return network configuration of the device.
   * 
   * @throw SDKException if not connected of if the device does not support Ethernet or if getting the device network 
   *                     configuration failed.
   */
  virtual DeviceNetworkConfig getDeviceNetworkConfig() = 0;


  // Process Interface
  /**
   * @brief Grants access to the process interface.
   * 
   * @warning The reference becomes invalid on disconnects.
   * 
   * @return reference to the process interface.
   * 
   * @throw SDKException if not connected.
   */
  virtual ProcessInterface& getPif() = 0;

  /**
   * @brief Grants read access to the process interface.
   * 
   * @warning The reference becomes invalid on disconnects.
   * 
   * @return constant reference to the process interface.
   * 
   * @throw SDKException if not connected.
   */
  virtual const ProcessInterface& getPif() const = 0;


  // Fail safe
  /**
   * @brief Interrups the all clear fail safe signal.
   * 
   * @note The client is only one source that can trigger the fail safe. If any of these sources detects an error, the fail safe
   *       will be triggered and it will only be released, if ALL the sources report an all clear.
   * 
   * @param[in] active if true the all clear signal is interrupted. If false, the all clear may be restored, if all other sources
   *                   report an all clear.
   * @param[in] reason to be displayed in the logs.
   * 
   * @throw SDKException if not connected.
   */
  virtual void interruptFailSafe(bool active, const std::string& reason) = 0;
  

  // Debugging
  /**
   * @brief Configure the tracing of the operation modules that comprise the processing pipeline.
   * 
   * @param[in] interval desired time in ms between subsequent updates. Set to 0 to deactivate tracing. 
   * @param[in] x        coordinate of a pixel whose value should be traced through processing.
   * @param[in] y        coordinate of a pixel whose value should be traced through processing.
   * 
   * @throw SDKException if not connected or if the pixel coordinates lie outside the frame.
   * 
   * @see IRImagerClient::onOperationInfo()
   */
  virtual void configureOperationInfo(int interval, int x, int y) = 0;
};

} // namespace optris