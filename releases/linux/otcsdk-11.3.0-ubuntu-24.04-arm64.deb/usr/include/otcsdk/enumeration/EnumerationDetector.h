// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   EnumerationDetector.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface definition for classes detecting available devices.
 * 
 * @date 2025-03-14
 */

#pragma once

#include <vector>

#include "otcsdk/common/DeviceInfo.h"


namespace optris 
{

/// Common interface for classes detecting available devices.
class EnumerationDetector
{
public:
  /// Constructor.
  EnumerationDetector() = default;

  /// No copy constructor.
  EnumerationDetector(const EnumerationDetector&) = delete;
  /// No copy assignment.
  EnumerationDetector& operator=(const EnumerationDetector&) = delete;

  /// Move constructor.
  EnumerationDetector(EnumerationDetector&&) = delete;
  /// Move assignment.
  EnumerationDetector& operator=(EnumerationDetector&&) = delete;
    
  /// Destructor.
  virtual ~EnumerationDetector() = default;


  /**
   * @brief Detects available devices.
   * 
   * @param[out] devices vector containing the already detected devices for this detector
   *                     to add its own detections to it.
   */
  virtual void detectDevices(std::vector<DeviceInfo>& devices) noexcept = 0;
};

} // namespace optris