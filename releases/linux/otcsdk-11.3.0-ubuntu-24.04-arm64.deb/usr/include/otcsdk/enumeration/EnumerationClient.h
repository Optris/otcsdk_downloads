// Copyright (c) 2008-2026 Optris GmbH & Co. KG
 
 /**
  * @file   EnumerationClient.h
  * @author Optris GmbH & Co. KG
  * @brief  Contains the base class for all clients observing the EnumerationManager.
  * 
  * @date 2024-09-23
  */

#pragma once

#include "otcsdk/common/DeviceInfo.h"


namespace optris
{

/// Base class for all clients observing the EnumerationManager.
class EnumerationClient
{
public:
  /// Constructor.
  EnumerationClient() = default;

  /// No copy constructor.
  EnumerationClient(const EnumerationClient&) = default;
  /// No copy assignment.
  EnumerationClient& operator=(const EnumerationClient&) = default;

  /// Move constructor.
  EnumerationClient(EnumerationClient&&) = default;
  /// Move assignment.
  EnumerationClient& operator=(EnumerationClient&&) = default;
    
  /// Destructor.
  virtual ~EnumerationClient() = default;


  /**
   * @brief Callback function triggered when a new available device is detected.
   *
   * @param[in] deviceInfo information of the device.
   */
  virtual void onDeviceDetected(DeviceInfo deviceInfo) noexcept
  { }

  /**
   * @brief Callback function triggered when a previously detected available device is no longer detected.
   *
   * @param[in] deviceInfo information of the device.
   */
  virtual void onDeviceDetectionLost(DeviceInfo deviceInfo) noexcept
  { }
  
  /**
   * @brief Callback function triggered when a previously detected available device changed its configuration.
   *
   * @param[in] deviceInfo information of the device.
   */
  virtual void onDeviceDetectionChanged(DeviceInfo deviceInfo) noexcept
  { }
};

} // namespace optris