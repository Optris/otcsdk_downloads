// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ImageBuilder.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class that converts thermal frames into false color images.
 * 
 * @date 2024-12-19
 */

#pragma once

#include <array>
#include <cstdint>
#include <vector>
#include <string>

#include "otcsdk/Api.h"

#include "otcsdk/common/ThermalFrame.h"
#include "otcsdk/common/Image.h"


namespace optris
{

/**
 * @brief Characterizes a rectangular region by the indexes of the upper left and the lower right corners
 *        along with an associated temperature.
 * 
 * Note that the origin of coordinates is located in upper left corner with the x-axis pointing right and
 * the y-axis pointing downwards.
 * 
 *  +---> x
 *  |
 *  v     1-----------+
 *  y     |           |
 *        |           |
 *        +-----------2
 *  
 *  => x1 <= x2 & y1 <= y2
 */
struct OTC_SDK_API TemperatureRegion
{
  /// Constructor.
  TemperatureRegion() noexcept;

  /**
   * @brief Constructor.
   * 
   * @param[in] x1 x index of the upper left corner.
   * @param[in] y1 y index of the upper left corner.
   * @param[in] x2 x index of the lower right corner.
   * @param[in] y2 y index of the lower right corner. 
   */
  TemperatureRegion(int x1, int y1, int x2, int y2) noexcept;

  /// Resets the temperature and the coordinates of the corners.
  void reset() noexcept;

  /**
   * @brief Returns whether the region fits within a rectangle of the given dimensions.
   *
   * @param[in] width   in pixels of the rectangle to fit the region in.
   * @param[in] height  in pixels of the rectangle to fit the region in.
   * @param[in] padding in pixels applied to the region in all directions during the check.
   * 
   * @return true if the region fits in the given rectangle. False otherwise.
   */
  bool fitsInRectangle(int width, int height, int padding = 0) const noexcept;


  /// Associated temperature in °C.
  float temperature;

  /// X index of the upper left corner.
  int x1;
  /// Y index of the upper left corner.
  int y1;

  /// X index of the lower right corner.
  int x2;
  /// Y index of the lower right corner.
  int y2;
};


/// Helper struct for calculating an integral image.
struct IntegralPixel
{
  /// Summed up valid pixel values.
  std::uint64_t value = 0;
  /// Number of valid pixels summed up.
  std::uint32_t count = 0;
};



/// Represents the different mode to scale temperatures when generating a false color image.
enum class TemperatureScalingMode
{
  Manual,  ///< User-defined upper and lower limit (fixed values).
  MinMax,  ///< Dynamic determination of minimum and maximum temperature as upper and lower limit.
  Sigma1,  ///< Dynamic determination of upper and lower limit from standard deviation of temperature image.
  Sigma3,  ///< Same as Sigma1, but with factor 3.
};


/// Creates false color images from thermal frames.
class ImageBuilder
{
public:
  /// Type for look up tables.
  using LookupTable = std::array<unsigned int, 65536>;


  /**
   * @brief Constructor.
   * 
   * Be mindful of which color format and width alignment you choose. Please refer to the documentation of the
   * enums for more details.
   *
   * @param[in] colorFormat    for the generated false color image.
   * @param[in] widthAlignment for the generated false color image.
   */
  OTC_SDK_API ImageBuilder(ColorFormat colorFormat, WidthAlignment widthAlignment);


  /**
   * @brief Sets a new thermal frame.
   *
   * The provide frame will be copied to an internal buffer.
   * 
   * @param[in] thermalFrame data.
   */
  OTC_SDK_API void setThermalFrame(const ThermalFrame& thermalFrame);

  /**
   * @brief Grants read access to the stored thermal frame.
   * 
   * @return const reference to the stored thermal frame.
   */
  const ThermalFrame& getThermalFrame() const noexcept;

  /**
   * @brief Returns the width in pixels of the thermal frame.
   *  
   * @return width in pixels of the thermal frame.
   */
  int getWidth() const noexcept;

  /**
   * @brief Returns the height in pixels of thermal frame.
   *
   * @return height in pixels of thermal frame.
   */
  int getHeight() const noexcept;

  /**
   * @brief Returns the temperature the from last acquired image at specified pixel index.
   *
   * @param[in] index pixel index.
   *
   * @return temperature in °C.
   *
   * @throw SDKException if index is out of range.
   */
  OTC_SDK_API float getTemperature(int index) const;

  /**
   * @brief Returns the temperature from last acquired image at specified pixel coordinates.
   *
   * The origin of coordinates is located in the upper left corner with the x-axis pointing right and
   * the y-axis pointing downwards.
   * 
   * @param[in] x coordinates.
   * @param[in] y coordinates.
   *
   * @return temperature in °C.
   *
   * @throw SDKException if coordinates are out of range.
   */
  OTC_SDK_API float getTemperature(int x, int y) const;

  /**
   * @brief Returns the mean temperature in °C of a rectangular region.
   *
   * Before providing the region to this method you have to define the rectangular area it covers by
   * specifying its upper left and lower right corners.
   * 
   * @param[out] meanRegion in which to calculate the mean temperature.
   *
   * @return true if a mean temperature could be calculated. False if no thermal data is available or
   *         if the region coordinates are inconstent or if the region is too large for the frame.
   */
  OTC_SDK_API bool getMeanTemperatureInRegion(TemperatureRegion& meanRegion);

  /**
   * @brief Returns the region of minimum/maximum temperature in °C with the given radius.
   *
   * The method will fill in all the data for the min and max temperature region.
   * 
   * @param[in]  radius    radius of the region.
   * @param[out] minRegion region of minimum mean temperature.
   * @param[out] maxRegion region of maximum mean temperature.
   *
   * @return true if minimum/maximum temperature could be calculated. False if no thermal data is available
   *         or if the radius is to large for the frame.
   */
  OTC_SDK_API bool getMinMaxRegions(int radius, TemperatureRegion& minRegion, TemperatureRegion& maxRegion);


  // Image conversion
  /**
   * @brief Sets the temperature range for the manual scaling mode.
   *
   * @attention If the scaling mode is not set to manual the set values will be overriden once the next image
   *            conversion is triggered.
   *
   * @param[in] min lower limit in °C.
   * @param[in] max upper limit in °C.
   *
   * @throw SDKException if the provided temperatures are invalid or if max is not at least 1°C higher than min.
   */
  OTC_SDK_API void setTemperatureScaling(float min, float max);

  /**
   * @brief Returns the minimum temperature used to scale the image.
   *
   * @return temperature in °C.
   */
  OTC_SDK_API float getTemperatureScalingMin() const noexcept;

  /**
   * @brief Returns the maximum temperature used to scale the image.
   *
   * @return temperature in °C.
   */
  OTC_SDK_API float getTemperatureScalingMax() const noexcept;

  /**
   * @brief Returns the filtered minimum temperature actually used by the most recent
   *        frame's palette rendering.
   *
   * For the auto-scaling modes this lags #getTemperatureScalingMin() by the hysteresis
   * filter (see #setTemperatureScalingFilterFactor); in Manual mode both return the
   * same value because #setTemperatureScaling resets the filter.
   *
   * @return temperature in °C.
   */
  OTC_SDK_API float getTemperatureScalingMinFiltered() const noexcept;

  /**
   * @brief Returns the filtered maximum temperature actually used by the most recent
   *        frame's palette rendering. See #getTemperatureScalingMinFiltered().
   *
   * @return temperature in °C.
   */
  OTC_SDK_API float getTemperatureScalingMaxFiltered() const noexcept;

  /**
   * @brief Sets the low pass filter factor for the temperature scaling for smooth transitions.
   *
   * @attention The filtering only affects decreasing maximum values and increasing minimum values. Increasing maximum 
   *            values and decreasing minimum values are instantly updated to prevent saturation.
   *
   * @param[in] filterFactor low pass filter factor in the interval [0.0, 1.0]. The default value is 0.96 and the value
   *                         0.0 disables the filter.
   *
   * @throw SDKException if the provided filter factor is out of bounds.
   */
  OTC_SDK_API void setTemperatureScalingFilterFactor(float filterFactor);

  /**
   * @brief Returns the low pass filter factor for the temperature scaling method.
   *
   * @return low pass filter factor.
   */
  OTC_SDK_API float getTemperatureScalingFilterFactor() const noexcept;

  /**
   * @brief Sets the temperature scaling mode for the false color conversion.
   *
   * @param[in] mode temperature scaling mode.
   */
  void setTemperatureScalingMode(TemperatureScalingMode mode) noexcept;

  /**
   * @brief Returns the current temperate scaling mode for the false color conversion.
   *
   * @return temperature scaling mode.
   */
  TemperatureScalingMode getTemperatureScalingMode() const noexcept;

  /**
   * @brief Sets the palette for the false color conversion by name.
   *
   * If palettes have not been loaded yet, this triggers Sdk::loadPalettes() automatically.
   * The palette data is copied into the ImageBuilder — subsequent registry changes do not
   * affect an already constructed ImageBuilder.
   *
   * @param[in] name palette name (case-sensitive, e.g. "Iron").
   *
   * @throw SDKException if the named palette cannot be found even after auto-loading.
   */
  OTC_SDK_API void setPalette(const std::string& name);

  /**
   * @brief Returns the name of the currently active palette.
   *
   * @return palette name string.
   */
  OTC_SDK_API std::string getPaletteName() const noexcept;

  /**
   * @brief Grants read access to the generated false color image.
   * 
   * @return const reference to the generated false color image.
   */
  const Image& getImage() noexcept;

  /**
   * @brief Returns the image size in bytes including potential width padding.
   * 
   * @return image size in bytes including potential width padding.
   */
  int getImageSizeInBytes() const noexcept;

  /**
   * @brief Returns the image stride in bytes.
   * 
   * The stride is the image width in bytes including potential padding.
   * 
   * @return image stride in bytes.
   */
  int getImageStride() const noexcept;

  /**
   * @brief Copies the false color image data to the given destination array.
   * 
   * @param[out] destination array to copy the false color image data to.
   * @param[in]  size        in bytes. The specified size is limited to [0, image size in bytes].
   */
  OTC_SDK_API void copyImageDataTo(unsigned char* destination, int size) const noexcept;
  
  /**
   * @brief Creates a lookup table for the false color conversion.
   *
   * @return lookup table.
   */
  OTC_SDK_API LookupTable createLookupTable();


  /// Triggers the image conversion.
  OTC_SDK_API void convertTemperatureToPaletteImage();

  /**
   * @brief Image conversion to RBG with lookup table. This method is efficient, but works only with fixed temperature ranges (manual mode).
   *
   * @param[in] lut lookup table.
   */
  OTC_SDK_API void convertTemperatureToPaletteImage(const LookupTable& lut);

  /**
   * @brief Converts thermal data to a false color image, writing output to an external buffer.
   *
   * The external buffer must be at least getImageSizeInBytes() bytes and have the same
   * stride as getImageStride(). The internal Image member is NOT updated or allocated.
   *
   * @param[out] destination pointer to the output buffer.
   * @param[in]  size        buffer size in bytes (must be >= getImageSizeInBytes()).
   */
  OTC_SDK_API void convertTemperatureToPaletteImage(void* destination, int size);


private:
  /// Default low pass filter factor for min-max filtering
  static constexpr float DEFAULT_TEMPERATURE_SCALING_FILTER_FACTOR = 0.96F;
  

  /// Calculates an image integral (speedup purpose).
  void calculateIntegralImage();

  /// Calculates the scaling boundaries based on minimal and maximal temperature.
  void calcMinMaxScalingFactor();

  /// Low pass filters the min value to prevent sudden jumps in the image.
  void updateMinValue(float filterFactor = 1.F);

  /// Low pass filters the max value to prevent sudden jumps in the image.
  void updateMaxValue(float filterFactor = 1.F);

  /**
   * @brief Calculates the scaling boundaries based on standard deviation.
   *
   * @param[in] sigma multiplication factor for sigma range
   */
  void calcSigmaScalingFactor(float sigma);

  /**
   * @brief Writes the false color image to the given destination buffer.
   *
   * @param[out] dest pointer to the output buffer (must be at least getImageSizeInBytes() bytes).
   */
  void writeColorImage(unsigned char* dest);


  /// Thermal frame.
  ThermalFrame _thermalFrame;
  /// Temperature converter.
  TemperatureConverter _converter;

  /// Integral image.
  std::vector<IntegralPixel> _integral;
  /// Flag for recomputing the integral image.
  bool _integralIsDirty;

  /// False color image (lazily allocated, only when using the internal-buffer path).
  Image _image;

  /// Lightweight image metadata (width, height, stride, color format) — no pixel allocation.
  ImageInfo _imageInfo;

  /// Indicates the temperature scaling mode.
  TemperatureScalingMode _scalingMode;

  /// Minimum temperature of the display range.
  unsigned short _min;

  /// Maximum temperature of the display range.
  unsigned short _max;

  /// Float companion of _min carrying the sub-integer precision that
  /// Sigma1/Sigma3's mean ± stdDev computation produces, fed into the
  /// hysteresis filter. In MinMax mode this just mirrors _min as a float
  /// (per-pixel data is integer-stepped, so there's nothing extra to keep).
  /// _min stays the canonical integer view used by the public
  /// getTemperatureScalingMin() API and LUT indexing.
  float _minFloat;

  /// Float companion of _max. See _minFloat.
  float _maxFloat;
  
  /// Minimum temperature of the display range after low pass filtering.
  /// Float so the hysteresis filter can settle between integer steps of
  /// the internal-value representation instead of truncating every step.
  float _minFiltered;

  /// Maximum temperature of the display range after low pass filtering.
  /// See _minFiltered.
  float _maxFiltered;

  /// Low pass filter factor for the min-max scaling values.
  float _scalingFilterFactor;

  /// Name of the active coloring palette.
  std::string _paletteName;
  /// 240-entry RGB color table copied from the registry on setPalette().
  std::array<std::array<uint8_t, 3>, 240> _paletteColors;
};


// Inline implementations
inline const ThermalFrame& ImageBuilder::getThermalFrame() const noexcept
{
  return _thermalFrame;
}

inline int ImageBuilder::getWidth() const noexcept
{
  return _thermalFrame.getWidth();
}

inline int ImageBuilder::getHeight() const noexcept
{
  return _thermalFrame.getHeight();
}

inline void ImageBuilder::setTemperatureScalingMode(TemperatureScalingMode mode) noexcept
{
  _scalingMode = mode;
}

inline TemperatureScalingMode ImageBuilder::getTemperatureScalingMode() const noexcept
{
  return _scalingMode;
}

inline std::string ImageBuilder::getPaletteName() const noexcept
{
  return _paletteName;
}

inline const Image& ImageBuilder::getImage() noexcept
{
  return _image;
}

inline int ImageBuilder::getImageSizeInBytes() const noexcept
{
  return _imageInfo.getHeight() * _imageInfo.getStride();
}

inline int ImageBuilder::getImageStride() const noexcept
{
  return _imageInfo.getStride();
}

} // namespace optris
