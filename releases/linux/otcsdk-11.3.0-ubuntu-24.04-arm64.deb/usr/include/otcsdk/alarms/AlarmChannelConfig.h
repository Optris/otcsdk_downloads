// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   AlarmChannelConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class defining the configuration of an alarm channel.
 * 
 * @date 2026-03-26
 */

#pragma once

#include <ostream>
#include <string>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/alarms/AlarmProperties.h"
#include "otcsdk/common/Range.h"
#include "otcsdk/fields/FieldProperties.h"
#include "otcsdk/fields/MeasurementField.h"
#include "otcsdk/pif/PifProperties.h"


namespace optris 
{

/// Holds the configuration of an alarm channel.
struct AlarmChannelConfig
{
  /// Name of the alarm channel.
  std::string name;

  /// Specifies the input that is observed by the alarm channel.
  AlarmInput input = AlarmInput::InternalTemperature;

  /// Identifies the measurement field by its index that should be used as input.
  int fieldIndex = 0;
  /// Identifies the statistic of the measurement field that should be used as input.
  FieldStat fieldStat = FieldStat::Mean;

  /// Identifies the PIF analog input channel that provides the uncommitted value that should be used as input.
  PifIndex uncommittedValuePifIndex = {0, 0};

  /// Indicates whether the entire alarm channel is enabled or disabled.
  bool enabled = true;

  /// Specifies whether the pre-alarm should be checked.
  bool preAlarmEnabled = false;
  /**
   * @brief A pre-alarm will be active, if the input is not in [preAlarmRange.min, preAlarmRange.max].
   *
   * Depending on the chosen input the unit of the pre-alarm range limits will differ:
   *  - Internal, chip, and measurement field temperature pre-alarms: degree Celsius.
   *  - Uncommitted value pre-alarms: unit depends on the specific PIF channel configuration.
   */  
  RangeF preAlarmRange = {20.F, 40.F};
  /**
   * @brief The alarm will be active, if the input is not in [alarmRange.min, alarmRange.max].
   *
   * An active alarm overrides a pre-alarm.
   *
   * Depending on the chosen input the unit of the alarm range limits will differ:
   *  - Internal, chip, and measurement field temperature alarms: degree Celsius.
   *  - Uncommitted value alarms: unit depends on the specific PIF channel configuration.
   */
  RangeF alarmRange = {25.F, 40.F};

  /**
   * @brief Indicates whether the alarm channel is part of the composite alarm.
   *
   * The composite alarm is triggered when at least one of the alarms in the composite is active.
   */
  bool partOfComposite = false;

  /**
   * @brief Identifies the PIF analog output channels to which the alarm status should be sent.
   *
   * This will only have an effect if the specified PIF channel is set to PifAoMode::Alarm.
   */
  std::vector<PifIndex> pifAoIndices;
  /**
   * @brief Identifies the PIF digital output channels to which the alarm status should be sent.
   *
   * This will only have an effect if the specified PIF channel is set to PifDoMode::Alarm.
   */
  std::vector<PifIndex> pifDoIndices;


  /**
   * @brief Creates a configuration for an alarm channel monitoring the internal temperature.
   *
   * The alarm will be active if the internal temperature is not in [minTemperature, maxTemperature].
   *
   * Specify the pre-, composite alarm and PIF output settings manually after creating the configuration.
   *
   * @param[in] name           of the alarm channel.
   * @param[in] minTemperature minimum temperature in degree Celsius.
   * @param[in] maxTemperature maximum temperature in degree Celsius.
   *
   * @return alarm channel configuration.
   */
  OTC_SDK_API static AlarmChannelConfig createInternalTemperature(const std::string& name, float minTemperature, float maxTemperature) noexcept;

  /**
   * @brief Creates a configuration for an alarm channel monitoring the sensor chip temperature.
   *
   * The alarm will be active if the sensor chip temperature is not in [minTemperature, maxTemperature].
   *
   * Specify the pre-, composite alarm and PIF output settings manually after creating the configuration.
   *
   * @param[in] name           of the alarm channel.
   * @param[in] minTemperature minimum temperature in degree Celsius.
   * @param[in] maxTemperature maximum temperature in degree Celsius.
   *
   * @return alarm channel configuration.
   */
  OTC_SDK_API static AlarmChannelConfig createChipTemperature(const std::string& name, float minTemperature, float maxTemperature) noexcept;

  /**
   * @brief Creates a configuration for an alarm channel monitoring a measurement field temperature.
   *
   * The alarm will be active if the measurement field temperature is not in [minTemperature, maxTemperature].
   *
   * Specify the pre-, composite alarm and PIF output settings manually after creating the configuration.
   *
   * @param[in] name           of the alarm channel.
   * @param[in] field          measurement field to monitor. If nullptr is passed, the field index will be set to 0.
   * @param[in] fieldStat      field statistic to monitor.
   * @param[in] minTemperature minimum temperature in degree Celsius.
   * @param[in] maxTemperature maximum temperature in degree Celsius.
   *
   * @return alarm channel configuration.
   */
  OTC_SDK_API static AlarmChannelConfig createMeasurementField(const std::string&                   name,
                                                               const MeasurementField::ConstShared& field, 
                                                               FieldStat                            fieldStat, 
                                                               float                                minTemperature, 
                                                               float                                maxTemperature) noexcept;

  /**
   * @brief Creates a configuration for an alarm channel monitoring an uncommitted value provided by a PIF analog input channel.
   *
   * The alarm will be active if the uncommitted value is in [minValue, maxValue].
   *
   * Specify the pre-, composite alarm and PIF output settings manually after creating the configuration.
   *
   * @param[in] name           of the alarm channel.
   * @param[in] pifDeviceIndex index of the PIF device identifying the PIF channel.
   * @param[in] pifPinIndex    index of the PIF pin identifying the PIF channel.
   * @param[in] minValue       minimum alarm value.
   * @param[in] maxValue       maximum alarm value.
   *
   * @return alarm channel configuration.
   */
  OTC_SDK_API static AlarmChannelConfig createUncommittedValue(const std::string& name,
                                                               int                pifDeviceIndex, 
                                                               int                pifPinIndex, 
                                                               float              minValue, 
                                                               float              maxValue) noexcept;


  /**
   * @brief Validates the configuration of an alarm channel.
   * 
   * @param[in,out] config alarm channel configuration to validate.
   *
   * @throw SDKException if the configuration is invalid.
   */
  OTC_SDK_API static void validate(AlarmChannelConfig& config);
};


// Utility functions
/**
 * @brief Output stream operator for alarm channel configurations.
 * 
 * @param[in] out    stream to use.
 * @param[in] config alarm channel configuration to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const AlarmChannelConfig& config) noexcept;

}  // namespace optris