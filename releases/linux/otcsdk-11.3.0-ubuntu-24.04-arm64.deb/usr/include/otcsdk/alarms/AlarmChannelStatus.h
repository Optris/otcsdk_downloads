// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   AlarmChannelStatus.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the status of an alarm channel.
 * 
 * @date 2026-03-27
 */

#pragma once

#include <cstdint>
#include <ostream>
#include <string>

#include "otcsdk/Api.h"
#include "otcsdk/alarms/AlarmProperties.h"


namespace optris 
{

/// Encapsulates the status of an alarm channel.
class AlarmChannelStatus
{
public:
  /// Constructor.
  OTC_SDK_API AlarmChannelStatus() noexcept;


  /**
   * @brief Returns the ID of the alarm channel.
   *
   * @return alarm channel ID.
   */
  std::int32_t getId() const noexcept;

  /**
   * @brief Returns the name of the alarm channel.
   * 
   * @return name of the alarm channel.
   */
  const std::string& getName() const noexcept;

  /**
   * @brief Returns the state of the alarm channel.
   *
   * @return alarm channel state.
   */
  AlarmState getState() const noexcept;

  /**
   * @brief Returns whether the alarm channel is active.
   *
   * An alarm channel will be considered active, if its state is AlarmState::Active.
   *
   * @return true if the alarm channel is active, false otherwise.
   */
  bool isActive() const noexcept;

  /**
   * @brief Returns the value of the alarm channel on which the alarm state is based.
   *
   * @return value of the alarm channel on which the alarm state is based.
   */
  float getValue() const noexcept;

  /**
   * @brief Returns the relation of the value to the alarm range.
   *
   * @return relation of the value to the alarm range.
   */
  AlarmRangeRelation getAlarmRangeRelation() const noexcept;


  /**
   * @brief Updates the status of the alarm channel.
   *
   * @param[in] channelId          ID of the alarm channel.
   * @param[in] name               name of the alarm channel.
   * @param[in] state              state of the alarm channel.
   * @param[in] alarmRangeRelation the relation between the value and the alarm ranges.
   * @param[in] value              value of the alarm channel on which the alarm state is based.
   */
  OTC_SDK_API void update(std::int32_t       channelId, 
                          const std::string& name, 
                          AlarmState         state, 
                          AlarmRangeRelation alarmRangeRelation,
                          float              value) noexcept;


private:
  /// ID of the alarm channel.
  std::int32_t _id;
  /// Name of the alarm channel.
  std::string _name;
  /// State of the alarm channel.
  AlarmState _state;
  /// Relation of the value to the alarm range.
  AlarmRangeRelation _alarmRangeRelation;
  /// Value of the alarm channel on which the alarm state is based.
  float _value;
};


// Utility functions
/**
 * @brief Output stream operator for alarm channel status.
 * 
 * @param[in] out    stream to use.
 * @param[in] status to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const AlarmChannelStatus& status);


// Inline implementations
inline std::int32_t AlarmChannelStatus::getId() const noexcept
{
  return _id;
}

inline const std::string& AlarmChannelStatus::getName() const noexcept
{
  return _name;
}

inline AlarmState AlarmChannelStatus::getState() const noexcept
{
  return _state;
}

inline AlarmRangeRelation AlarmChannelStatus::getAlarmRangeRelation() const noexcept
{
  return _alarmRangeRelation;
}

inline float AlarmChannelStatus::getValue() const noexcept
{
  return _value;
}

inline bool AlarmChannelStatus::isActive() const noexcept
{
  return _state == AlarmState::Active;
}

} // namespace optris