// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   CompositeAlarmStatus.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class holding the status of a composite alarm.
 * 
 * @date 2026-04-10
 */

#pragma once

#include <ostream>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/alarms/AlarmChannelStatus.h"


namespace optris 
{

/// Encapsulates the status of the composite alarm.
class CompositeAlarmStatus
{
public:
  /// Constructor.
  CompositeAlarmStatus() = default;


  /**
   * @brief Returns whether the composite alarm is active.
   * 
   * The composite alarm is considered active, if at least one of its alarm channels is active. If none of
   * its alarm channels is active or if it does not have alarm channels, it will be inactive.
   *
   * @return true if the composite alarm is active, false otherwise.
   *
   * @see AlarmChannelStatus::isActive()
   */
  bool isActive() const noexcept;

  /**
   * @brief Returns the statuses of the active alarm channels contributing to the composite alarm.
   * 
   * @return statuses of the active alarm channels contributing to the composite alarm. Empty, if
   *         the composite alarm is not active.
   *
   * @see AlarmChannelStatus::isActive()
   */
  const std::vector<AlarmChannelStatus>& getActiveChannelStatuses() const noexcept;

  /**
   * @brief Returns the count of active alarm channels contributing to the composite alarm.
   * 
   * @return count of active alarm channels contributing to the composite alarm. Zero, if the
   *         composite alarm is not active.
   *
   * @see AlarmChannelStatus::isActive()
   */
  int getActiveChannelCount() const noexcept;

  /// Resets the composite alarm status.
  void reset() noexcept;

  /**
   * @brief Adds the status of an active alarm channel contributing to the composite alarm.
   * 
   * @param[in] channel status of an active alarm channel to add.
   */
  void addChannelStatus(const AlarmChannelStatus& channel) noexcept;


private:
  /// Statuses of the active alarm channels contributing to the composite alarm.
  std::vector<AlarmChannelStatus> _activeChannels;
};


// Utility functions
/**
 * @brief Output stream operator for composite alarm status.
 * 
 * @param[in] out    stream to use.
 * @param[in] status to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const CompositeAlarmStatus& status);


// Inline implementations
inline bool CompositeAlarmStatus::isActive() const noexcept
{
  return !_activeChannels.empty();
}

inline const std::vector<AlarmChannelStatus>& CompositeAlarmStatus::getActiveChannelStatuses() const noexcept
{
  return _activeChannels;
}

inline int CompositeAlarmStatus::getActiveChannelCount() const noexcept
{
  return static_cast<int>(_activeChannels.size());
}

inline void CompositeAlarmStatus::reset() noexcept
{
  _activeChannels.clear();
}

inline void CompositeAlarmStatus::addChannelStatus(const AlarmChannelStatus& channel) noexcept
{
  _activeChannels.push_back(channel);
}

}  // namespace optris