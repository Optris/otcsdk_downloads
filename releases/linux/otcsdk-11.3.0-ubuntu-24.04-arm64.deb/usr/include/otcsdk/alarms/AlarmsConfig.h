// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   AlarmsConfig.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains a class encapsulating the configuration of the alarms.
 * 
 * @date 2026-03-26
 */

#pragma once

#include <ostream>
#include <vector>

#include "otcsdk/Api.h"
#include "otcsdk/alarms/AlarmChannelConfig.h"


namespace optris 
{

/// Holds the alarm configuration.
struct AlarmsConfig
{
  /// Alarm channel configurations.
  std::vector<AlarmChannelConfig> channels;


  /**
   * @brief Validates the alarm configuration.
   * 
   * @param[in,out] config alarm configuration to validate.
   *
   * @throw SDKException if the configuration is invalid.
   */
  OTC_SDK_API static void validate(AlarmsConfig& config);
};


// Utility functions
/**
 * @brief Output stream operator for the alarm configuration.
 * 
 * @param[in] out    stream to use.
 * @param[in] config alarm configuration to output. 
 *
 * @return used output stream. 
 */
OTC_SDK_API std::ostream& operator<<(std::ostream& out, const AlarmsConfig& config) noexcept;

}  // namespace optris