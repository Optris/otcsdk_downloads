// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   AlarmChannel.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains an interface representing an alarm channel.
 * 
 * @date 2026-03-30
 */

#pragma once

#include <cstdint>
#include <string>
#include <memory>

#include "otcsdk/alarms/AlarmChannelConfig.h"


namespace optris 
{

/// Interface representing an alarm channel.
class AlarmChannel
{
public:
  /// Shared pointer type for alarm channels.
  using ConstShared = std::shared_ptr<const AlarmChannel>;


  /// Constructor.
  AlarmChannel() = default;

  /// No copy constructor.
  AlarmChannel(const AlarmChannel&) = delete;
  /// No copy assignment.
  AlarmChannel& operator=(const AlarmChannel&) = delete;

  /// No move constructor.
  AlarmChannel(AlarmChannel&&) = delete;
  /// No move assignment.
  AlarmChannel& operator=(AlarmChannel&&) = delete;

  /// Destructor.
  virtual ~AlarmChannel() = default;


  /**
   * @brief Returns the unique ID identifying the alarm channel.
   *
   * @return unique ID identifying the alarm channel.
   */
  virtual std::int32_t getId() const noexcept = 0;

  /**
   * @brief Returns the name of the alarm channel.
   * 
   * @return name of the alarm channel.
   */
  virtual const std::string& getName() const noexcept = 0;

  /**
   * @brief Returns the configuration of the alarm channel.
   *
   * @return configuration of the alarm channel.
   */
  virtual const AlarmChannelConfig& getConfig() const noexcept = 0;
};

} // namespace optris