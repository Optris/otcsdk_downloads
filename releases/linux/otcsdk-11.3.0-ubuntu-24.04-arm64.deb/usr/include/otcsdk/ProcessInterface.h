// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file   ProcessInterface.h
 * @author Optris GmbH & Co. KG
 * @brief  Contains the interface that defines how to interact with process interfaces.
 * 
 * @date 2025-06-24
 */

#pragma once

#include <vector>

#include "otcsdk/pif/PifConfig.h"


namespace optris
{

/**
 * @brief Interface defining the API for interacting with process interfaces (PIFs).
 * 
 * Each PIF can have up to five different channel type. The API uses the following abbreviations to mark 
 * resources specific to a channel type:
 *
 * - `Ai` - analog inputs
 * - `Di` - digital inputs
 * - `Ao` - analog outputs
 * - `Do` - digital outputs
 * - `Fs` - fail safe
 *
 * In case of stackable PIFs the number of configurable PIFs can deviate from the number of actually
 * connected PIFs. To reflect this the API features different count methods for PIF devices and PIF
 * channels:
 *
 * __Devices__
 * - `getActualDeviceCount()` returns the number of actually connected devices.
 * - `getConfigurableDeviceCount()` returns the number configurable devices.
 *
 * @note On non-stackable PIFs these methods yield the same values.
 *
 * __Channels__ (`XX` denotes the channel type)
 * - `getActualXXCount()` returns the count of all `XX` channels on actually connected devices.
 * - `getConfigurableXXCount()` returns the count of all `XX` channels on configurable devices.
 * - `getXXCountPerDevice()` returns the count of `XX` channels per individual device.
 * 
 * @note The actual PIF device count can never exceed the configurable device count.
 * 
 * For more details and an overview of the process interface capabilities please refer to the
 * [Process Interface (PIF)](#pif) chapter.
 */
class ProcessInterface
{
public:
  /// Constructor.
  ProcessInterface() = default;

  /// No copy constructor.
  ProcessInterface(const ProcessInterface&) = delete;
  /// No copy assignment.
  ProcessInterface& operator=(const ProcessInterface&) = delete;

  /// No move constructor.
  ProcessInterface(ProcessInterface&&) = delete;
  /// No move assignment.
  ProcessInterface& operator=(ProcessInterface&&) = delete;

  /// Destructor.
  virtual ~ProcessInterface() = default;


  // Device
  /**
   * @brief Returns the PIF device type.
   * 
   * @return PIF device type. 
   */
  virtual PifDeviceType getDeviceType() const noexcept = 0;

  /**
   * @brief Returns the list of PIF device types this camera model accepts in setConfig().
   *
   * Cameras are categorized into three groups (autonomous, PI1, non-autonomous), each
   * accepting a different subset of PifDeviceType values. This method reports the subset
   * for the connected camera so clients can build a UI that only offers valid choices.
   *
   * @return supported PIF device types for this camera.
   */
  virtual std::vector<PifDeviceType> getSupportedDeviceTypes() const noexcept = 0;

  /**
   * @brief Returns the count of actually connected PIFs.
   * 
   * The method only returns count of connected PIFs whose type equals the one returned by getDeviceType().
   *
   * @attention This count can never exceed the configurable device count returned by getConfigurableDeviceCount().
   *
   * @return count of actually connected PIFs. 
   */
  virtual int getActualDeviceCount() const noexcept = 0;

  /**
   * @brief Returns the count of configurable PIFs.
   * 
   * @return count of configurable PIFs. 
   */
  virtual int getConfigurableDeviceCount() const noexcept = 0;

  /**
   * @brief Returns whether a PIF is actually connected.
   * 
   * @return false if the actual device count is 0. True otherwise.
   */
  virtual bool isActualConnected() const noexcept = 0;


  /**
   * @brief Returns the serial number of the PIF with the given device index.
   * 
   * @param[in] deviceIndex identifying the PIF device.
   *
   * @return serial number of the PIF with the given device index.
   *
   * @throw SDKException if the device index is out of range.
   */
  virtual unsigned long getDeviceSerialNumber(int deviceIndex) const = 0;

  /**
   * @brief Returns the firmware revision of the PIF with the given device index.
   * 
   * @param[in] deviceIndex identifying the PIF device.
   *
   * @return firmware revision of the PIF with the given device index.
   *
   * @throw SDKException if the device index is out of range.
   */
  virtual unsigned short getDeviceFirmwareRevision(int deviceIndex) const = 0;


  /**
   * @brief Sets the given configuration for the entire process interface.
   * 
   * @param[in] config to set.
   *
   * @throw SDKException if the provided configuration could not be applied.
   */
  virtual void setConfig(const PifConfig& config) = 0;

  /**
   * @brief Returns the current configuration of the entire process interface.
   * 
   * @return the current configuration of the entire process interface. 
   */
  virtual PifConfig getConfig() const noexcept = 0;


  // Analog inputs
  /**
   * @brief Returns the count of all analog input channels on actually connected PIFs.
   * 
   * @return count of all analog input channels on actually connected PIFs. 
   */
  virtual int getActualAiCount() const noexcept = 0;

  /**
   * @brief Returns the count of all analog input channels on configurable PIFs.
   * 
   * @return count of all analog input channels on configurable PIFs. 
   */
  virtual int getConfigurableAiCount() const noexcept = 0;

  /**
   * @brief Returns the count of all analog input channels on a single PIF.
   * 
   * @return count of all analog input channels on a single PIF.
   */
  virtual int getAiCountPerDevice() const noexcept = 0;


  /**
   * @brief Sets the configuration for a single analog input channel.
   * 
   * If an analog input channel that generates an uncommitted value is switch to a different mode,
   * dependent alarm channel turn orphaned and are subsequently removed.
   *
   * @param[in] config to set.
   *
   * @throw SDKExceptions if the provided configuration could not be applied.
   */
  virtual void setAiConfig(const PifAiConfig& config) = 0;

  /**
   * @brief Returns the current configuration of the specified analog input channel.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return current configuration of the specified analog input channel.
   *
   * @throw SDKException if the given indices are out of range.
   */
  virtual PifAiConfig getAiConfig(int deviceIndex, int pinIndex) const = 0;


  // Digital inputs
  /**
   * @brief Returns the count of all digital input channels on actually connected PIFs.
   * 
   * @return count of all digital input channels on actually connected PIFs. 
   */
  virtual int getActualDiCount() const noexcept = 0;

  /**
   * @brief Returns the count of all digital input channels on configurable PIFs.
   * 
   * @return count of all digital input channels on configurable PIFs. 
   */
  virtual int getConfigurableDiCount() const noexcept = 0;

  /**
   * @brief Returns the count of all digital input channels on a single PIF.
   * 
   * @return count of all digital input channels on a single PIF.
   */
  virtual int getDiCountPerDevice() const noexcept = 0;


  /**
   * @brief Sets the configuration for a single digital input channel.
   * 
   * @param[in] config to set.
   *
   * @throw SDKExceptions if the provided configuration could not be applied.
   */
  virtual void setDiConfig(const PifDiConfig& config) = 0;

  /**
   * @brief Returns the current configuration of the specified digital input channel.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return current configuration of the specified digital input channel.
   *
   * @throw SDKException if the given indices are out of range.
   */
  virtual PifDiConfig getDiConfig(int deviceIndex, int pinIndex) = 0;


  // Analog outputs
  /**
   * @brief Returns the count of all analog output channels on actually connected PIFs.
   * 
   * @return count of all analog output channels on actually connected PIFs. 
   */
  virtual int getActualAoCount() const noexcept = 0;

  /**
   * @brief Returns the count of all analog output channels on configurable PIFs.
   * 
   * @return count of all analog output channels on configurable PIFs. 
   */
  virtual int getConfigurableAoCount() const noexcept = 0;

  /**
   * @brief Returns the count of all analog output channels on a single PIF.
   * 
   * @return count of all analog output channels on a single PIF.
   */
  virtual int getAoCountPerDevice() const noexcept = 0;

  /**
   * @brief Returns the default analog output mode of the PIF.
   * 
   * @return default analog output mode of the PIF. 
   */
  virtual PifAoOutputMode getDefaultAoOutputMode() const noexcept = 0;


  /**
   * @brief Sets the configuration for a single analog output channel.
   * 
   * @param[in] config to set.
   *
   * @throw SDKExceptions if the provided configuration could not be applied.
   */
  virtual void setAoConfig(const PifAoConfig& config) = 0;

  /**
   * @brief Returns the current configuration of the specified analog output channel.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return current configuration of the specified analog output channel.
   *
   * @throw SDKException if the given indices are out of range.
   */
  virtual PifAoConfig getAoConfig(int deviceIndex, int pinIndex) = 0;


  /**
   * @brief Sets the output value of the specified analog output channel.
   * 
   * The provided value is automatically clipped to the set output mode limits.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] value       to output.
   *
   * @throw SDKException if the indices are out of range or if the channel is not set to PifAoMode::ExternalCommunication.
   */
  virtual void setAoValue(int deviceIndex, int pinIndex, float value) = 0;


  // Digital outputs
  /**
   * @brief Returns the count of all digital output channels on actually connected PIFs.
   * 
   * @return count of all digital output channels on actually connected PIFs. 
   */
  virtual int getActualDoCount() const noexcept = 0;

  /**
   * @brief Returns the count of all digital output channels on configurable PIFs.
   * 
   * @return count of all digital output channels on configurable PIFs. 
   */
  virtual int getConfigurableDoCount() const noexcept = 0;

  /**
   * @brief Returns the count of all digital output channels on a single PIF.
   * 
   * @return count of all digital output channels on a single PIF.
   */
  virtual int getDoCountPerDevice() const noexcept = 0;


  /**
   * @brief Sets the configuration for a single digital output channel.
   * 
   * @param[in] config to set.
   *
   * @throw SDKExceptions if the provided configuration could not be applied.
   */
  virtual void setDoConfig(const PifDoConfig& config) = 0;

  /**
   * @brief Returns the current configuration of the specified digital output channel.
   * 
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   *
   * @return current configuration of the specified digital output channel.
   *
   * @throw SDKException if the given indices are out of range.
   */
  virtual PifDoConfig getDoConfig(int deviceIndex, int pinIndex) = 0;


  /**
   * @brief Sets the output value of the specified digital output channel.
   *
   * @param[in] deviceIndex identifying the channel.
   * @param[in] pinIndex    identifying the channel.
   * @param[in] value       to output.
   *
   * @throw SDKException if the indices are out of range or if the channel is not set to PifDoMode::ExternalCommunication.
   */
  virtual void setDoValue(int deviceIndex, int pinIndex, bool value) = 0;

  
  // Fail safe
  /**
   * @brief Returns wether the PIF has a fail safe channel.
   * 
   * @return true if the PIF has a fail safe channel. False otherwise.
   */
  virtual bool hasFs() const noexcept = 0;

  /**
   * @brief Sets the configuration for the fail safe channel.
   * 
   * @param[in] config to set.
   *
   * @throw SDKException if no fail safe channel is available. 
   */
  virtual void setFsConfig(const PifFsConfig& config) = 0;

  /**
   * @brief Returns the current fail safe channel configuration.
   * 
   * @return current fail safe channel configuration. 
   *
   * @throw SDKException if no fail safe channel is available. 
   */
  virtual PifFsConfig getFsConfig() = 0;
};

} // namespace optris