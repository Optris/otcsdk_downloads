# CMake release target configuration for the SoSCorrection library

set_property(TARGET SoSCorrection::SoSCorrection APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)

if(FALSE)
  set_target_properties(SoSCorrection::SoSCorrection
    PROPERTIES
      IMPORTED_LOCATION ${PACKAGE_PREFIX_DIR}/bin/SoSCorrectionLib.dll
      IMPORTED_IMPLIB   ${PACKAGE_PREFIX_DIR}/lib/SoSCorrectionLib.lib
  )
else()
  set_target_properties(SoSCorrection::SoSCorrection
    PROPERTIES
      IMPORTED_LOCATION ${PACKAGE_PREFIX_DIR}/lib/libSoSCorrectionLib.so
  )
endif()
