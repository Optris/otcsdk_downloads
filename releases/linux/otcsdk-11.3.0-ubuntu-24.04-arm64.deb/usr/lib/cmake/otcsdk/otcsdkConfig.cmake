# Import library targets
include("${CMAKE_CURRENT_LIST_DIR}/otcsdkTargets.cmake")


# Find library dependencies
include(CMakeFindDependencyMacro)

# Backup the the CMake module path and then add the path to our custom find
# modules so that public library dependencies can be located with the macro
# find_dependency(). Afterwards we restore the original CMake module path.
set(_otcsdk_module_path_backup "${CMAKE_MODULE_PATH}")
list(INSERT CMAKE_MODULE_PATH 0 "${CMAKE_CURRENT_LIST_DIR}/find_modules")

# Size of Source Correction
find_dependency(SoSCorrection
  HINTS "${CMAKE_CURRENT_LIST_DIR}"
)

if(TRUE)
  find_dependency(LibUdev)
  find_dependency(LibUsb)
elseif(FALSE)
  # Direct Show Stream Base Filters
  find_dependency(DsStreamBase
    HINTS "${CMAKE_CURRENT_LIST_DIR}"
  )
endif()

set(CMAKE_MODULE_PATH "${_otcsdk_module_path_backup}")
unset(_otcsdk_module_path_backup)
