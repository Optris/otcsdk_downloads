# CMake configuration for the SoSCorrection library

include("${CMAKE_CURRENT_LIST_DIR}/SoSCorrectionTargets.cmake")