// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file    SimpleEnumerationClient.h
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the enumeration example.
 *          
 * @date 2025-03-31
 */

#pragma once

#include "otcsdk/enumeration/EnumerationClient.h"


/**
 * @brief Simple example implementation of an EnumerationClient that outputs enumerations events.
 *
 * An EnumerationClient serves as observer to the EnumerationManger that constantly checks whether devices
 * are newly attached or removed.
 */
class SimpleEnumerationClient : public optris::EnumerationClient
{
public:
  /// Constructor.
  SimpleEnumerationClient();


  /// Main run method.
  void run();


private:
  /**
   * @brief Called when a new device was detected.
   *
   * This happens, for example, if a camera is plugged in to the computer via USB.
   * 
   * @param[in] deviceInfo about the detected device.
   */
  void onDeviceDetected(optris::DeviceInfo deviceInfo) noexcept override;

  /**
   * @brief Called when a previously detected device is now longer found.
   * 
   * This happens, for example, if a camera is unplugged from the computer.
   * 
   * @param[in] deviceInfo about the lost device.
   */
  void onDeviceDetectionLost(optris::DeviceInfo deviceInfo) noexcept override;

  /**
   * @brief Called when a previously detected device changed its status or configuration.
   * 
   * This happens, for example, if a camera is opened by another program and starts streaming data.
   * 
   * @param[in] deviceInfo about the changed device.
   */
  void onDeviceDetectionChanged(optris::DeviceInfo deviceInfo) noexcept override;

  /// Prints the header for the displayed enumeration events.
  void printHeader();

  /**
   * @brief Prints out an enumeration event.
   * 
   * @param[in] event      to print.
   * @param[in] deviceInfo to print.
   */
  void printEvent(const std::string& event, const optris::DeviceInfo& deviceInfo);
};