﻿// Copyright (c) 2008-2026 Optris GmbH & Co. KG

using Optris.OtcSdk;

namespace Minimal
{
    internal class Program
    {
        /// <summary>Program main entry point.</summary>
        static void Main(string[] args)
        {
            // Initialize the SDK with log verbosity
            Sdk.init(Verbosity.Info, Verbosity.Off, "Enumeration");

            /*
             * Add an additional detector for Ethernet devices on the network 192.168.0.0/24. A detector for 
             * USB devices was added when calling Sdk.init().
             */
            EnumerationManager.getInstance().addEthernetDetector("192.168.0.0/24");

            // The serial number 0 serves as a wild card. If specified the first compatible device is used.
            uint serialNumber = 0;
            if (args.Length > 0)
            {
                serialNumber = uint.Parse(args[0]);
            }

            SimpleImagerClient client;
            try
            {
                client = new(serialNumber);
            }
            catch (SDKException ex)
            {
                Console.WriteLine(ex.Message);

                return;
            }

            // Run the client
            client.run();
        }
    }
}
