# Optris Thermal Camera SDK Examples

The directories in this folder feature examples illustrating various capabilities of the SDK. Please refer to their respective
Readmes to learn more about them and about the prerequisites needed to compile and/or run them.

## General Preparations

You may want to install a code editor, like [Visual Studio Code](https://code.visualstudio.com/) to take a closer look at the
source code of the examples.

For more details on how to build and run the examples please refer to the more specific `README.md` in the sub-folders for
each supported programming language.

### Linux

On Linux you have to copy the examples files from its install location to a place where you can edit them at ease. You could use,
for example, your home directory:

```bash
cp -r /usr/share/doc/otcsdk/examples ~
```

The copied files are owned by `root` but you can still edit them as you like. You can change the ownership as follows:

```bash
sudo chown -R <user>:<user group> example
```

Replace `<user>` with your username and `<user group>` to your user group.

### Windows

On Windows the installer already created a copy of the examples in your `Documents` directory. If you want to restore the examples
you can copy the `examples` folder from the SDK installation directory. By default this directory is located at:

```powershell
C:\Program Files\Optris\otcsdk\examples
```
