// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file    SimpleImagerClient.cpp
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the minimal example.
 *          
 * @date 2025-03-31 
 */

#include "SimpleImagerClient.h"

#include <cmath>
#include <iostream>
#include <iomanip>

#include "otcsdk/IRImagerFactory.h"


SimpleImagerClient::SimpleImagerClient(unsigned long serialNumber)
  /*
   * The factory is implemented as a Singleton. Therefore, you have to call getInstance()
   * first before you can create an IRImager object.
   *
   * The native implementation allows you to access the thermal data of cameras connected
   * via USB or Ethernet.
   */
  : _imager{optris::IRImagerFactory::getInstance().create("native")}
  , _fps{100}
{
  /*
   * Register this instance as a client/observer with the IRImager implementation to
   * receive updates on thermal data and more.
   */
  _imager->addClient(this);

  // Establishes a connection to the camera.
  _imager->connect(serialNumber);
}


void SimpleImagerClient::run()
{
  /*
   * Run the imager synchronously (the run() method will block).
   *
   * As an alternative, the imager can be run asynchronously with the runAsync()
   * method. In this case the callbacks will be triggered from a separate
   * thread.
   */ 
   _imager->run();
}


void SimpleImagerClient::onFrame(const optris::FrameEvent& evt) noexcept
{
  _fps.trigger();

  // When the flag transitioned out of Initializing the thermal data is valid. Thus, print the header of the output table.
  static auto flagState = evt.meta.getFlagState();
  if (flagState != evt.meta.getFlagState() && flagState == optris::FlagState::Initializing)
  {
    std::cout << "\n"
          << "Thermal Frame\n\n"
          << std::setw(10) << std::left << "WIDTH" 
          << std::setw(10) << std::left << "HEIGHT"
          << std::setw(10) << std::left << "FPS"
          << std::setw(20) << std::left << "TEMP CENTER PIXEL"
          << std::setw(15) << std::left << "FLAG STATE\n";
  }

  // When the flag transitioned out of Initializing the thermal data is valid and can be displayed.
  if (evt.meta.getFlagState() != optris::FlagState::Initializing)
  {
    std::cout << std::setw(10) << std::left << evt.thermalFrame.getWidth() 
              << std::setw(10) << std::left << evt.thermalFrame.getHeight()
              << std::setw(10) << std::left << std::round(_fps.getFps())
              << std::setw(20) << std::left << evt.thermalFrame.getTemperature(evt.thermalFrame.getWidth() / 2, evt.thermalFrame.getHeight() / 2)
              << std::setw(15) << std::left << evt.meta.getFlagState() 
              << "\r" << std::flush;
  }

  flagState = evt.meta.getFlagState();
}
