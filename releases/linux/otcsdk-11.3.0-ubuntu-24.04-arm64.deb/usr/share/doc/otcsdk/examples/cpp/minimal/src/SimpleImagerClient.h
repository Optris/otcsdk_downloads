// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file    SimpleImagerClient.h
 * @author  Optris GmbH & Co. KG
 * @brief   Main entry point for the minimal example.
 *          
 * @date 2025-03-31
 */

#pragma once

#include <memory>

#include "otcsdk/IRImager.h"
#include "otcsdk/IRImagerClient.h"
#include "otcsdk/FramerateCounter.h"


/**
 * @brief Minimal example implementation of an IRImagerClient.
 * 
 * Bare minimum required to run an imager instance and receive data from it via the Observer
 * pattern. See simpleView example for a more comprehensive implementation.
 */
class SimpleImagerClient : public optris::IRImagerClient
{
public:
  /**
   * @brief Constructor.
   * 
   * @param[in] serialNumber of the camera to connect to.
   *
   * @throw SDKException if an imager instance could not be created.
   */
  SimpleImagerClient(unsigned long serialNumber);


  /// Main run method.
  void run();


private:
  /**
   * @brief Callback method triggered by imager when a new thermal frame is available.
   *
   * @param[in] evt event containing metadata, thermal frame data and measurement field data.
   */
  void onFrame(const optris::FrameEvent& evt) noexcept override;


  /// Imager instance.
  std::shared_ptr<optris::IRImager> _imager;

  /// Measures frames per second.
  optris::FramerateCounter _fps;
};