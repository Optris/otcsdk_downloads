/**
 * @file Obvious2D.h
 *
 * @brief  Contains resources to render images with the help of OpenGL.
 *
 *
 * This file is part of the Obviously library.
 *
 * Copyright(c) 2010-2012 Georg-Simon-Ohm University, Nuremberg.
 * http://www.ohm-university.eu
 *
 * This file may be licensed under the terms of of the
 * GNU General Public License Version 2 (the ``GPL'').
 *
 * Software distributed under the License is distributed
 * on an ``AS IS'' basis, WITHOUT WARRANTY OF ANY KIND, either
 * express or implied. See the GPL for the specific language
 * governing rights and limitations.
 *
 * You should have received a copy of the GPL along with this
 * program. If not, go to http://www.gnu.org/licenses/gpl.html
 * or write to the Free Software Foundation, Inc.,
 * 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
 *
 */

#pragma once

#include <mutex>
#include <vector>
#include <string>
#include <map>

#define GL_GLEXT_PROTOTYPES 1
#include <GL/glew.h>
#include <GL/freeglut.h>
#include <GL/gl.h>

#include "Obvious2DClient.h"
#include "otcsdk/FramerateCounter.h"



#define TEXTMAX 10


struct TextStruct
{
  std::string text;
  unsigned int col;
  unsigned int row;
  unsigned char rgba[4];
  unsigned char rgbaBG[4];
  double progress;
};

struct CrossHair
{
  std::string text;
  int col;
  int row;
  float radius;  // range [0; 1] => 1.f states whole image edge length
  unsigned char rgba[4];
  unsigned char rgbaBG[4];
  float offset;
};

struct Rectangle
{
  int col;
  int row;
  int width;
  int height;
  unsigned char rgba[4];
};



//// GLUT-based 2D viewer.
class Obvious2D
{
public:
  /// Function pointer for keyboard callbacks.
  using fptrKeyboardCallback = void (*)();


  /// White color as a RGBA array.
  static constexpr unsigned char WHITE[4] = {255, 255, 255, 255};
  /// Black color as a RGBA array.
  static constexpr unsigned char BLACK[4] = {0, 0 , 0, 255};
  /// Blue color as a RGBA array.
  static constexpr unsigned char BLUE[4] = {0, 0, 255, 255};
  /// Red color as a RGBA array.
  static constexpr unsigned char RED[4] = {255, 0 , 0, 255};
  /// Green color as a RGBA array.
  static constexpr unsigned char GREEN[4] = {0, 255, 0, 255};


  /**
   * @brief Constructor.
   *
   * @param[in] width  image width.
   * @param[in] height image height.
   * @param[in] title  window title.
   */
  Obvious2D(unsigned int width, unsigned int height, std::string title);

  /// Destructor.
  ~Obvious2D();


  /**
   * @brief Returns the width of the window.
   *
   * @return width of the window.
   */
  unsigned int getWidth() const;

  /**
   * @brief Sets the width of the window.
   *
   * @param[in] width of the window.
   */
  void setWidth(unsigned int width);

  /**
   * @brief Returns the height of the window.
   *
   * @return height of the window.
   */
  unsigned int getHeight() const;

  /**
   * @brief Sets the height of the window.
   *
   * @param[in] height of the window.
   */
  void setHeight(unsigned int height);

  /**
   * @brief Returns the initial width of the window.
   *
   * @return initial width of the window.
   */
  unsigned int getInitWidth() const;

  /**
   * @brief Returns the initial height of the window.
   *
   * @return initial height of the window.
   */
  unsigned int getInitHeight() const;

  /**
   * @brief Returns the width of the screen.
   *
   * @return width of the screen.
   */
  unsigned int getScreenWidth() const;

  /**
   * @brief Returns the height of the screen.
   *
   * @return height of the screen.
   */
  unsigned int getScreenHeight() const;

  /**
   * @brief Returns the flag indicating whether to use fullscreen.
   *
   * @return flag indication whether to use fullscreen.
   */
  bool getFullscreen() const;

  /**
   * @brief Sets the flag indicating whether to use fullscreen.
   *
   * @param[in] fullscreen fullscreen flag value.
   */
  void setFullscreen(bool fullscreen);

  /**
   * @brief Resizes an existing window.
   *
   * @param[in] width  to set. 
   * @param[in] height to set. 
   */
  void resizeWindow(int width, int height);

  /// Toggles fullscreen.
  void toggleFullscreen();

  /**
   * @brief Sets a black border horizontally and vertically.
   *
   * @param[in] pixelsLeft   number of pixels set as left border.
   * @param[in] pixelsRight  number of pixels set as right border.
   * @param[in] pixelsTop    number of pixels set as top border.
   * @param[in] pixelsBottom number of pixels set as bottom border.
   */
  void setBorder(unsigned int pixelsLeft, unsigned int pixelsRight, unsigned int pixelsTop, unsigned int pixelsBottom);

  /**
   * @brief Sets the GLUT font.
   *
   * @param[in] font  to set, e.g. GLUT_BITMAP_HELVETICA_10, GLUT_BITMAP_HELVETICA_12, GLUT_BITMAP_HELVETICA_18. 
   *                  Default: GLUT_BITMAP_HELVETICA_12
   */
  void setFont(void* font);

  /**
   * @brief Sets whether to display help information.
   *
   * @param[in] showHelp if true, show help information.
   */
  void setShowHelp(bool showHelp);

  /**
   * @brief Sets whether to displaying of fps information.
   *
   * @param[in] showFPS if true, fps information is displayed.
   */
  void setShowFPS(bool showFPS);

  /**
   * @brief Returns whether the viewer is still to be drawn.
   *
   * @return if true, the viewer is still to be drawn. False otherwise.
   */
  bool isAlive() const;

  /// Terminates the viewer.
  void terminate();

  /**
   * @brief Returns the length of the given string in pixels.
   *
   * @param[in] text string whose length in pixels should be returned.
   *
   * @return the length of the given string in pixels.
   */
  int getBitmapLength(const char* text) const;

  /**
   * @brief Returns the height of a font in pixels.
   *
   * @return height of a font in pixels.
   */
  int getBitmapHeight() const;

  /**
   * @brief Draws the given image on the screen.
   *
   * @param[in] image         pointer to image data (size = width*height*channels).
   * @param[in] width         image width.
   * @param[in] height        image height.
   * @param[in] channels      number of color channels.
   * @param[in] flagState     current flag state.
   * @param[in] fps           frames per second of grabbing process.
   */
  void draw(const unsigned char* image, 
            unsigned int         width, 
            unsigned int         height, 
            unsigned int         channels,
            const std::string&   flagState,
            double               fpsSrc=0.0);

  /**
   * @brief Draws the serial number on the screen.
   *
   * @param[in] _showSerial indicates whether the serial number should be drawn.
   * @param[in] serial      number to be drawn.
   */
  void showSerialNum(bool _showSerial, int serial);

  /**
   * @brief Registers a callback function that is triggered by keyboard events.
   *
   * @param[in] key      when pressed triggers the callback.
   * @param[in] callback pointer to the callback function.
   * @param[in] helpText describing the effects of the callback.
   * @param[in] rgba     color of the help text.
   * @param[in] rgbaBG   background color of the help text.
   */
  void registerKeyboardCallback(char                 key, 
                                fptrKeyboardCallback callback, 
                                const std::string&   helpText, 
                                const unsigned char  rgba[4], 
                                const unsigned char  rgbaBG[4]);

  /**
   * @brief Registers an observer for keyboard events.
   *
   * @param[in] key      to be observed. 
   * @param[in] client   pointer to the observer.
   * @param[in] helpText describing the effects when pressing the key.
   * @param[in] rgba     color of the help text.
   * @param[in] rgbaBG   background color of the help text.
   */
  void registerKeyboardClient(char                key, 
                              Obvious2DClient*    client, 
                              const std::string&  helpText, 
                              const unsigned char rgba[4], 
                              const unsigned char rgbaBG[4]);

  /**
   * @brief Adds a crosshair to be drawn.
   *
   * @param[in] x      display position.
   * @param[in] y      display position.
   * @param[in] rgba   drawing color.
   * @param[in] rgbaBG drawing background color.
   * @param[in] radius of the crosshair.
   * @param[in] offset of the crosshair.
   */
  void addCrosshair(unsigned int        x, 
                    unsigned int        y, 
                    const std::string&  text, 
                    const unsigned char rgba[4], 
                    const unsigned char rgbaBG[4], 
                    float               radius = 0.04F, 
                    float               offset = 0.F);

  /**
   * @brief Adds a info text to be drawn once at the next frame.
   *
   * @param[in] text     to draw.
   * @param[in] rgba     drawing color
   * @param[in] rgbaBG   drawing background color
   * @param[in] progress progress status [0 ... 1.0]
   * @param[in] popup    if true, centered progress bar with text info. Otherwise text in lower left corner (only one popup is allowed).
   */
  void addVolatileInfoText(const std::string&  text, 
                           const unsigned char rgba[4], 
                           const unsigned char rgbaBG[4], 
                           double              progress = 0., 
                           bool                popup = false);

  /// Clears the info texts previously added (will not be displayed at next drawing).
  void clearVolatileInfoText();

  /**
   * @brief Sets the color of canvas (info text field).
   *
   * @param[in] rgba color.
   */
  void setColorCanvas(const unsigned char rgba[4]);

  /**
   * @brief Processes registered callbacks.
   *
   * @param[in] key registered key
   */
  void processCallback(char key);

  void setOperationModeInfo(const std::string& operationMode);

  static Obvious2D* _this[32];
  static bool _is_glut_initialized;
  static bool _instance_map[32];


private:
  /// Draws the help text.
  void drawHelp() const;

  /// Draws the user-defined information.
  void drawInfo() const;

  /// Draws user-defined popup.
  void drawPopup() const;

  /// Draws a transparent background for help and info boxes.
  void drawTextBackground(int minX, int maxX, int minY, int maxY, const unsigned char color[4]) const;

  /// Holds the added crosshairs.
  std::vector<CrossHair> _crosshairs;

  /// GLUT window handle.
  int _handle;

  int _isMasterGUI;

  /// Mutex
  static std::mutex _mutex;

  /// Is alive flag.
  bool _isAlive;

  /// Width of the GLUT window.
  unsigned int _width;

  /// Height of the GLUT window.
  unsigned int _height;

  /// Initial width passed via constructor.
  unsigned int _init_width;

  /// Initial height passed via constructor.
  unsigned int _init_height;

  /// Width of the screen.
  unsigned int _screen_width;

  /// Height of the screen.
  unsigned int _screen_height;

  /// Fullscreen flag.
  bool _fullscreen;

  /// Show help flag.
  bool _showHelp;

  /// Instance ID.
  unsigned int _instanceID;

  /// Callback map.
  std::map<char, fptrKeyboardCallback> _mCallback;

  /// Client map.
  std::map<char, Obvious2DClient*> _mClient;

  /// Help description.
  std::vector<TextStruct> _helpText;

  /// User-defined information.
  std::vector<TextStruct> _infoText;

  /// User-defined popups.
  std::vector<TextStruct> _popupText;

  /// GLUT fonts, e.g., GLUT_BITMAP_HELVETICA_10, GLUT_BITMAP_HELVETICA_12, GLUT_BITMAP_HELVETICA_18.
  void* _font;

  // 2D texture for drawing pixels
  GLuint _texture;

  /// Black border.
  unsigned int _borderLeft;
  unsigned int _borderRight;
  unsigned int _borderTop;
  unsigned int _borderBottom;

  /// Calculator of display fps.
  optris::FramerateCounter* _fpsDisplay;

  /// Show fps flag.
  bool _showFPS;
  /// Current source fps.
  double _fpsSrc;

  /// Show flag state flag.
  bool _showFlagState;
  /// Current flag state.
  std::string _flagState;

  /// Show operation mode.
  bool _showOperationMode;
  /// Operation mode info.
  std::string _operationMode;

  unsigned char* _colorCanvas;

  /// Serial number.
  int _serial = 0;
};
