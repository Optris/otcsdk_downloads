﻿// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/*
 * The configuration of the PIF is grouped in the configurePif() method. 
 * It checks which PIF device is connected and dependent on the available inputs and outputs sets these mode of the first channel of
 * each type:
 *
 * |         Channel         | [deviceIndex, pinIndex] |          Mode          |
 * |-------------------------|-------------------------|------------------------|
 * | Analog input (Ai)       |           [0, 0]        | Uncommitted Value      |
 * | Analog output (Ao)      |           [0, 0]        | Internal Temperature   |
 * | Digital input (Di)      |           [0, 0]        | Flag Control           |
 * | Digital output (Do)     |           [0, 0]        | External Communication |
 * | Dedicated FailSave (Fs) |           [0, 0]        | On                     |
 *
 * The direct access of the PIF input values happens in the onThermalFrame() callback via the FrameMetadata object. 
 * This example prints the value of each available channel to standard output.
 *
 * Some important notes:
 *  - This example will use only one camera
 *  - If a Di is available, the flag must be controlled by the input signal
 *  - It is also possible (and in many cases more flexible) to configure the PIF via the configuration file. 
 * This example will use the mode it configured for the first pin of each channel instead of the mode that is stated in the config file.
 *  - This is only a small subset of the possible modes for the PIF channels.
 *  - Please have a look at the documentation to learn more about configuring the modes used in this example as well as the other available modes. 
 */

using Optris.OtcSdk;

namespace Pif
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // Initialize the SDK with log verbosity
            Sdk.init(Verbosity.Info, Verbosity.Off, "Pif");
            
            /*
             * Add an additional detector for Ethernet devices on the network 192.168.0.0/24. A detector for USB devices was added
             * when calling Sdk.init().
             */
            EnumerationManager.getInstance().addEthernetDetector("192.168.0.0/24");

            // The serial number 0 serves as a wild card. If specified the first compatible devoice is used.
            uint serialNumber = 0;
            if (args.Length > 0)
            {
                serialNumber = uint.Parse(args[0]);
            }

            SimpleImagerClientPif client;
            try
            {
                client = new(serialNumber);

                // Configure the Process Interface (PIF)
                client.configurePif();
            }
            catch (SDKException ex)
            {
                Console.WriteLine(ex.Message);

                return;
            }

            // Run the client
            client.run();
        }
    }
}
