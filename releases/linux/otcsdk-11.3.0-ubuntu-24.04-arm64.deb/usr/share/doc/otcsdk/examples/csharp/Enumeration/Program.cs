﻿// Copyright (c) 2008-2026 Optris GmbH & Co. KG

using Optris.OtcSdk;


namespace Enumeration
{
    internal class Program
    {
        ///<summary>Program main entry point.</summary>
        static void Main(string[] args)
        {
            // Initialize the SDK by providing log verbosity
            Sdk.init(Verbosity.Error, Verbosity.Off, "Enumeration");

            SimpleEnumerationClient client = new();
            client.run();
        }
    }
}
