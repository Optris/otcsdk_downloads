// Copyright (c) 2008-2026 Optris GmbH & Co. KG

/**
 * @file    IRImagerShow.h
 * @author  Optris GmbH & Co. KG
 * @brief   Declaration of the IRImagerShow class.
 *          
 * @date    2024-06-19   
 */

#pragma once

#include <memory>
#include <mutex>
#include <cstdint>

#include "otcsdk/IRImager.h"
#include "otcsdk/ImageBuilder.h"
#include "otcsdk/FramerateCounter.h"

#include "display/opengl/Obvious2D.h"
#include "display/opengl/Obvious2DClient.h"



/**
 * @brief Example client implementation. 
 * 
 * Use this class as a template for your own application. Derive your class from optris::IRImagerClient and  
 * register it with addClient to an IRImager object. The run method of the IRImager object will trigger the 
 * callbacks to deliver data.
 * 
 * This layout adheres to the Observer design pattern.
 */
class IRImagerShow : public optris::IRImagerClient, public Obvious2DClient
{
public:
  /**
   * @brief Constructor.
   *
   * @param[in] serialNumber of the device to connect to or 0 to automatically choose a device connected
   *                         via USB.
   */
  IRImagerShow(unsigned int serialNumber);


  /// Starts the frame grabbing thread.
  void startGrabbingThread();

  /**
   * @brief Renders the latest available thermal frame.
   * 
   * @return true if thermal frame was rendered successfully. False if rendering fails, the user hits q or
   *         the window is closed.
   */
  bool render();


private:
  /// Mutex type used for thread synchronization.
  using Mutex = std::mutex;
  /// Lock type used for thread synchronization.
  using Lock  = std::unique_lock<Mutex>;


  /**
   * @brief Callback method triggered by imager when a new thermal frame is available.
   *
   * @param[in] evt event containing metadata, thermal frame data and measurement field data.
   */
  void onFrame(const optris::FrameEvent& evt) noexcept override;

  /**
   * @brief Callback method triggered by imager when the video format has changed.
   * 
   * This happens during calls to IRImager::connect() or IRImager::setActiveOperationMode().
   * 
   * @param[in] evt event containing the new video format information.
   */
  void onVideoFormatChanged(const optris::VideoFormatEvent& evt) noexcept override;

  /// Callback method triggered by connection events.
  void onConnection(optris::ConnectionEvent& evt) noexcept override;


  /**
   * @brief Callback for keyboard shortcuts from the GUI.
   * 
   * @param[in] key that triggered the callback from the GUI.
   */
  void keyboardCallback(char key) override;
  
  /**
   * @brief Draws a crosshair on the display with the provided temperature.
   * 
   * @param[in] imageWidth      of the false color image.
   * @param[in] imageHeight     of the false color image.
   * @param[in] positionX       of the crosshair center.
   * @param[in] positionY       of the crosshair center.
   * @param[in] temperature     to display.
   * @param[in] color           of the crosshair and the temperature text.
   * @param[in] backgroundColor of the crosshair and the temperature text.
   */
  void drawMeasurementInfo(unsigned int       imageWidth, 
                           unsigned int       imageHeight, 
                           unsigned int       positionX, 
                           unsigned int       positionY, 
                           float              temperature,
                           const std::uint8_t color[4], 
                           const std::uint8_t backgroundColor[4]);

  /// Updates the displayed information about the operation mode.
  void updateOperationModeInfo();


  /// Grabs and processes thermal frames.
  std::shared_ptr<optris::IRImager> _imager;

  /// Converts thermal frames to false color images.
  std::unique_ptr<optris::ImageBuilder> _imageBuilder;

  /// Displays the false color images on screen.
  std::unique_ptr<Obvious2D> _display;

  /// Frame counter for received thermal frames.
  std::unique_ptr<optris::FramerateCounter> _fps;

  /// Synchronizes the frame event data.
  Mutex _eventMutex;
  /// Frame event data.
  optris::FrameEvent _event;

  /// List of all available operation modes.
  std::vector<optris::OperationMode::ConstShared> _operationModes;
  /// Index of the active mode in the above vector.
  int _activeModeIndex;
};
